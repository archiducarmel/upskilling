# 🏗️ Guide Complet — Architecture de Monitoring IA V8

> *Une exploration détaillée de chaque bloc fonctionnel et de chaque flux de données, pour comprendre comment fonctionne une plateforme d'observabilité ML/LLM de bout en bout*

---

# 🎯 Vue d'Ensemble

L'architecture V8 de monitoring IA est conçue pour répondre à un besoin fondamental : **savoir ce qui se passe réellement quand vos modèles sont en production**. Elle combine deux approches complémentaires :

- **Batch Side** : Analyse périodique des distributions, détection de drift
- **Platform Side** : Évaluation qualitative continue par LLM-as-Judge

Cette dualité permet de couvrir à la fois les modèles tabulaires classiques (scoring, classification) et les modèles génératifs (RAG, chatbots).

---

# 📦 LES 8 BLOCS FONCTIONNELS

## Bloc 1 : Inference Platform — Là où tout commence

### Rôle fonctionnel
**L'Inference Platform est le cœur de production.** C'est ici que vos modèles ML/LLM reçoivent des requêtes et produisent des prédictions. Chaque use case (scoring crédit, détection de fraude, assistant conversationnel) est déployé comme un service indépendant.

### Ce qui s'y passe
Quand un utilisateur ou un système appelle un modèle :
1. La requête arrive avec ses données d'entrée
2. Le modèle exécute son inférence
3. La prédiction est retournée au demandeur
4. **Simultanément**, une trace est émise vers la plateforme d'observabilité

### Pourquoi c'est critique
Sans émission de traces depuis l'Inference Platform, tout le reste de l'architecture est aveugle. C'est le **contrat d'observabilité** : chaque prédiction doit être tracée pour pouvoir être analysée, auditée, et améliorée.

### Flux associé
- **① Telemetry** : Push des traces vers l'API d'observabilité

---

## Bloc 2 : Observability API — Le point d'entrée centralisé

### Rôle fonctionnel
**L'Observability API est le récepteur universel.** Toutes les données de monitoring transitent par elle : traces d'inférence, métriques de drift, scores d'évaluation. Elle agit comme un routeur intelligent qui valide, enrichit et persiste les données.

### Ce qui s'y passe
1. **Réception** : L'API expose des endpoints REST pour recevoir différents types de données
   - `POST /traces` pour les traces d'inférence (flux ①)
   - `POST /metrics` pour les métriques de drift (flux ⑧a)
2. **Validation** : Chaque payload est validé contre un schéma (champs obligatoires, types)
3. **Enrichissement** : Ajout de métadonnées (timestamp serveur, version API)
4. **Routage** : Les données sont immédiatement persistées en base (flux ② et ⑧b)

### Pourquoi c'est critique
L'API est le **goulot d'étranglement volontaire** de l'architecture. En centralisant tous les flux entrants, elle garantit la cohérence des données et permet d'appliquer des règles transverses (authentification, rate limiting, validation).

### Flux associés
- **① Telemetry** (entrée) : Réception des traces
- **② Persist** (sortie) : Écriture en base relationnelle
- **⑧a Write** (entrée) : Réception des métriques batch
- **⑧b Persist** (sortie) : Écriture des métriques en base

---

## Bloc 3 : Platform Evaluators — L'intelligence qualitative

### Rôle fonctionnel
**Les Platform Evaluators apportent le jugement.** Au-delà des métriques statistiques, ils évaluent la qualité réelle des sorties des modèles. Le composant principal est le **LLM-as-Judge** : un LLM qui note les réponses d'autres LLM.

### Ce qui s'y passe
1. **Polling** : Les évaluateurs interrogent périodiquement la base pour récupérer les traces non évaluées (flux ⑤a)
2. **Évaluation** : Pour chaque trace, le LLM-as-Judge appelle un LLM externe (flux ⑤b) avec un prompt structuré
3. **Scoring** : Le LLM retourne des scores sur différentes dimensions (faithfulness, hallucination, relevance)
4. **Persistance** : Les scores sont écrits en base (flux ⑨)

### Les dimensions d'évaluation
| Dimension | Question posée | Applicable à |
|-----------|---------------|--------------|
| **Faithfulness** | La réponse est-elle fidèle aux sources ? | RAG, Q&A |
| **Hallucination** | Y a-t-il des informations inventées ? | Tous LLM |
| **Relevance** | La réponse répond-elle à la question ? | Tous LLM |
| **Toxicity** | Le contenu est-il approprié ? | Modération |
| **Coherence** | La réponse est-elle logique ? | Génératif |

### Pourquoi c'est critique
Les métriques traditionnelles (précision, recall) ne capturent pas la qualité perçue d'un système génératif. Un RAG peut avoir un excellent recall documentaire mais produire des réponses incohérentes. **Seul un jugement contextuel peut détecter ces problèmes.**

### Flux associés
- **⑤a Read** : Lecture des traces à évaluer
- **⑤b LLM Call** : Appel au service LLM
- **⑨ Write** : Persistance des scores

---

## Bloc 4 : Batch Monitor — La sentinelle des distributions

### Rôle fonctionnel
**Le Batch Monitor surveille les dérives.** Il compare périodiquement les données de production aux données de référence (entraînement) pour détecter des changements dans les distributions. C'est l'approche classique du MLOps pour les modèles tabulaires.

### Ce qui s'y passe
1. **Chargement référence** : Le monitor récupère les datasets baseline depuis le Reference Storage (flux ④a)
2. **Récupération production** : Il charge les traces récentes depuis l'Object Storage (flux ④b)
3. **Calcul des métriques** : Pour chaque feature, il calcule des indicateurs de drift
4. **Envoi des résultats** : Les métriques sont poussées vers l'API (flux ⑧a)

### Les métriques de drift
| Métrique | Ce qu'elle mesure | Interprétation |
|----------|-------------------|----------------|
| **PSI** | Stabilité de population | < 0.1 stable, > 0.25 action requise |
| **KS Test** | Distance entre distributions | > 0.05 significatif |
| **Chi²** | Indépendance catégorielle | p-value < 0.05 = drift |
| **Jensen-Shannon** | Divergence probabiliste | 0 = identique, 1 = opposé |

### Pourquoi c'est critique
Un modèle entraîné sur des données de 2023 peut devenir obsolète si la population de 2024 est différente. Le Batch Monitor est le **système d'alerte précoce** qui détecte ces changements avant qu'ils n'impactent les décisions business.

### Flux associés
- **④a Get Ref** : Chargement des données de référence
- **④b Query S3** : Récupération des traces de production
- **⑧a Write** : Envoi des métriques de drift

---

## Bloc 5 : LLM Service — Le cerveau externe

### Rôle fonctionnel
**Le LLM Service fournit la capacité de raisonnement.** C'est un service d'inférence LLM (auto-hébergé ou cloud) que les Platform Evaluators appellent pour obtenir des jugements qualitatifs.

### Ce qui s'y passe
1. Le LLM-as-Judge construit un prompt structuré contenant :
   - La question originale de l'utilisateur
   - Les documents récupérés (si RAG)
   - La réponse générée par le modèle en production
   - Les critères d'évaluation
2. Le LLM Service exécute l'inférence et retourne un jugement structuré
3. Le LLM-as-Judge parse la réponse et extrait les scores

### Exemple de prompt d'évaluation
```
Évalue la réponse suivante sur une échelle de 0 à 1.

Question: Quelle est la politique de remboursement ?
Documents: [doc1: "Remboursement sous 30 jours...", doc2: "..."]
Réponse: "Vous pouvez retourner vos articles sous 30 jours..."

Critères:
- Faithfulness: La réponse est-elle fidèle aux documents ?
- Completeness: Tous les aspects sont-ils couverts ?
- Relevance: La réponse répond-elle à la question ?

Retourne un JSON avec les scores.
```

### Pourquoi c'est critique
La qualité de l'évaluation dépend directement de la qualité du LLM évaluateur. Un LLM médiocre produira des jugements incohérents. C'est pourquoi on utilise généralement des **modèles robustes** pour cette tâche.

### Flux associé
- **⑤b LLM Call** : Appel depuis le LLM-as-Judge

---

## Bloc 6 : Reference Storage — La mémoire du passé

### Rôle fonctionnel
**Le Reference Storage conserve les données de référence.** Ce sont les datasets d'entraînement, les distributions historiques, les golden sets utilisés pour valider les modèles. Ils représentent la "normalité" contre laquelle la production est comparée.

### Ce qu'il contient
- **Training sets** : Les données utilisées pour entraîner chaque modèle
- **Validation sets** : Les données de test avec labels connus
- **Distribution snapshots** : Histogrammes et statistiques des features au moment du déploiement

### Pourquoi c'est critique
Sans référence, pas de comparaison possible. Si vous ne savez pas comment se distribuait l'âge des clients au moment de l'entraînement, vous ne pouvez pas détecter que la population a rajeuni de 10 ans en production.

### Flux associé
- **④a Get Ref** : Lecture par le Batch Monitor

---

## Bloc 7 : Table Storage — La mémoire vive

### Rôle fonctionnel
**Le Table Storage est la base de données relationnelle.** Elle stocke toutes les données opérationnelles : traces récentes, métriques de drift, scores d'évaluation. C'est le point de vérité pour les requêtes temps réel.

### Ce qu'il contient
| Table | Contenu | Rétention |
|-------|---------|-----------|
| `traces` | Toutes les traces d'inférence | 30-90 jours |
| `drift_metrics` | Métriques PSI, KS, Chi² | 1 an |
| `evaluation_scores` | Scores LLM-as-Judge | 6 mois |
| `alerts` | Historique des alertes | 1 an |

### Pourquoi c'est critique
Le Table Storage permet les **requêtes SQL complexes** : agrégations, jointures, fenêtres temporelles. C'est ce qui alimente les dashboards et permet l'analyse ad-hoc.

### Flux associés
- **② Persist** : Écriture des traces
- **③ Sync** : Export vers Object Storage
- **⑤a Read** : Lecture par les évaluateurs
- **⑧b Persist** : Écriture des métriques
- **⑨ Write** : Écriture des scores
- **⑩ Read** : Lecture par les dashboards

---

## Bloc 8 : Object Storage — La mémoire longue

### Rôle fonctionnel
**L'Object Storage archive les données massives.** Format JSON ou Parquet, partitionné par date et use case, il stocke l'historique complet des traces à moindre coût. C'est la source pour les analyses batch.

### Ce qu'il contient
```
/traces/
  /2026/
    /01/
      /26/
        /credit_scoring/
          traces_2026-01-26_00.parquet
          traces_2026-01-26_01.parquet
          ...
        /fraud_detection/
          ...
```

### Pourquoi c'est critique
Le Table Storage n'est pas conçu pour stocker des années de données. L'Object Storage offre un **coût 10x inférieur** et une capacité quasi-illimitée, tout en permettant des analyses Spark/Batch.

### Flux associés
- **③ Sync** : Réception des exports périodiques
- **④b Query S3** : Lecture par le Batch Monitor

---

## Bloc 9 : Visualization Layer — La fenêtre sur le système

### Rôle fonctionnel
**Les Dashboards rendent l'information actionnable.** Ils agrègent et visualisent toutes les métriques pour que les équipes ML puissent surveiller, analyser et réagir.

### Ce qu'ils affichent
- **Vue Opérationnelle** : Volume, latence, erreurs en temps réel
- **Vue Drift** : Évolution des PSI/KS par feature sur 30 jours
- **Vue Qualité** : Scores faithfulness/hallucination par use case
- **Vue Alertes** : Notifications actives et historique

### Pourquoi c'est critique
Toute la data collectée n'a de valeur que si elle est **visible et compréhensible**. Les dashboards transforment des millions de traces en insights actionnables.

### Flux associé
- **⑩ Read** : Requêtes SQL vers le Table Storage

---

# 🔄 LES 11 FLUX DE DONNÉES

## Séquence globale

```
INGESTION          BATCH SIDE              PLATFORM SIDE         VISUALIZATION
─────────          ──────────              ─────────────         ─────────────
① → ② → ③    →    ④a + ④b → ⑧a → ⑧b    →    ⑤a → ⑤b → ⑨    →      ⑩
```

---

## 📥 INGESTION (Flux ①②③)

### Flux ① Telemetry — La capture initiale

**D'où :** Inference Platform  
**Vers :** Observability API  
**Protocole :** HTTP POST /traces  
**Fréquence :** Temps réel (chaque inférence)

**Ce qui se passe concrètement :**  
À l'instant où un modèle produit une prédiction, le code d'inférence construit une trace JSON et l'envoie à l'API. C'est généralement fait de manière asynchrone (fire-and-forget) pour ne pas impacter la latence de réponse à l'utilisateur.

**Les données transmises :**
```json
{
  "trace_id": "tr_abc123",
  "use_case": "credit_scoring",
  "timestamp": "2026-01-26T14:30:00Z",
  "input": {"age": 35, "income": 52000},
  "output": {"score": 0.73, "decision": "approved"},
  "latency_ms": 45,
  "model_version": "v2.1.0"
}
```

**Pourquoi ce flux est crucial :**  
C'est le seul point d'entrée des données de production dans le système. Si ce flux échoue (API down, réseau saturé), vous perdez la visibilité sur ce que font vos modèles.

---

### Flux ② Persist — La sauvegarde immédiate

**D'où :** Observability API  
**Vers :** Table Storage  
**Protocole :** SQL INSERT  
**Fréquence :** Synchrone (chaque trace reçue)

**Ce qui se passe concrètement :**  
L'API écrit immédiatement la trace en base. C'est un write-through : la réponse HTTP 200 n'est renvoyée qu'une fois l'écriture confirmée. Cela garantit qu'aucune trace n'est perdue en cas de crash.

**Pourquoi ce flux est crucial :**  
La persistance immédiate permet deux choses : (1) les traces sont requêtables instantanément pour le debugging, (2) en cas de panne, on sait exactement où on en était.

---

### Flux ③ Sync — L'archivage optimisé

**D'où :** Table Storage  
**Vers :** Object Storage  
**Protocole :** Export batch (SQL → Parquet)  
**Fréquence :** Toutes les 15 minutes

**Ce qui se passe concrètement :**  
Un job périodique extrait les traces des dernières 15 minutes, les convertit en format Parquet (compressé, colonaire), et les dépose sur l'Object Storage avec un partitionnement par date/use_case.

**Pourquoi ce flux est crucial :**  
Le Table Storage n'est pas fait pour stocker des années de données. Ce flux décharge la base et crée une archive économique pour les analyses long terme.

---

## 📊 BATCH SIDE (Flux ④a, ④b, ⑧a, ⑧b)

### Flux ④a Get Ref — Charger le passé

**D'où :** Reference Storage  
**Vers :** Batch Monitor  
**Protocole :** Lecture fichier (Parquet/CSV)  
**Fréquence :** À chaque exécution batch

**Ce qui se passe concrètement :**  
Le Batch Monitor commence par charger les distributions de référence. Pour chaque feature (age, income, etc.), il récupère les histogrammes et statistiques calculés sur le dataset d'entraînement.

**Pourquoi ce flux est crucial :**  
Sans baseline, impossible de dire si une distribution a changé. Ce flux fournit le point de comparaison indispensable au calcul du drift.

---

### Flux ④b Query S3 — Récupérer la production

**D'où :** Object Storage  
**Vers :** Batch Monitor  
**Protocole :** Lecture Parquet (S3/MinIO)  
**Fréquence :** À chaque exécution batch

**Ce qui se passe concrètement :**  
Le Batch Monitor liste les fichiers Parquet correspondant à la période à analyser (ex: dernières 24h), les télécharge et les charge en mémoire pour analyse.

**Pourquoi ce flux est crucial :**  
C'est la source des données de production. Le format Parquet et le stockage objet permettent de traiter des millions de traces efficacement.

---

### Flux ⑧a Write — Remonter les résultats

**D'où :** Batch Monitor  
**Vers :** Observability API  
**Protocole :** HTTP POST /metrics  
**Fréquence :** Fin de chaque batch

**Ce qui se passe concrètement :**  
Une fois les métriques calculées (PSI par feature, KS tests, etc.), le Batch Monitor les envoie à l'API sous forme de payload JSON structuré.

**Pourquoi ce flux est crucial :**  
Ce flux centralise les résultats de drift avec les autres données de monitoring. Sans lui, les métriques batch resteraient isolées.

---

### Flux ⑧b Persist — Historiser les métriques

**D'où :** Observability API  
**Vers :** Table Storage  
**Protocole :** SQL INSERT  
**Fréquence :** Après chaque réception de métriques

**Ce qui se passe concrètement :**  
L'API persiste chaque métrique avec son timestamp, use case, et valeur. Cela crée une série temporelle de drift exploitable pour visualiser les tendances.

**Pourquoi ce flux est crucial :**  
L'historisation permet de voir l'évolution du drift dans le temps. Un PSI qui passe progressivement de 0.05 à 0.15 sur 3 semaines est un signal d'alerte, même si le seuil de 0.25 n'est pas encore atteint.

---

## 🤖 PLATFORM SIDE (Flux ⑤a, ⑤b, ⑨)

### Flux ⑤a Read — Alimenter l'évaluateur

**D'où :** Table Storage  
**Vers :** Platform Evaluators  
**Protocole :** SQL SELECT  
**Fréquence :** Polling continu (toutes les 30s)

**Ce qui se passe concrètement :**  
Le LLM-as-Judge interroge la base pour récupérer les traces qui n'ont pas encore été évaluées. Il applique éventuellement un sampling (ex: 20% des traces) pour maîtriser les coûts.

```sql
SELECT * FROM traces 
WHERE evaluated = false 
  AND use_case IN ('rag_assistant', 'chatbot')
ORDER BY timestamp DESC
LIMIT 100
```

**Pourquoi ce flux est crucial :**  
Ce flux crée le découplage entre l'ingestion (temps réel, critique) et l'évaluation (asynchrone, tolérante). L'évaluation peut prendre du retard sans impacter la production.

---

### Flux ⑤b LLM Call — Le jugement

**D'où :** LLM-as-Judge  
**Vers :** LLM Service  
**Protocole :** HTTP POST /chat/completions  
**Fréquence :** Une fois par trace évaluée

**Ce qui se passe concrètement :**  
Pour chaque trace, le LLM-as-Judge construit un prompt d'évaluation et l'envoie au LLM Service. Il attend la réponse, parse le JSON retourné, et extrait les scores.

**Pourquoi ce flux est crucial :**  
C'est ici que se fait l'évaluation qualitative. La richesse du prompt et la qualité du LLM déterminent la pertinence des scores obtenus.

---

### Flux ⑨ Write — Persister les scores

**D'où :** Platform Evaluators  
**Vers :** Table Storage  
**Protocole :** SQL INSERT/UPDATE  
**Fréquence :** Après chaque évaluation

**Ce qui se passe concrètement :**  
Les scores (faithfulness: 0.92, hallucination: 0.05, etc.) sont écrits en base avec la référence à la trace évaluée. La trace est marquée comme évaluée.

**Pourquoi ce flux est crucial :**  
Ce flux ferme la boucle Platform Side. Les scores sont maintenant disponibles pour les dashboards et les alertes.

---

## 📈 VISUALIZATION (Flux ⑩)

### Flux ⑩ Read — Afficher l'insight

**D'où :** Table Storage  
**Vers :** Visualization Layer (Dashboards)  
**Protocole :** SQL SELECT (agrégations)  
**Fréquence :** Rafraîchissement dashboard (5-60s)

**Ce qui se passe concrètement :**  
Les dashboards exécutent des requêtes SQL agrégées pour calculer les métriques affichées : moyennes, percentiles, tendances, alertes actives.

```sql
-- Exemple : tendance faithfulness sur 7 jours
SELECT 
  DATE(timestamp) as day,
  use_case,
  AVG(faithfulness_score) as avg_faith,
  COUNT(*) as volume
FROM evaluation_scores
WHERE timestamp > NOW() - INTERVAL '7 days'
GROUP BY 1, 2
ORDER BY 1
```

**Pourquoi ce flux est crucial :**  
C'est le flux qui transforme toute la data collectée en **valeur visible**. Sans dashboards, les équipes ML n'auraient aucune visibilité sur la santé de leurs modèles.

---

# 🎯 Synthèse

L'architecture V8 de monitoring IA est un système **modulaire et extensible** qui combine :

| Approche | Composants | Forces |
|----------|------------|--------|
| **Batch Side** | Batch Monitor, Reference Storage | Drift statistique, coût optimisé |
| **Platform Side** | LLM-as-Judge, LLM Service | Évaluation qualitative, contextuelle |
| **Ingestion** | API, Table Storage, Object Storage | Temps réel, durable, économique |
| **Visualization** | Dashboards | Insight actionnable |

Les **11 flux** forment un pipeline cohérent :
1. **Capturer** (①②③) : Chaque inférence est tracée et archivée
2. **Analyser** (④⑤⑧) : Drift et qualité sont évalués en continu
3. **Persister** (②⑧b⑨) : Tout est historisé pour l'audit et l'analyse
4. **Visualiser** (⑩) : Les équipes ont une vue temps réel

Cette architecture pose les fondations pour la **V9**, qui ajoutera le flux **④b' Query API** offrant une alternative temps réel au batch pour les cas d'usage nécessitant une réactivité immédiate.

---

*Architecture V8 — 11 flux, 8 blocs fonctionnels, monitoring unifié ML/LLM*
