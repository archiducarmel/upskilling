# 🎯 Guide Approfondi — Les 3 Parcours End-to-End

> *Plongée détaillée dans le monitoring de bout en bout pour 3 cas d'usage représentatifs : scoring tabulaire, assistant génératif RAG et classification de toxicité*

---

# 📊 Cas 1 : Credit Scoring — Modèle Tabulaire

> *Comment monitorer un modèle de scoring crédit de l'inférence jusqu'au dashboard, en détectant les dérives de distribution*

---

## Vue d'ensemble

Le Credit Scoring est l'archétype du modèle ML tabulaire en production. Un client soumet une demande de crédit, le modèle analyse ses caractéristiques (revenus, âge, historique) et produit un score de risque. Ce cas d'usage est **réglementairement sensible** : chaque décision doit être traçable, et toute dérive du modèle doit être détectée rapidement.

---

## Phase 1 : Ingestion — Capturer chaque décision

### 🔄 Flux ① Telemetry

**Le parcours commence à l'instant précis où le modèle rend sa décision.**

Quand l'API de scoring reçoit une requête, elle exécute le modèle puis, immédiatement après, émet une trace vers la plateforme d'observabilité. Cette trace est structurée :

```
{
  "trace_id": "tr_8f2a4c",
  "use_case": "credit_scoring",
  "timestamp": "2026-01-26T14:32:01Z",
  "input": {
    "age": 34,
    "income": 52000,
    "debt_ratio": 0.31,
    "employment_years": 6
  },
  "output": {
    "score": 0.72,
    "decision": "approved",
    "confidence": 0.89
  }
}
```

**Pourquoi c'est crucial :** Sans cette émission systématique, aucune analyse ultérieure n'est possible. Le flux ① est le **contrat de confiance** entre l'inférence et l'observabilité.

---

### 🔄 Flux ② Persist

**La trace ne doit jamais être perdue.**

Dès réception, l'API d'observabilité valide le schéma (les champs obligatoires sont-ils présents ?) puis écrit immédiatement en base relationnelle. C'est un write-through : la réponse HTTP n'est renvoyée qu'une fois l'écriture confirmée.

**Ce que cela garantit :**
- **Durabilité** : même si le système crashe juste après, la trace est sauvée
- **Requêtabilité** : on peut immédiatement faire des requêtes SQL sur les dernières traces
- **Audit** : pour le régulateur, chaque décision de crédit est historisée

---

### 🔄 Flux ③ Sync

**Le stockage relationnel n'est pas fait pour l'archivage massif.**

Toutes les 15 minutes, un job exporte les nouvelles traces vers un stockage objet distribué. Format Parquet pour l'efficacité, partitionnement par date et use case pour faciliter les requêtes.

**L'intérêt stratégique :**
- La base relationnelle reste légère et performante
- Les analyses batch (drift, tendances) travaillent sur le stockage objet sans impacter la production
- Le coût de stockage long terme est divisé par 10

---

## Phase 2 : Détection de Drift — Surveiller les distributions

### 🔄 Flux ④a Get Ref

**Pour savoir si quelque chose a changé, il faut se souvenir de l'état initial.**

Le Batch Monitor charge le dataset de référence : ce sont les données d'entraînement du modèle de scoring. Elles représentent la "normalité" — la distribution des features au moment où le modèle a été validé.

**Exemple concret :**
- Référence : âge moyen = 42 ans, écart-type = 12
- Si en production l'âge moyen passe à 28 ans, c'est un **data drift** majeur

---

### 🔄 Flux ④b Query S3 (Option A) ou ④b' Query API (Option B)

**Récupérer les données de production à analyser.**

Deux stratégies possibles :

| Option | Flux | Latence | Coût | Usage |
|--------|------|---------|------|-------|
| **A** | ④b Query S3 | Minutes | Faible | Analyse quotidienne programmée |
| **B** | ④b' Query API | Secondes | Élevé | Alerte urgente, debugging |

Pour le Credit Scoring, l'**Option A** est généralement suffisante : un rapport de drift quotidien détecte les problèmes avant qu'ils n'impactent significativement le business.

---

### 🔄 Calcul des métriques de drift

**Le Batch Monitor compare les distributions.**

Sur chaque feature numérique (age, income, debt_ratio), il calcule :

- **PSI (Population Stability Index)** : mesure globale de changement de distribution
  - PSI < 0.1 : stable ✅
  - PSI 0.1-0.25 : surveillance ⚠️
  - PSI > 0.25 : action requise 🚨

- **KS (Kolmogorov-Smirnov)** : distance maximale entre les distributions cumulées

- **Chi² Test** : pour les variables catégorielles (statut emploi, type de logement)

---

### 🔄 Flux ⑧a Write + ⑧b Persist

**Les résultats remontent dans la plateforme.**

Une fois les métriques calculées, le Batch Monitor les envoie à l'API (⑧a) qui les persiste en base (⑧b). Chaque exécution crée un enregistrement daté :

```
| timestamp           | use_case       | metric | feature    | value |
|---------------------|----------------|--------|------------|-------|
| 2026-01-26 15:00:00 | credit_scoring | PSI    | age        | 0.08  |
| 2026-01-26 15:00:00 | credit_scoring | PSI    | income     | 0.23  |
| 2026-01-26 15:00:00 | credit_scoring | KS     | debt_ratio | 0.11  |
```

**Valeur ajoutée :** L'historisation permet de voir les tendances. Un PSI qui passe de 0.05 à 0.08 puis 0.12 sur trois semaines indique une dérive progressive — même si aucun seuil n'est encore franchi.

---

## Phase 3 : Visualisation — Rendre l'information actionnable

### 🔄 Flux ⑩ Read

**Tous les flux convergent vers les dashboards.**

L'équipe ML consulte un tableau de bord qui affiche :
- **Volume** : nombre de scorings par heure/jour
- **Performance** : latence p50, p95, p99
- **Drift** : courbes PSI par feature sur 30 jours
- **Alertes** : notifications quand un seuil est dépassé

**Le moment décisif :** C'est ici que le Data Scientist détecte que la feature "income" dérive dangereusement et décide de réentraîner le modèle — avant que les décisions de crédit ne deviennent incohérentes.

---

## 🎯 Résumé du parcours Credit Scoring

```
Client demande crédit
        ↓
┌─────────────────────┐
│  Modèle de Scoring  │ ──→ Décision (approved/rejected)
└─────────────────────┘
        ↓
   ① Telemetry (trace émise)
        ↓
   ② Persist (sauvegarde immédiate)
        ↓
   ③ Sync (export périodique)
        ↓
┌─────────────────────┐
│   Batch Monitor     │ ←── ④a Get Ref (baseline)
│   (calcul drift)    │ ←── ④b/④b' Query (prod data)
└─────────────────────┘
        ↓
   ⑧a Write + ⑧b Persist (métriques)
        ↓
   ⑩ Read (dashboards)
        ↓
   Data Scientist alerté → Réentraînement si nécessaire
```

---
---

# 🤖 Cas 2 : RAG Assistant — Modèle Génératif

> *Monitorer un assistant conversationnel avec retrieval, en évaluant la qualité des réponses par LLM-as-Judge*

---

## Vue d'ensemble

Le RAG Assistant combine recherche documentaire et génération de texte. Un utilisateur pose une question, le système récupère des documents pertinents, puis un LLM génère une réponse contextualisée. Ce cas d'usage est **complexe à monitorer** : comment savoir si la réponse est fidèle aux sources ? Comment détecter les hallucinations ?

---

## Phase 1 : Ingestion — Capturer l'interaction complète

### 🔄 Flux ① Telemetry

**Une trace RAG est plus riche qu'une trace tabulaire.**

Chaque interaction génère une trace qui capture tout le contexte :

```
{
  "trace_id": "tr_rag_7d2f",
  "use_case": "rag_assistant",
  "timestamp": "2026-01-26T14:45:22Z",
  "input": {
    "query": "Quelle est la politique de remboursement ?",
    "conversation_id": "conv_123",
    "turn": 3
  },
  "retrieval": {
    "documents": [
      {"id": "doc_456", "score": 0.92, "snippet": "Les remboursements sont possibles sous 30 jours..."},
      {"id": "doc_789", "score": 0.87, "snippet": "Pour demander un remboursement, contactez..."}
    ],
    "latency_ms": 45
  },
  "output": {
    "response": "Notre politique de remboursement vous permet de retourner tout article sous 30 jours. Pour initier une demande, vous pouvez contacter notre service client...",
    "model": "llm_v2",
    "tokens": 89,
    "latency_ms": 1250
  }
}
```

**La richesse de cette trace permet ensuite :**
- D'évaluer si la réponse est fidèle aux documents récupérés
- De mesurer la qualité du retrieval (les bons documents ont-ils été trouvés ?)
- D'analyser les performances (latence retrieval vs génération)

---

### 🔄 Flux ② Persist + ③ Sync

**Même logique que pour le tabulaire, mais avec des traces plus volumineuses.**

Les réponses génératives peuvent faire plusieurs centaines de tokens. Le stockage objet (③ Sync) devient crucial pour archiver ces traces sans exploser les coûts de la base relationnelle.

---

## Phase 2 : Évaluation Qualitative — Le jugement par l'IA

### 🔄 Flux ⑤a Read

**L'évaluation ne peut pas être temps réel.**

Un LLM-as-Judge qui analyse une réponse prend 2-5 secondes. Impossible de bloquer l'utilisateur. Le composant d'évaluation travaille donc en **asynchrone** : il interroge périodiquement la base pour récupérer les traces non encore évaluées.

**Stratégie de sampling :** Pour un assistant à fort volume, on n'évalue pas 100% des traces. Un échantillon de 10-20% suffit pour avoir une vision statistiquement fiable de la qualité.

---

### 🔄 Flux ⑤b LLM Call

**Le cœur de l'évaluation générative.**

Le LLM-as-Judge reçoit la question, les documents récupérés et la réponse générée. Il évalue selon plusieurs dimensions :

#### Faithfulness (Fidélité)
> *La réponse est-elle fidèle aux documents sources ?*

Le juge vérifie que chaque affirmation de la réponse peut être rattachée à un passage des documents. Score de 0 à 1.

**Exemple :**
- Documents : "Remboursement sous 30 jours"
- Réponse : "Vous avez 30 jours pour demander un remboursement" → Faithful ✅
- Réponse : "Vous avez 60 jours pour demander un remboursement" → Hallucination 🚨

#### Hallucination Detection
> *La réponse contient-elle des informations inventées ?*

Le juge identifie les affirmations qui ne sont supportées par aucun document. C'est le **risque majeur** des systèmes RAG : le modèle génère du contenu plausible mais faux.

#### Relevance (Pertinence)
> *La réponse répond-elle à la question posée ?*

Une réponse peut être fidèle aux documents mais hors sujet. Le juge évalue l'adéquation question/réponse.

#### Answer Completeness
> *La réponse couvre-t-elle tous les aspects de la question ?*

Si l'utilisateur pose une question à plusieurs volets, la réponse doit tous les adresser.

---

### 🔄 Flux ⑨ Write

**Les scores sont persistés avec la trace.**

Chaque évaluation enrichit la trace originale :

```
| trace_id    | metric       | score | details                          |
|-------------|--------------|-------|----------------------------------|
| tr_rag_7d2f | faithfulness | 0.94  | 15/16 claims supported           |
| tr_rag_7d2f | hallucination| 0.06  | 1 unsupported claim detected     |
| tr_rag_7d2f | relevance    | 0.91  | Direct answer to question        |
| tr_rag_7d2f | completeness | 0.88  | 2/2 aspects addressed            |
```

---

## Phase 3 : Monitoring du Retrieval — La qualité en amont

### Métriques spécifiques RAG

Au-delà de l'évaluation LLM, le monitoring RAG inclut des métriques de retrieval :

- **Recall@k** : Parmi les k documents récupérés, combien sont pertinents ?
- **MRR (Mean Reciprocal Rank)** : Le document le plus pertinent est-il bien classé en premier ?
- **Context Precision** : Les documents récupérés sont-ils vraiment utiles pour répondre ?

Ces métriques sont calculées par le **Batch Monitor** (flux ④a, ④b, ⑧a, ⑧b) en comparant les documents récupérés à des jugements de référence.

---

## Phase 4 : Visualisation — Piloter la qualité générative

### 🔄 Flux ⑩ Read

**Le dashboard RAG est multi-dimensionnel.**

L'équipe ML visualise :
- **Qualité générative** : tendance faithfulness, hallucination rate sur 7/30 jours
- **Performance retrieval** : Recall@5, latence de recherche
- **Alertes** : pics d'hallucination, dégradation du retrieval
- **Analyse par sujet** : certains topics génèrent-ils plus d'erreurs ?

**Le signal d'alerte typique :** Le taux d'hallucination passe de 5% à 12% sur une semaine. Investigation : une mise à jour de la base documentaire a supprimé des documents clés, forçant le modèle à "inventer" des réponses.

---

## 🎯 Résumé du parcours RAG Assistant

```
Utilisateur pose question
        ↓
┌─────────────────────┐
│   Retrieval Engine  │ ──→ Documents pertinents
└─────────────────────┘
        ↓
┌─────────────────────┐
│    LLM Génératif    │ ──→ Réponse contextualisée
└─────────────────────┘
        ↓
   ① Telemetry (trace complète : query + docs + response)
        ↓
   ② Persist + ③ Sync
        ↓
┌─────────────────────┐
│    LLM-as-Judge     │ ←── ⑤a Read (traces à évaluer)
│   (évaluation)      │ ──→ ⑤b LLM Call (scoring)
└─────────────────────┘
        ↓
   ⑨ Write (scores faithfulness, hallucination, relevance)
        ↓
┌─────────────────────┐
│   Batch Monitor     │ ←── ④a, ④b (métriques retrieval)
│   (Recall, MRR)     │ ──→ ⑧a, ⑧b
└─────────────────────┘
        ↓
   ⑩ Read (dashboard qualité + retrieval)
```

---
---

# 🛡️ Cas 3 : Toxicity Classification — Classification de Texte

> *Monitorer un modèle de modération de contenu, en combinant métriques de classification et évaluation safety*

---

## Vue d'ensemble

Le classificateur de toxicité analyse des messages utilisateurs et les catégorise : toxique, haineux, spam, ou clean. C'est un cas d'usage **critique pour la confiance** : un faux négatif (contenu toxique non détecté) expose la plateforme, un faux positif (contenu légitime bloqué) frustre les utilisateurs.

---

## Phase 1 : Ingestion — Capturer chaque classification

### 🔄 Flux ① Telemetry

**La trace capture le message et la décision.**

```
{
  "trace_id": "tr_tox_9e3b",
  "use_case": "toxicity_classification",
  "timestamp": "2026-01-26T14:52:33Z",
  "input": {
    "text": "Ce produit est vraiment une arnaque, évitez à tout prix !",
    "context": "product_review",
    "user_id": "usr_anon_789"
  },
  "output": {
    "prediction": "negative_but_clean",
    "scores": {
      "toxic": 0.12,
      "hate": 0.03,
      "spam": 0.08,
      "clean": 0.77
    },
    "decision": "approved",
    "confidence": 0.77
  }
}
```

**La nuance est essentielle :** Un avis négatif n'est pas toxique. Le modèle doit distinguer critique légitime et contenu haineux.

---

### 🔄 Flux ② Persist + ③ Sync

**Volume élevé, latence critique.**

Un modèle de modération peut traiter des millions de messages par jour. La persistance (②) doit être ultra-rapide pour ne pas créer de goulot d'étranglement. Le sync (③) vers le stockage objet est crucial pour l'archivage.

---

## Phase 2 : Évaluation Safety — Au-delà du modèle

### 🔄 Flux ⑤a Read + ⑤b LLM Call

**Le modèle de classification n'est pas infaillible.**

Le composant Safety utilise un LLM évaluateur pour vérifier les décisions du classificateur, particulièrement sur les cas limites :

#### Vérification des "clean" à faible confiance
Les messages classés "clean" mais avec un score de confiance < 0.8 sont réévalués. Le LLM analyse le contexte, les sous-entendus, l'ironie.

#### Détection des faux négatifs
Le LLM identifie des patterns toxiques que le classificateur a manqués : langage codé, toxicité implicite, harcèlement subtil.

#### Analyse des faux positifs
Des utilisateurs se plaignent de messages bloqués à tort. Le LLM réévalue et identifie les sur-détections.

---

### 🔄 Flux ⑨ Write

**Les corrections sont enregistrées.**

```
| trace_id    | metric            | value | llm_assessment                    |
|-------------|-------------------|-------|-----------------------------------|
| tr_tox_9e3b | classifier_ok     | true  | Negative review, not toxic        |
| tr_tox_4f2a | false_negative    | true  | Coded language detected           |
| tr_tox_8c1d | false_positive    | true  | Sarcasm misinterpreted            |
```

Ces données alimentent ensuite le **réentraînement** du classificateur.

---

## Phase 3 : Drift & Performance — Surveiller les distributions

### 🔄 Flux ④a Get Ref + ④b/④b' Query

**Le contenu utilisateur évolue constamment.**

Le Batch Monitor compare les distributions actuelles à la référence :

- **Label drift** : La proportion de contenu toxique a-t-elle changé ? Une augmentation soudaine peut indiquer une attaque coordonnée ou un événement viral.

- **Feature drift** : La longueur des messages, le vocabulaire utilisé ont-ils évolué ? De nouveaux termes toxiques apparaissent régulièrement.

- **Concept drift** : Ce qui était acceptable hier est-il toujours acceptable aujourd'hui ? Les normes sociales évoluent.

---

### 🔄 Flux ⑧a Write + ⑧b Persist

**Métriques spécifiques classification :**

| Métrique | Description | Seuil d'alerte |
|----------|-------------|----------------|
| **Precision (toxic)** | % de prédictions "toxic" correctes | < 0.85 |
| **Recall (toxic)** | % de contenu toxique détecté | < 0.90 |
| **F1 Score** | Harmonie precision/recall | < 0.87 |
| **FPR (False Positive Rate)** | % de clean classés toxic | > 0.05 |

---

## Phase 4 : Feedback Loop — Amélioration continue

### Le cercle vertueux

1. **Détection** (⑩ Read) : Le dashboard montre une baisse du recall sur le contenu haineux
2. **Analyse** (⑤a, ⑤b) : Le LLM Safety identifie un nouveau pattern de langage codé
3. **Action** : Les exemples mal classés sont ajoutés au dataset d'entraînement
4. **Réentraînement** : Nouveau modèle déployé
5. **Validation** : Les métriques remontent — le cycle recommence

---

## Phase 5 : Visualisation — Le cockpit de modération

### 🔄 Flux ⑩ Read

**Dashboard temps réel critique.**

Pour une plateforme de contenu, la modération est **temps réel** :
- **Volume** : messages analysés par minute, pics d'activité
- **Taux de blocage** : % de contenu filtré (normal : 1-3%, attaque : 15%+)
- **Confiance** : distribution des scores de confiance
- **Latence** : temps de classification (SLA : < 100ms)
- **Alertes** : pics de toxicité, nouveaux patterns détectés

**Scénario de crise :** À 14h, le taux de contenu toxique passe de 2% à 18%. L'équipe Trust & Safety est alertée immédiatement. Analyse : un événement d'actualité provoque un afflux de commentaires haineux. Action : renforcement temporaire des seuils de blocage.

---

## 🎯 Résumé du parcours Toxicity Classification

```
Message utilisateur
        ↓
┌─────────────────────┐
│   Classificateur    │ ──→ Décision (toxic/clean)
│     Toxicité        │ ──→ Action (block/approve)
└─────────────────────┘
        ↓
   ① Telemetry (message + scores + décision)
        ↓
   ② Persist + ③ Sync
        ↓
┌─────────────────────┐
│   Safety Evaluator  │ ←── ⑤a Read (cas limites)
│   (LLM vérification)│ ──→ ⑤b LLM Call
└─────────────────────┘
        ↓
   ⑨ Write (false positives/negatives identifiés)
        ↓
┌─────────────────────┐
│   Batch Monitor     │ ←── ④a Get Ref + ④b/④b' Query
│   (drift + metrics) │ ──→ ⑧a + ⑧b
└─────────────────────┘
        ↓
   ⑩ Read (dashboard modération temps réel)
        ↓
   Trust & Safety team → Actions immédiates si crise
        ↓
   Feedback → Réentraînement modèle
```

---
---

# 📊 Tableau Comparatif des 3 Cas E2E

| Aspect | Credit Scoring | RAG Assistant | Toxicity Classification |
|--------|---------------|---------------|------------------------|
| **Type de modèle** | Tabulaire (XGBoost, etc.) | Génératif (LLM + Retrieval) | Classification texte |
| **Volume typique** | 10K-100K/jour | 1K-50K/jour | 1M-10M/jour |
| **Latence requise** | < 200ms | < 3s | < 100ms |
| **Drift principal** | Features numériques | Qualité retrieval | Label distribution |
| **Évaluation clé** | PSI, KS, Chi² | Faithfulness, Hallucination | Precision, Recall, F1 |
| **LLM-as-Judge** | Non utilisé | Critique | Vérification cas limites |
| **Criticité** | Réglementaire | Expérience utilisateur | Trust & Safety |
| **Feedback loop** | Mensuel | Hebdomadaire | Continu |

---

*Architecture V9 — Monitoring adapté à chaque typologie de modèle ML/LLM*
