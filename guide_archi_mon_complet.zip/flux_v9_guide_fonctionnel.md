# 🔄 Guide Fonctionnel — Architecture de Monitoring IA V9

> *Un parcours pas à pas à travers les 12 flux qui font vivre votre plateforme d'observabilité ML/LLM*

---

## 📥 INGESTION — Capturer les données

### ① Telemetry — Le point d'entrée unique

**Tout commence ici.** À chaque fois qu'un modèle fait une prédiction, une trace est émise vers la plateforme d'observabilité. Cette trace contient l'input (les données envoyées au modèle), l'output (la réponse produite) et les métadonnées (timestamp, identifiant use case). Sans ce flux, aucune donnée n'entre dans le système — c'est la porte d'entrée obligatoire.

---

### ② Persist — Garantir la durabilité

**Les traces arrivent, il faut les sauvegarder.** Dès réception par l'API, chaque trace est immédiatement écrite en base de données relationnelle. Ce pattern "write-through" garantit qu'aucune donnée n'est perdue. C'est aussi ce qui permet ensuite de requêter l'historique, de faire des audits réglementaires et d'alimenter les analyses.

---

### ③ Sync — Optimiser le stockage long terme

**La base de données n'est pas faite pour tout stocker éternellement.** Périodiquement (toutes les 15 minutes par exemple), les traces sont exportées vers un stockage objet distribué. Format JSON ou Parquet, coût réduit, capacité quasi-illimitée. Les jobs d'analyse batch pourront y accéder sans surcharger la base principale.

---

## 📊 BATCH SIDE — Détecter les dérives

### ④a Get Ref — Charger la référence

**Pour détecter une dérive, il faut une référence.** Le Batch Monitor commence par charger les datasets d'entraînement (baseline) depuis le stockage de référence. Ces données représentent la "normalité" : la distribution des features et des prédictions au moment où le modèle a été validé. Sans cette baseline, impossible de calculer PSI, KS ou Chi².

---

### ④b Query S3 — Option A : le batch économique

**Première option pour récupérer les traces de production.** Le Batch Monitor lit directement les fichiers JSON exportés sur le stockage objet. Avantages : coût très faible, traitement massif parallélisable, pas d'impact sur la base. Inconvénient : latence de quelques minutes. Parfait pour les analyses périodiques programmées (quotidiennes, hebdomadaires).

---

### ④b' Query API — Option B : le temps réel ⭐ NEW V9

**Nouveauté V9 : une alternative temps réel.** Au lieu de lire les fichiers batch, le Batch Monitor interroge directement l'API avec des filtres (date, use case, tags). Résultat en secondes, pas en minutes. Plus coûteux en ressources, mais indispensable pour les alertes urgentes, le debugging en live ou les dashboards interactifs.

---

### ⑧a Write — Remonter les résultats

**Le Batch Monitor a calculé ses métriques de drift, il faut les centraliser.** Les scores (PSI, KS, Chi²) sont envoyés à l'API d'observabilité via un endpoint dédié. Cela permet d'avoir une vue unifiée : traces, métriques de drift et scores de qualité au même endroit, prêts pour la visualisation et l'alerting.

---

### ⑧b Persist — Historiser les métriques

**Les métriques de drift doivent être conservées dans le temps.** L'API écrit ces scores en base de données. Cet historique est précieux : il permet de visualiser les tendances, de comparer les périodes entre elles, de détecter des dégradations progressives et d'alimenter les systèmes d'alerte avec des seuils dynamiques.

---

## 🤖 PLATFORM SIDE — Évaluer la qualité

### ⑤a Read — Récupérer les traces à évaluer

**L'évaluation qualitative se fait de manière asynchrone.** Les composants d'évaluation (LLM-as-Judge, Safety) interrogent la base pour récupérer les traces non encore évaluées. Ce découplage est essentiel : l'ingestion temps réel n'est jamais bloquée par les évaluations, qui peuvent prendre plusieurs secondes par trace.

---

### ⑤b LLM Call — Le jugement par l'IA

**C'est le cœur de l'évaluation générative.** Le composant LLM-as-Judge envoie chaque paire (input, output) à un LLM évaluateur. Celui-ci note la fidélité, détecte les hallucinations, évalue la pertinence. Cette approche remplace les métriques traditionnelles par un jugement contextuel, plus proche de l'évaluation humaine.

---

### ⑨ Write — Sauvegarder les scores qualité

**Les scores d'évaluation doivent être persistés.** Chaque note (faithfulness, hallucination, toxicity) est écrite en base avec la référence de la trace évaluée. Cela permet le suivi temporel de la qualité, la détection de dégradations, l'analyse des causes racines et l'alimentation des dashboards de qualité.

---

## 📈 VISUALIZATION — Restituer l'information

### ⑩ Read — Alimenter les dashboards

**Tous les flux convergent ici.** Les dashboards interrogent la base de données pour afficher en temps réel : volume de traces, métriques de performance, scores de drift, évaluations de qualité, alertes actives. C'est l'interface finale pour les équipes ML : une vue unifiée de la santé de tous les modèles en production.

---

## 🎯 Résumé visuel

```
┌─────────────────────────────────────────────────────────────────┐
│                         INGESTION                                │
│  ① Telemetry → ② Persist → ③ Sync                              │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                        BATCH SIDE                                │
│  ④a Get Ref ←─┐                                                 │
│  ④b Query S3 ←┼── Batch Monitor ──→ ⑧a Write → ⑧b Persist      │
│  ④b' Query API←┘      (drift)                                   │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                      PLATFORM SIDE                               │
│  ⑤a Read → LLM-as-Judge → ⑤b LLM Call                          │
│                 ↓                                                │
│            ⑨ Write (scores qualité)                             │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                      VISUALIZATION                               │
│                    ⑩ Read → Dashboards                          │
└─────────────────────────────────────────────────────────────────┘
```

---

*Architecture V9 — 12 flux, 2 options de requêtage batch, évaluation générative intégrée.*
