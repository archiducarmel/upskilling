import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis } from 'recharts';

// Data
const inputTypeData = [
  { name: 'Texte', value: 12, color: '#06b6d4' },
  { name: 'Tableau numérique', value: 6, color: '#3b82f6' },
];

const inputTempoData = [
  { name: 'Périodique', value: 18, color: '#22c55e' },
];

const outputTypeData = [
  { name: 'Tableau numérique', value: 14, color: '#8b5cf6' },
  { name: 'Texte', value: 5, color: '#f43f5e' },
];

const outputTempoData = [
  { name: 'Périodique', value: 14, color: '#22c55e' },
  { name: 'Temps réel', value: 5, color: '#f59e0b' },
];

const annotationData = [
  { name: 'Oui', value: 16, color: '#22c55e' },
  { name: 'Non', value: 2, color: '#f43f5e' },
  { name: 'N/A', value: 6, color: '#64748b' },
];

const feedbackData = [
  { name: 'Oui', value: 14, color: '#22c55e' },
  { name: 'N/A', value: 10, color: '#64748b' },
];

const inputMetrics = [
  { name: 'Longueur message', count: 11 },
  { name: 'Distribution', count: 10 },
  { name: 'Drift detection', count: 6 },
  { name: 'PSI / KS test', count: 6 },
  { name: 'Features analysis', count: 5 },
  { name: 'Timestamp', count: 4 },
  { name: 'OOV / Embedding', count: 3 },
  { name: 'Toxicité / Validité', count: 3 },
];

const outputMetrics = [
  { name: 'Distribution', count: 14 },
  { name: 'Stats descriptives', count: 9 },
  { name: 'Min / Max / Std', count: 9 },
  { name: 'Score', count: 7 },
  { name: 'Quantiles', count: 6 },
  { name: 'LLM Juge', count: 5 },
  { name: 'Sémantique / Token', count: 5 },
  { name: 'Score confiance', count: 5 },
];

const modelTypeStats = [
  { name: 'NLP Classification', count: 8, input: 7, output: 7, annotation: 7, icon: '🤖', color: 'rgba(244, 63, 94, 0.15)' },
  { name: 'Tabulaire Classification', count: 4, input: 4, output: 4, annotation: 3, icon: '📊', color: 'rgba(59, 130, 246, 0.15)' },
  { name: 'NLP Génératif', count: 3, input: 3, output: 3, annotation: 3, icon: '✨', color: 'rgba(139, 92, 246, 0.15)' },
  { name: 'Tabulaire Régression', count: 2, input: 2, output: 2, annotation: 1, icon: '📈', color: 'rgba(59, 130, 246, 0.15)' },
  { name: 'NLP RAG', count: 2, input: 1, output: 2, annotation: 2, icon: '🔍', color: 'rgba(6, 182, 212, 0.15)' },
  { name: 'Speech-to-Text', count: 2, input: 0, output: 0, annotation: 0, icon: '🎤', color: 'rgba(251, 191, 36, 0.15)' },
  { name: 'Recommandation', count: 1, input: 1, output: 1, annotation: 0, icon: '🎯', color: 'rgba(16, 185, 129, 0.15)' },
  { name: 'Non défini', count: 2, input: 0, output: 0, annotation: 0, icon: '❓', color: 'rgba(100, 116, 139, 0.15)' },
];

const inputWordCloud = [
  { word: 'longueur', size: 5 }, { word: 'message', size: 5 }, { word: 'distribution', size: 4 },
  { word: 'drift', size: 3 }, { word: 'PSI', size: 3 }, { word: 'KS test', size: 3 },
  { word: 'features', size: 3 }, { word: 'timestamp', size: 2 }, { word: 'OOV', size: 2 },
  { word: 'embedding', size: 2 }, { word: 'toxicité', size: 2 }, { word: 'validité', size: 2 }, { word: 'sentiment', size: 1 },
];

const outputWordCloud = [
  { word: 'distribution', size: 5 }, { word: 'statistiques', size: 4 }, { word: 'min/max/std', size: 4 },
  { word: 'score', size: 3 }, { word: 'quantiles', size: 3 }, { word: 'LLM Juge', size: 3 },
  { word: 'sémantique', size: 3 }, { word: 'token', size: 2 }, { word: 'coûts', size: 2 },
  { word: 'classification', size: 2 }, { word: 'confiance', size: 2 },
];

const CustomTooltip = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div style={{ background: 'rgba(15, 23, 42, 0.95)', border: '1px solid rgba(148, 163, 184, 0.2)', borderRadius: '10px', padding: '12px 16px' }}>
        <p style={{ color: '#f1f5f9', fontWeight: '600', fontSize: '13px', margin: 0 }}>{data.name}: {data.value}</p>
      </div>
    );
  }
  return null;
};

const StatCard = ({ title, value, subtitle, icon, color, percentage }) => (
  <div style={{
    background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.8) 0%, rgba(15, 23, 42, 0.9) 100%)',
    borderRadius: '20px', padding: '22px', border: '1px solid rgba(148, 163, 184, 0.1)',
    position: 'relative', overflow: 'hidden'
  }}>
    <div style={{ position: 'absolute', top: 0, right: 0, width: '100px', height: '100px', background: color, borderRadius: '50%', filter: 'blur(35px)', opacity: 0.3, transform: 'translate(30%, -30%)' }} />
    <div style={{ position: 'relative', zIndex: 1 }}>
      <div style={{ fontSize: '22px', marginBottom: '8px' }}>{icon}</div>
      <p style={{ color: '#64748b', fontSize: '11px', textTransform: 'uppercase', letterSpacing: '1px', fontWeight: '600', margin: '0 0 5px 0' }}>{title}</p>
      <p style={{ color: color, fontSize: '28px', fontWeight: '800', margin: '0 0 3px 0' }}>{value}</p>
      <p style={{ color: '#94a3b8', fontSize: '11px', margin: 0 }}>{subtitle}</p>
      {percentage !== undefined && (
        <div style={{ marginTop: '12px', height: '6px', background: 'rgba(148, 163, 184, 0.1)', borderRadius: '3px', overflow: 'hidden' }}>
          <div style={{ height: '100%', width: `${percentage}%`, background: `linear-gradient(90deg, ${color}, ${color}dd)`, borderRadius: '3px' }} />
        </div>
      )}
    </div>
  </div>
);

const WordCloud = ({ words, colorClass }) => (
  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', justifyContent: 'center', alignItems: 'center', minHeight: '180px', padding: '20px' }}>
    {words.map((item, idx) => {
      const sizes = { 1: '11px', 2: '13px', 3: '15px', 4: '17px', 5: '20px' };
      const opacities = { 1: 0.7, 2: 0.8, 3: 0.9, 4: 1, 5: 1 };
      const colors = { cyan: { bg: 'rgba(6, 182, 212, 0.15)', text: '#22d3ee' }, violet: { bg: 'rgba(139, 92, 246, 0.15)', text: '#a78bfa' } };
      return (
        <span key={idx} style={{
          padding: '8px 16px', borderRadius: '20px', fontWeight: item.size >= 4 ? '800' : '600',
          fontSize: sizes[item.size], opacity: opacities[item.size],
          background: colors[colorClass].bg, color: colors[colorClass].text,
          transition: 'transform 0.3s ease', cursor: 'default'
        }}
        onMouseEnter={e => e.target.style.transform = 'scale(1.1)'}
        onMouseLeave={e => e.target.style.transform = 'scale(1)'}
        >{item.word}</span>
      );
    })}
  </div>
);

const MetricsList = ({ metrics, colorClass, maxCount }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
    {metrics.map((m, idx) => (
      <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 16px', background: 'rgba(15, 23, 42, 0.5)', borderRadius: '12px', border: '1px solid rgba(148, 163, 184, 0.05)' }}>
        <span style={{ flex: 1, fontSize: '13px', fontWeight: '500', color: '#f8fafc' }}>{m.name}</span>
        <span style={{ fontSize: '14px', fontWeight: '700', minWidth: '40px', textAlign: 'right', color: colorClass === 'cyan' ? '#22d3ee' : '#a78bfa' }}>{m.count}</span>
        <div style={{ flex: 1, maxWidth: '150px', height: '8px', background: 'rgba(148, 163, 184, 0.1)', borderRadius: '4px', overflow: 'hidden' }}>
          <div style={{ height: '100%', width: `${(m.count / maxCount) * 100}%`, background: colorClass === 'cyan' ? 'linear-gradient(90deg, #06b6d4, #22d3ee)' : 'linear-gradient(90deg, #8b5cf6, #a78bfa)', borderRadius: '4px' }} />
        </div>
      </div>
    ))}
  </div>
);

const MiniDonutChart = ({ data }) => (
  <ResponsiveContainer width="100%" height="100%">
    <PieChart>
      <Pie data={data} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={35} outerRadius={50} paddingAngle={2}>
        {data.map((entry, index) => <Cell key={index} fill={entry.color} stroke="rgba(15, 23, 42, 0.8)" strokeWidth={2} />)}
      </Pie>
      <Tooltip content={<CustomTooltip />} />
    </PieChart>
  </ResponsiveContainer>
);

export default function MonitoringNeedsDashboard() {
  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(180deg, #0f172a 0%, #020617 100%)', fontFamily: "'Inter', -apple-system, sans-serif", padding: '40px', position: 'relative', overflow: 'hidden' }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
        @keyframes fadeSlideUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.7; } }
        @keyframes float { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-20px); } }
      `}</style>

      <div style={{ position: 'fixed', top: '5%', left: '5%', width: '500px', height: '500px', background: 'radial-gradient(circle, rgba(6, 182, 212, 0.08) 0%, transparent 70%)', borderRadius: '50%', pointerEvents: 'none', animation: 'float 20s ease-in-out infinite' }} />
      <div style={{ position: 'fixed', bottom: '10%', right: '10%', width: '600px', height: '600px', background: 'radial-gradient(circle, rgba(139, 92, 246, 0.08) 0%, transparent 70%)', borderRadius: '50%', pointerEvents: 'none', animation: 'float 25s ease-in-out infinite reverse' }} />

      <div style={{ maxWidth: '1700px', margin: '0 auto', position: 'relative', zIndex: 1 }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '50px' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.15), rgba(6, 182, 212, 0.15))', padding: '8px 20px', borderRadius: '30px', marginBottom: '20px', border: '1px solid rgba(148, 163, 184, 0.1)' }}>
            <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#22c55e', animation: 'pulse 2s infinite' }} />
            <span style={{ color: '#94a3b8', fontSize: '13px', fontWeight: '600', letterSpacing: '1px' }}>ANALYSE APPROFONDIE</span>
          </div>
          <h1 style={{ color: '#f8fafc', fontSize: '44px', fontWeight: '900', margin: '0 0 12px 0', letterSpacing: '-2px', background: 'linear-gradient(135deg, #f8fafc, #94a3b8)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Besoins de Monitoring ML</h1>
          <p style={{ color: '#64748b', fontSize: '18px', margin: 0, fontWeight: '500' }}>Input, Model & Output Monitoring • Annotation & Gestion des Datasets • 24 Use Cases analysés</p>
        </div>

        {/* KPIs */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '18px', marginBottom: '40px' }}>
          <StatCard title="UC Analysés" value="24" subtitle="Use Cases total" icon="📊" color="#34d399" />
          <StatCard title="Input Monitoring" value="18" subtitle="75% des UC" icon="📥" color="#22d3ee" percentage={75} />
          <StatCard title="Output Monitoring" value="19" subtitle="79.2% des UC" icon="📤" color="#a78bfa" percentage={79.2} />
          <StatCard title="Annotation" value="16" subtitle="66.7% des UC" icon="🏷️" color="#fbbf24" percentage={66.7} />
          <StatCard title="User Feedback" value="14" subtitle="58.3% des UC" icon="💬" color="#fb7185" percentage={58.3} />
        </div>

        {/* Input & Output Sections */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', marginBottom: '30px' }}>
          {/* Input Monitoring */}
          <div style={{ background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.8) 100%)', borderRadius: '24px', padding: '28px', border: '1px solid rgba(6, 182, 212, 0.2)' }}>
            <h3 style={{ fontSize: '16px', fontWeight: '700', marginBottom: '6px', display: 'flex', alignItems: 'center', gap: '10px', color: '#f8fafc' }}>📥 Input Monitoring</h3>
            <p style={{ color: '#64748b', fontSize: '13px', marginBottom: '20px' }}>Analyse des besoins de monitoring des entrées</p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '20px' }}>
              <div>
                <p style={{ fontSize: '12px', color: '#64748b', marginBottom: '10px', textTransform: 'uppercase', letterSpacing: '1px' }}>Type d'entrée</p>
                <div style={{ height: '160px' }}><ResponsiveContainer><PieChart><Pie data={inputTypeData} dataKey="value" cx="50%" cy="50%" innerRadius={45} outerRadius={65} paddingAngle={3}>{inputTypeData.map((e, i) => <Cell key={i} fill={e.color} stroke="rgba(15,23,42,0.8)" strokeWidth={3} />)}</Pie><Tooltip content={<CustomTooltip />} /></PieChart></ResponsiveContainer></div>
                <div style={{ display: 'flex', gap: '12px', justifyContent: 'center', marginTop: '10px' }}>{inputTypeData.map((d, i) => <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11px', color: '#94a3b8' }}><div style={{ width: '8px', height: '8px', borderRadius: '50%', background: d.color }} />{d.name} ({d.value})</div>)}</div>
              </div>
              <div>
                <p style={{ fontSize: '12px', color: '#64748b', marginBottom: '10px', textTransform: 'uppercase', letterSpacing: '1px' }}>Temporalité</p>
                <div style={{ height: '160px' }}><ResponsiveContainer><PieChart><Pie data={inputTempoData} dataKey="value" cx="50%" cy="50%" innerRadius={45} outerRadius={65}>{inputTempoData.map((e, i) => <Cell key={i} fill={e.color} stroke="rgba(15,23,42,0.8)" strokeWidth={3} />)}</Pie><Tooltip content={<CustomTooltip />} /></PieChart></ResponsiveContainer></div>
                <div style={{ display: 'flex', gap: '12px', justifyContent: 'center', marginTop: '10px' }}><div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11px', color: '#94a3b8' }}><div style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#22c55e' }} />Périodique (18)</div></div>
              </div>
            </div>
            <p style={{ fontSize: '12px', color: '#64748b', marginBottom: '12px', textTransform: 'uppercase', letterSpacing: '1px' }}>Métriques clés (Word Cloud)</p>
            <WordCloud words={inputWordCloud} colorClass="cyan" />
          </div>

          {/* Output Monitoring */}
          <div style={{ background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.8) 100%)', borderRadius: '24px', padding: '28px', border: '1px solid rgba(139, 92, 246, 0.2)' }}>
            <h3 style={{ fontSize: '16px', fontWeight: '700', marginBottom: '6px', display: 'flex', alignItems: 'center', gap: '10px', color: '#f8fafc' }}>📤 Output Monitoring</h3>
            <p style={{ color: '#64748b', fontSize: '13px', marginBottom: '20px' }}>Analyse des besoins de monitoring des sorties</p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '20px' }}>
              <div>
                <p style={{ fontSize: '12px', color: '#64748b', marginBottom: '10px', textTransform: 'uppercase', letterSpacing: '1px' }}>Type de sortie</p>
                <div style={{ height: '160px' }}><ResponsiveContainer><PieChart><Pie data={outputTypeData} dataKey="value" cx="50%" cy="50%" innerRadius={45} outerRadius={65} paddingAngle={3}>{outputTypeData.map((e, i) => <Cell key={i} fill={e.color} stroke="rgba(15,23,42,0.8)" strokeWidth={3} />)}</Pie><Tooltip content={<CustomTooltip />} /></PieChart></ResponsiveContainer></div>
                <div style={{ display: 'flex', gap: '12px', justifyContent: 'center', marginTop: '10px' }}>{outputTypeData.map((d, i) => <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11px', color: '#94a3b8' }}><div style={{ width: '8px', height: '8px', borderRadius: '50%', background: d.color }} />{d.name} ({d.value})</div>)}</div>
              </div>
              <div>
                <p style={{ fontSize: '12px', color: '#64748b', marginBottom: '10px', textTransform: 'uppercase', letterSpacing: '1px' }}>Temporalité</p>
                <div style={{ height: '160px' }}><ResponsiveContainer><PieChart><Pie data={outputTempoData} dataKey="value" cx="50%" cy="50%" innerRadius={45} outerRadius={65} paddingAngle={3}>{outputTempoData.map((e, i) => <Cell key={i} fill={e.color} stroke="rgba(15,23,42,0.8)" strokeWidth={3} />)}</Pie><Tooltip content={<CustomTooltip />} /></PieChart></ResponsiveContainer></div>
                <div style={{ display: 'flex', gap: '12px', justifyContent: 'center', marginTop: '10px' }}>{outputTempoData.map((d, i) => <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11px', color: '#94a3b8' }}><div style={{ width: '8px', height: '8px', borderRadius: '50%', background: d.color }} />{d.name} ({d.value})</div>)}</div>
              </div>
            </div>
            <p style={{ fontSize: '12px', color: '#64748b', marginBottom: '12px', textTransform: 'uppercase', letterSpacing: '1px' }}>Métriques clés (Word Cloud)</p>
            <WordCloud words={outputWordCloud} colorClass="violet" />
          </div>
        </div>

        {/* Top Metrics */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', marginBottom: '30px' }}>
          <div style={{ background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.8) 100%)', borderRadius: '24px', padding: '28px', border: '1px solid rgba(6, 182, 212, 0.2)' }}>
            <h3 style={{ fontSize: '16px', fontWeight: '700', marginBottom: '6px', color: '#f8fafc' }}>📊 Top Métriques Input</h3>
            <p style={{ color: '#64748b', fontSize: '13px', marginBottom: '20px' }}>Métriques de monitoring des entrées les plus demandées</p>
            <MetricsList metrics={inputMetrics} colorClass="cyan" maxCount={11} />
          </div>
          <div style={{ background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.8) 100%)', borderRadius: '24px', padding: '28px', border: '1px solid rgba(139, 92, 246, 0.2)' }}>
            <h3 style={{ fontSize: '16px', fontWeight: '700', marginBottom: '6px', color: '#f8fafc' }}>📈 Top Métriques Output</h3>
            <p style={{ color: '#64748b', fontSize: '13px', marginBottom: '20px' }}>Métriques de monitoring des sorties les plus demandées</p>
            <MetricsList metrics={outputMetrics} colorClass="violet" maxCount={14} />
          </div>
        </div>

        {/* Model Type Stats */}
        <div style={{ background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.8) 100%)', borderRadius: '24px', padding: '28px', border: '1px solid rgba(251, 191, 36, 0.2)', marginBottom: '30px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', marginBottom: '6px', color: '#f8fafc' }}>🧠 Besoins de Monitoring par Type de Modèle</h3>
          <p style={{ color: '#64748b', fontSize: '13px', marginBottom: '20px' }}>Couverture des besoins selon la catégorie de modèle ML</p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
            {modelTypeStats.map((m, idx) => (
              <div key={idx} style={{ background: 'rgba(15, 23, 42, 0.5)', borderRadius: '14px', padding: '16px', border: '1px solid rgba(148, 163, 184, 0.05)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' }}>
                  <div style={{ width: '32px', height: '32px', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px', background: m.color }}>{m.icon}</div>
                  <span style={{ fontSize: '12px', fontWeight: '600', flex: 1, color: '#f8fafc' }}>{m.name}</span>
                  <span style={{ fontSize: '11px', color: '#64748b', background: 'rgba(148, 163, 184, 0.1)', padding: '2px 8px', borderRadius: '10px' }}>{m.count} UC</span>
                </div>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <div style={{ flex: 1, textAlign: 'center', padding: '8px', borderRadius: '8px', background: 'rgba(148, 163, 184, 0.05)' }}>
                    <div style={{ fontSize: '16px', fontWeight: '700', color: m.input > 0 ? '#22d3ee' : '#64748b' }}>{m.input}</div>
                    <div style={{ fontSize: '9px', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', marginTop: '2px' }}>Input</div>
                  </div>
                  <div style={{ flex: 1, textAlign: 'center', padding: '8px', borderRadius: '8px', background: 'rgba(148, 163, 184, 0.05)' }}>
                    <div style={{ fontSize: '16px', fontWeight: '700', color: m.output > 0 ? '#a78bfa' : '#64748b' }}>{m.output}</div>
                    <div style={{ fontSize: '9px', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', marginTop: '2px' }}>Output</div>
                  </div>
                  <div style={{ flex: 1, textAlign: 'center', padding: '8px', borderRadius: '8px', background: 'rgba(148, 163, 184, 0.05)' }}>
                    <div style={{ fontSize: '16px', fontWeight: '700', color: m.annotation > 0 ? '#fbbf24' : '#64748b' }}>{m.annotation}</div>
                    <div style={{ fontSize: '9px', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', marginTop: '2px' }}>Annot.</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Annotation & Datasets */}
        <div style={{ background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.8) 100%)', borderRadius: '24px', padding: '28px', border: '1px solid rgba(16, 185, 129, 0.2)', marginBottom: '30px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', marginBottom: '6px', color: '#f8fafc' }}>🏷️ Annotation & Gestion des Datasets</h3>
          <p style={{ color: '#64748b', fontSize: '13px', marginBottom: '20px' }}>Besoins en annotation des traces et création de datasets</p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px' }}>
            {[
              { icon: '✏️', title: 'Annotation des Traces', data: annotationData },
              { icon: '👥', title: 'Collaboration', data: annotationData },
              { icon: '📁', title: 'Création Dataset', data: annotationData },
              { icon: '💬', title: 'User Feedback', data: feedbackData },
            ].map((item, idx) => (
              <div key={idx} style={{ background: 'rgba(15, 23, 42, 0.5)', borderRadius: '16px', padding: '20px', border: '1px solid rgba(148, 163, 184, 0.05)', textAlign: 'center' }}>
                <div style={{ fontSize: '28px', marginBottom: '10px' }}>{item.icon}</div>
                <div style={{ fontSize: '13px', fontWeight: '600', marginBottom: '16px', color: '#f8fafc' }}>{item.title}</div>
                <div style={{ height: '120px', marginBottom: '12px' }}><MiniDonutChart data={item.data} /></div>
                <div style={{ display: 'flex', justifyContent: 'center', gap: '16px' }}>
                  {item.data.map((d, i) => (
                    <div key={i} style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '18px', fontWeight: '700', color: d.color }}>{d.value}</div>
                      <div style={{ fontSize: '10px', color: '#64748b', textTransform: 'uppercase' }}>{d.name}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div style={{ textAlign: 'center', marginTop: '50px', paddingTop: '30px', borderTop: '1px solid rgba(148, 163, 184, 0.1)' }}>
          <p style={{ color: '#475569', fontSize: '13px' }}>Dashboard Besoins de Monitoring - Plateforme ML • Analyse approfondie • {new Date().toLocaleDateString('fr-FR', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>
      </div>
    </div>
  );
}
