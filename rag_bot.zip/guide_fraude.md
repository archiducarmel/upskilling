# Guide de la détection de fraude

## Qu'est-ce que la fraude bancaire ?

La fraude bancaire désigne toute activité illégale visant à obtenir de l'argent ou des biens 
par tromperie auprès d'institutions financières ou de leurs clients. Elle peut prendre 
plusieurs formes : fraude à la carte bancaire, usurpation d'identité, phishing, ou 
manipulation de transactions.

## Types de fraude courants

### Fraude à la carte bancaire
La fraude à la carte bancaire est le type le plus fréquent. Elle survient lorsqu'un 
criminel utilise les informations d'une carte volée pour effectuer des achats non autorisés. 
Les signaux d'alerte incluent : des transactions à des heures inhabituelles, des achats 
dans des lieux géographiquement éloignés du domicile du titulaire, et des montants 
anormalement élevés.

### Phishing
Le phishing consiste à envoyer des messages frauduleux (emails, SMS) imitant des 
institutions légitimes pour obtenir les informations personnelles des victimes. Les 
attaques de phishing sont de plus en plus sophistiquées et peuvent cibler aussi bien 
les particuliers que les entreprises.

### Usurpation d'identité
L'usurpation d'identité implique l'utilisation des informations personnelles d'une 
personne sans son consentement pour ouvrir des comptes, contracter des prêts, ou 
effectuer des transactions. C'est souvent le résultat d'une fuite de données.

## Techniques de détection

### Détection par règles
Les systèmes à base de règles définissent des seuils et des conditions pour identifier 
les transactions suspectes. Par exemple : bloquer toute transaction supérieure à 5000€ 
depuis un nouveau terminal, ou alerter si plus de 3 transactions sont effectuées en 
moins de 5 minutes.

### Machine Learning
Les modèles de machine learning, comme XGBoost ou les réseaux de neurones, analysent 
des patterns complexes dans les données transactionnelles. Ils peuvent détecter des 
anomalies subtiles que les règles statiques manqueraient. Le modèle apprend à partir 
de données historiques étiquetées (fraude / non-fraude).

### Feature engineering pour la détection de fraude
Les features les plus discriminantes incluent :
- La distance géographique entre le client et le commerçant
- L'heure de la transaction (les fraudes sont plus fréquentes la nuit)
- Le montant par rapport à l'historique du client
- La fréquence des transactions récentes
- Le type de commerçant

## Métriques d'évaluation

Pour évaluer un modèle de détection de fraude, on utilise principalement :
- **Precision** : parmi les transactions signalées comme fraude, combien le sont réellement
- **Recall** : parmi toutes les fraudes réelles, combien ont été détectées
- **F1-Score** : moyenne harmonique de la precision et du recall
- **ROC-AUC** : capacité du modèle à distinguer fraude et non-fraude

Le recall est souvent prioritaire car manquer une fraude coûte plus cher qu'un faux positif.
