"""
LLMaaS client — single interface for embedding, reranking, and chat.

All three calls go to the same base URL with different endpoints:
  POST /v1/embeddings          (OpenAI-compatible)
  POST /v1/rerank              (Cohere-compatible)
  POST /v1/chat/completions    (OpenAI-compatible)
"""
from __future__ import annotations

import logging
import os
from typing import Any

import requests

logger = logging.getLogger("rag.llm_client")


class LLMClient:
    """Stateless HTTP client for LLMaaS endpoints."""

    def __init__(self):
        self.base_url = os.getenv("LLMAAS_BASE_URL", "").rstrip("/")
        self.api_key = os.getenv("LLMAAS_API_KEY", "")
        self.llm_model = os.getenv("LLM_MODEL_NAME", "")
        self.embed_model = os.getenv("EMBEDDING_MODEL_NAME", "bge-m3")
        self.rerank_model = os.getenv("RERANK_MODEL_NAME", "bge-reranker-v2-m3")

        if not self.base_url or not self.api_key:
            raise ValueError("LLMAAS_BASE_URL and LLMAAS_API_KEY must be set")

    @property
    def _headers(self) -> dict:
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

    # ── Embedding ───────────────────────────────────────────────────

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a list of texts via BGE-M3.

        Args:
            texts: list of strings to embed.

        Returns:
            List of embedding vectors (list of floats).
        """
        resp = requests.post(
            f"{self.base_url}/embeddings",
            headers=self._headers,
            json={"model": self.embed_model, "input": texts},
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        # OpenAI format: data[i].embedding
        return [item["embedding"] for item in sorted(data["data"], key=lambda x: x["index"])]

    def embed_single(self, text: str) -> list[float]:
        """Embed a single text."""
        return self.embed([text])[0]

    # ── Reranking ───────────────────────────────────────────────────

    def rerank(
        self, query: str, documents: list[str], top_n: int = 3
    ) -> list[dict[str, Any]]:
        """Rerank documents against a query via BGE-reranker.

        Args:
            query: the user question.
            documents: list of text chunks to rerank.
            top_n: number of top results to return.

        Returns:
            List of dicts with keys: index, relevance_score, text.
            Sorted by relevance_score descending.
        """
        resp = requests.post(
            f"{self.base_url}/rerank",
            headers=self._headers,
            json={
                "model": self.rerank_model,
                "query": query,
                "documents": documents,
                "top_n": top_n,
            },
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()

        results = []
        for item in data.get("results", []):
            idx = item["index"]
            results.append({
                "index": idx,
                "relevance_score": item["relevance_score"],
                "text": documents[idx],
            })
        return sorted(results, key=lambda x: x["relevance_score"], reverse=True)

    # ── Chat / Generation ───────────────────────────────────────────

    def chat(
        self,
        messages: list[dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 1024,
    ) -> dict[str, Any]:
        """Send a chat completion request.

        Args:
            messages: list of {"role": ..., "content": ...} dicts.
            temperature: sampling temperature.
            max_tokens: max response tokens.

        Returns:
            Dict with keys: content, model, usage.
        """
        resp = requests.post(
            f"{self.base_url}/chat/completions",
            headers=self._headers,
            json={
                "model": self.llm_model,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
            },
            timeout=60,
        )
        resp.raise_for_status()
        data = resp.json()
        choice = data["choices"][0]["message"]
        return {
            "content": choice["content"],
            "model": data.get("model", self.llm_model),
            "usage": data.get("usage", {}),
        }
