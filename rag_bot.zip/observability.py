"""
Langfuse observability for RAG pipeline.

Trace structure per /chat request:
───────────────────────────────────
trace: "rag-pipeline"
  ├── embedding:  "embed-query"        → query → vector (BGE-M3)
  ├── retriever:  "vector-search"      → vector → top-K chunks
  ├── span:       "rerank"             → top-K → top-N reranked
  ├── generation: "llm-generation"     → context + question → answer
  └── scores:
        ├── top_chunk_score     NUMERIC      rerank score of best chunk
        ├── num_chunks_used     NUMERIC      how many chunks in context
        ├── answer_length       NUMERIC      response length tracking
"""
from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger("rag.observability")

_langfuse = None
_enabled = False


def init_langfuse():
    """Initialize Langfuse. Silent no-op if keys are missing."""
    global _langfuse, _enabled

    if os.getenv("LANGFUSE_ENABLED", "true").lower() == "false":
        logger.info("Langfuse disabled")
        return

    pk = os.getenv("LANGFUSE_PUBLIC_KEY")
    sk = os.getenv("LANGFUSE_SECRET_KEY")
    if not pk or not sk:
        logger.info("Langfuse keys not set — tracing disabled")
        return

    try:
        from langfuse import Langfuse
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider

        resource = Resource.create({"service.name": "rag-bot-api"})
        provider = TracerProvider(resource=resource)

        _langfuse = Langfuse(
            public_key=pk,
            secret_key=sk,
            host=os.getenv("LANGFUSE_BASE_URL", "https://cloud.langfuse.com"),
            tracer_provider=provider,
        )
        _enabled = True
        logger.info("Langfuse tracing enabled (key: %s...)", pk[:12])
    except Exception as e:
        logger.warning("Langfuse init failed: %s", e)


def shutdown_langfuse():
    if _langfuse:
        try:
            _langfuse.flush()
        except Exception:
            pass


def trace_rag_pipeline(
    *,
    request_id: str,
    user_query: str,
    query_embedding_dim: int,
    embed_ms: float,
    retrieved_chunks: list[dict],
    retrieve_ms: float,
    reranked_chunks: list[dict],
    rerank_ms: float,
    llm_response: str,
    llm_model: str,
    llm_usage: dict,
    generate_ms: float,
    system_prompt: str,
):
    """Trace a complete RAG pipeline call to Langfuse."""
    if not _enabled:
        return

    try:
        _send_trace(
            request_id=request_id,
            user_query=user_query,
            query_embedding_dim=query_embedding_dim,
            embed_ms=embed_ms,
            retrieved_chunks=retrieved_chunks,
            retrieve_ms=retrieve_ms,
            reranked_chunks=reranked_chunks,
            rerank_ms=rerank_ms,
            llm_response=llm_response,
            llm_model=llm_model,
            llm_usage=llm_usage,
            generate_ms=generate_ms,
            system_prompt=system_prompt,
        )
    except Exception as e:
        logger.warning("Langfuse trace failed: %s", e)


def _send_trace(
    *,
    request_id: str,
    user_query: str,
    query_embedding_dim: int,
    embed_ms: float,
    retrieved_chunks: list[dict],
    retrieve_ms: float,
    reranked_chunks: list[dict],
    rerank_ms: float,
    llm_response: str,
    llm_model: str,
    llm_usage: dict,
    generate_ms: float,
    system_prompt: str,
):
    total_ms = embed_ms + retrieve_ms + rerank_ms + generate_ms
    top_score = reranked_chunks[0]["relevance_score"] if reranked_chunks else 0

    tags = ["rag"]
    if top_score < 0.3:
        tags.append("low_relevance")
    if len(reranked_chunks) == 0:
        tags.append("no_context")

    # ── Root trace ──
    with _langfuse.start_as_current_observation(
        as_type="span",
        name="rag-pipeline",
        input={"query": user_query},
        output={"answer": llm_response[:500]},
        metadata={
            "request_id": request_id,
            "total_latency_ms": round(total_ms, 2),
        },
    ):
        _langfuse.update_current_trace(tags=tags)

        # ── Embedding: encode the user query ──
        with _langfuse.start_as_current_observation(
            as_type="generation",
            name="embed-query",
            model=f"bge-m3",
            input={"query": user_query},
            output={"embedding_dim": query_embedding_dim},
            usage_details={"input": len(user_query.split()), "output": query_embedding_dim},
            metadata={"latency_ms": round(embed_ms, 2)},
        ):
            pass

        # ── Retrieval: vector search ──
        with _langfuse.start_as_current_observation(
            as_type="span",
            name="vector-search",
            input={"embedding_dim": query_embedding_dim, "top_k": len(retrieved_chunks)},
            output={
                "num_results": len(retrieved_chunks),
                "sources": list({c.get("source", "") for c in retrieved_chunks}),
            },
            metadata={"latency_ms": round(retrieve_ms, 2)},
        ):
            pass

        # ── Reranking ──
        with _langfuse.start_as_current_observation(
            as_type="span",
            name="rerank",
            input={
                "query": user_query,
                "num_candidates": len(retrieved_chunks),
            },
            output={
                "num_kept": len(reranked_chunks),
                "top_score": round(top_score, 4),
                "scores": [round(c["relevance_score"], 4) for c in reranked_chunks],
            },
            metadata={"latency_ms": round(rerank_ms, 2)},
        ):
            pass

        # ── LLM Generation ──
        with _langfuse.start_as_current_observation(
            as_type="generation",
            name="llm-generation",
            model=llm_model,
            input={
                "system_prompt": system_prompt[:200],
                "user_query": user_query,
                "context_chunks": len(reranked_chunks),
            },
            output={"response": llm_response[:500]},
            usage_details=llm_usage,
            metadata={"latency_ms": round(generate_ms, 2)},
        ):
            pass

        # ── Scores ──
        _langfuse.score_current_trace(
            name="top_chunk_score",
            value=round(top_score, 4),
            data_type="NUMERIC",
            comment="best rerank score — low = poor retrieval",
        )
        _langfuse.score_current_trace(
            name="num_chunks_used",
            value=len(reranked_chunks),
            data_type="NUMERIC",
        )
        _langfuse.score_current_trace(
            name="answer_length",
            value=len(llm_response),
            data_type="NUMERIC",
            comment="track response verbosity over time",
        )
