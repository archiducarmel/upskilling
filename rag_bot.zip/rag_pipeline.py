"""
RAG pipeline — orchestrates the 4 steps:
  1. Embed the user query           (BGE-M3)
  2. Retrieve top-K chunks          (ChromaDB cosine search)
  3. Rerank to top-N                (BGE-reranker via LLMaaS)
  4. Generate answer with context   (LLM via LLMaaS)
"""
from __future__ import annotations

import logging
import os
import time

from app.llm_client import LLMClient
from app.vector_store import VectorStore
from app.observability import trace_rag_pipeline

logger = logging.getLogger("rag.pipeline")

SYSTEM_PROMPT = (
    "Tu es un assistant qui répond aux questions en se basant uniquement "
    "sur le contexte fourni. Si le contexte ne contient pas la réponse, "
    "dis-le clairement. Réponds en français, de manière concise et précise."
)


def run_pipeline(
    query: str,
    llm: LLMClient,
    store: VectorStore,
    request_id: str = "",
) -> dict:
    """Run the full RAG pipeline and return structured results.

    Returns:
        Dict with keys: answer, sources, timings, reranked_chunks.
    """
    top_k = int(os.getenv("RETRIEVAL_TOP_K", "10"))
    top_n = int(os.getenv("RERANK_TOP_N", "3"))

    # ── Step 1: Embed query ─────────────────────────────────────────
    t0 = time.perf_counter()
    query_embedding = llm.embed_single(query)
    embed_ms = (time.perf_counter() - t0) * 1000

    # ── Step 2: Retrieve top-K ──────────────────────────────────────
    t0 = time.perf_counter()
    retrieved = store.search(query_embedding, top_k=top_k)
    retrieve_ms = (time.perf_counter() - t0) * 1000

    # ── Step 3: Rerank to top-N ─────────────────────────────────────
    reranked = []
    rerank_ms = 0.0
    if retrieved:
        candidate_texts = [c["text"] for c in retrieved]
        t0 = time.perf_counter()
        reranked = llm.rerank(query, candidate_texts, top_n=top_n)
        rerank_ms = (time.perf_counter() - t0) * 1000

    # ── Step 4: Generate answer ─────────────────────────────────────
    context = "\n\n---\n\n".join(c["text"] for c in reranked) if reranked else ""

    user_message = (
        f"Contexte:\n{context}\n\n---\n\nQuestion: {query}"
        if context
        else f"Question: {query}\n\n(Aucun contexte trouvé dans la base documentaire.)"
    )

    t0 = time.perf_counter()
    llm_result = llm.chat(
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_message},
        ]
    )
    generate_ms = (time.perf_counter() - t0) * 1000

    # ── Trace to Langfuse ───────────────────────────────────────────
    trace_rag_pipeline(
        request_id=request_id,
        user_query=query,
        query_embedding_dim=len(query_embedding),
        embed_ms=embed_ms,
        retrieved_chunks=retrieved,
        retrieve_ms=retrieve_ms,
        reranked_chunks=reranked,
        rerank_ms=rerank_ms,
        llm_response=llm_result["content"],
        llm_model=llm_result["model"],
        llm_usage=llm_result["usage"],
        generate_ms=generate_ms,
        system_prompt=SYSTEM_PROMPT,
    )

    # ── Build response ──────────────────────────────────────────────
    sources = list({c.get("source", c.get("text", "")[:50]) for c in reranked})

    return {
        "answer": llm_result["content"],
        "sources": sources,
        "timings": {
            "embed_ms": round(embed_ms, 2),
            "retrieve_ms": round(retrieve_ms, 2),
            "rerank_ms": round(rerank_ms, 2),
            "generate_ms": round(generate_ms, 2),
            "total_ms": round(embed_ms + retrieve_ms + rerank_ms + generate_ms, 2),
        },
        "reranked_chunks": [
            {"text": c["text"][:200], "score": round(c["relevance_score"], 4)}
            for c in reranked
        ],
    }
