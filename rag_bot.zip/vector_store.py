"""
ChromaDB vector store — ingestion and retrieval.

Documents are chunked, embedded via LLMaaS BGE-M3, and stored
in a persistent ChromaDB collection.
"""
from __future__ import annotations

import hashlib
import logging
import os
from pathlib import Path

import chromadb

from app.llm_client import LLMClient

logger = logging.getLogger("rag.vector_store")

CHROMA_DIR = Path(__file__).parent.parent / "chroma_data"
COLLECTION_NAME = "rag_docs"


class VectorStore:
    """ChromaDB-backed vector store with LLMaaS embedding."""

    def __init__(self, llm_client: LLMClient):
        self.llm = llm_client
        self.client = chromadb.PersistentClient(path=str(CHROMA_DIR))
        self.collection = self.client.get_or_create_collection(
            name=COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )
        logger.info(
            "ChromaDB ready: %d documents in '%s'",
            self.collection.count(), COLLECTION_NAME,
        )

    # ── Chunking ────────────────────────────────────────────────────

    @staticmethod
    def chunk_text(
        text: str,
        chunk_size: int | None = None,
        chunk_overlap: int | None = None,
    ) -> list[str]:
        """Split text into overlapping chunks by character count."""
        size = chunk_size or int(os.getenv("CHUNK_SIZE", "512"))
        overlap = chunk_overlap or int(os.getenv("CHUNK_OVERLAP", "50"))
        chunks = []
        start = 0
        while start < len(text):
            end = start + size
            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            start += size - overlap
        return chunks

    # ── Ingestion ───────────────────────────────────────────────────

    def ingest_file(self, filepath: str | Path) -> int:
        """Read a text/markdown file, chunk it, embed, and store.

        Returns the number of chunks added.
        """
        filepath = Path(filepath)
        if not filepath.exists():
            raise FileNotFoundError(f"{filepath} not found")

        text = filepath.read_text(encoding="utf-8")
        chunks = self.chunk_text(text)
        if not chunks:
            return 0

        # Generate deterministic IDs to avoid duplicates
        ids = [
            hashlib.md5(f"{filepath.name}:{i}:{c[:50]}".encode()).hexdigest()
            for i, c in enumerate(chunks)
        ]

        # Embed all chunks via LLMaaS
        embeddings = self.llm.embed(chunks)

        # Upsert into ChromaDB
        self.collection.upsert(
            ids=ids,
            embeddings=embeddings,
            documents=chunks,
            metadatas=[{"source": filepath.name, "chunk_index": i} for i, _ in enumerate(chunks)],
        )

        logger.info("Ingested %d chunks from %s", len(chunks), filepath.name)
        return len(chunks)

    def ingest_directory(self, dirpath: str | Path) -> dict[str, int]:
        """Ingest all .txt and .md files from a directory.

        Returns dict of {filename: chunk_count}.
        """
        dirpath = Path(dirpath)
        results = {}
        for f in sorted(dirpath.iterdir()):
            if f.suffix.lower() in (".txt", ".md"):
                results[f.name] = self.ingest_file(f)
        return results

    # ── Search ──────────────────────────────────────────────────────

    def search(
        self, query_embedding: list[float], top_k: int | None = None,
    ) -> list[dict]:
        """Search for similar chunks by embedding.

        Returns list of dicts with keys: text, source, chunk_index, distance.
        """
        k = top_k or int(os.getenv("RETRIEVAL_TOP_K", "10"))
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=min(k, self.collection.count()),
            include=["documents", "metadatas", "distances"],
        )

        hits = []
        for i in range(len(results["ids"][0])):
            hits.append({
                "text": results["documents"][0][i],
                "source": results["metadatas"][0][i].get("source", ""),
                "chunk_index": results["metadatas"][0][i].get("chunk_index", 0),
                "distance": results["distances"][0][i],
            })
        return hits

    @property
    def count(self) -> int:
        return self.collection.count()
