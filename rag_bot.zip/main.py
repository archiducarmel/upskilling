"""
RAG Bot API

Endpoints:
  GET  /health    → service status + doc count
  POST /ingest    → ingest .txt/.md files from data/ directory
  POST /chat      → ask a question, get a RAG-powered answer
"""
from __future__ import annotations

import logging
import uuid
from contextlib import asynccontextmanager

from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware

from app.schemas import ChatRequest, ChatResponse, IngestResponse, HealthResponse
from app.llm_client import LLMClient
from app.vector_store import VectorStore
from app.rag_pipeline import run_pipeline
from app.observability import init_langfuse, shutdown_langfuse

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("rag.api")

_llm: LLMClient | None = None
_store: VectorStore | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _llm, _store
    _llm = LLMClient()
    _store = VectorStore(_llm)
    init_langfuse()
    logger.info("RAG Bot API ready — %d documents indexed", _store.count)
    yield
    shutdown_langfuse()


app = FastAPI(
    title="RAG Bot API",
    description="Simple RAG bot: embed → retrieve → rerank → generate.",
    version="1.0.0",
    lifespan=lifespan,
)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.get("/health", response_model=HealthResponse, tags=["System"])
async def health():
    return HealthResponse(
        documents_indexed=_store.count if _store else 0,
        models={
            "llm": _llm.llm_model if _llm else "",
            "embedding": _llm.embed_model if _llm else "",
            "reranker": _llm.rerank_model if _llm else "",
        },
    )


@app.post("/ingest", response_model=IngestResponse, tags=["Ingestion"])
async def ingest():
    """Ingest all .txt and .md files from the data/ directory."""
    if not _store:
        raise HTTPException(503, "Store not initialized")

    from pathlib import Path
    data_dir = Path(__file__).parent.parent / "data"
    if not data_dir.exists():
        raise HTTPException(400, f"data/ directory not found at {data_dir}")

    results = _store.ingest_directory(data_dir)
    total = sum(results.values())
    return IngestResponse(status="ok", files=results, total_chunks=total)


@app.post("/chat", response_model=ChatResponse, tags=["Chat"])
async def chat(
    request: Request,
    query: str = Query(..., min_length=1, max_length=2000, description="Your question"),
):
    """Ask a question — runs the full RAG pipeline."""
    if not _llm or not _store:
        raise HTTPException(503, "Service not ready")

    if _store.count == 0:
        raise HTTPException(
            400,
            "No documents indexed. Call POST /ingest first to load documents from data/.",
        )

    rid = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    result = run_pipeline(
        query=query,
        llm=_llm,
        store=_store,
        request_id=rid,
    )
    return ChatResponse(**result)
