"""Pydantic schemas for the RAG Bot API."""
from __future__ import annotations
from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=2000, description="User question")


class ChunkInfo(BaseModel):
    text: str
    score: float


class Timings(BaseModel):
    embed_ms: float
    retrieve_ms: float
    rerank_ms: float
    generate_ms: float
    total_ms: float


class ChatResponse(BaseModel):
    answer: str
    sources: list[str]
    timings: Timings
    reranked_chunks: list[ChunkInfo]


class IngestResponse(BaseModel):
    status: str
    files: dict[str, int] = Field(default_factory=dict, description="filename → chunk count")
    total_chunks: int


class HealthResponse(BaseModel):
    status: str = "ok"
    documents_indexed: int
    models: dict[str, str]
