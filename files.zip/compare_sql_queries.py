#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
=============================================================================
SCRIPT DE COMPARAISON DES REQUÊTES SQL : ORIGINAL vs CORRIGÉ
=============================================================================

Ce script permet de comparer les performances et résultats entre les requêtes
SQL originales et leurs versions corrigées pour le projet PDO.

UTILISATION :
-------------
1. Placer les fichiers SQL corrigés dans common/sql/queries_corrected/
2. Exécuter : python compare_sql_queries.py
3. Ou exécuter une seule requête : python compare_sql_queries.py --queries transac

AUTEUR : IA Factory - Code Review
DATE : 2025-12
=============================================================================
"""

from __future__ import annotations

import argparse
import logging
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

import polars as pl

# =============================================================================
# IMPORTS DU PROJET EXISTANT (même pattern que batch.py)
# =============================================================================
from ml_utils.logger_helper import configure_logger
from ml_utils.vault_connector import VaultConnector

from common.con_starburst import StarburstConnector
from common.sql.retrieve_sql_query import retrieve_sql_query
from common.constants import LOGGER_NAME

# Import pour charger les variables d'environnement (comme dans batch.py)
from config.load_config import load_service_config_file

# Logger - initialisé après configure_logger()
logger = logging.getLogger(LOGGER_NAME)


# =============================================================================
# CONFIGURATION DES REQUÊTES
# =============================================================================

@dataclass
class QueryConfig:
    """Configuration d'une requête à tester."""
    name: str                    # Nom court (ex: "df_main")
    original_file: str           # Nom du fichier SQL original
    corrected_file: str          # Nom du fichier SQL corrigé
    description: str             # Description de la requête
    corrections: list[str]       # Liste des corrections appliquées


# Liste des 9 requêtes à comparer
QUERIES_CONFIG = [
    QueryConfig(
        name="unfiltered_df_main",
        original_file="query_starburst_unfiltered_df_main.sql",
        corrected_file="query_starburst_unfiltered_df_main_corrected.sql",
        description="Extraction des données entreprises (RP + RC + Groupes d'Affaires)",
        corrections=["#5: UNION → UNION ALL", "#7: DISTINCT excessifs supprimés"]
    ),
    QueryConfig(
        name="soldes",
        original_file="query_starburst_soldes.sql",
        corrected_file="query_starburst_soldes_corrected.sql",
        description="Extraction des soldes de comptes à vue",
        corrections=["#2: Alias i_uniq_ttlre dupliqué", "#4: Partition pruning (YEAR/MONTH/DAY)"]
    ),
    QueryConfig(
        name="reboot",
        original_file="query_starburst_reboot.sql",
        corrected_file="query_starburst_reboot_corrected.sql",
        description="Extraction des scores REBOOT (notation interne)",
        corrections=["#3: ORDER BY dans CTE supprimé", "#4: Partition pruning"]
    ),
    QueryConfig(
        name="transac",
        original_file="query_starburst_transac.sql",
        corrected_file="query_starburst_transac_corrected.sql",
        description="Extraction des transactions bancaires (6 mois)",
        corrections=["#1: LIKE avec | → OR", "#6: Window functions → GROUP BY"]
    ),
    QueryConfig(
        name="rsc",
        original_file="query_starburst_rsc.sql",
        corrected_file="query_starburst_rsc_corrected.sql",
        description="Extraction des indicateurs RSC (jours de dépassement)",
        corrections=["#10: Filtre périmètre PDO + agrégation MAX"]
    ),
    QueryConfig(
        name="safir_cc",
        original_file="query_starburst_safir_cc.sql",
        corrected_file="query_starburst_safir_cc_corrected.sql",
        description="SAFIR Consolidé - Caractéristiques (métadonnées bilans)",
        corrections=["#13: Mapping périmètre PDO", "#15: Bilan le plus récent"]
    ),
    QueryConfig(
        name="safir_cd",
        original_file="query_starburst_safir_cd.sql",
        corrected_file="query_starburst_safir_cd_corrected.sql",
        description="SAFIR Consolidé - Détail (postes comptables)",
        corrections=["#11: Filtre d_der_maj", "#13: Mapping périmètre PDO"]
    ),
    QueryConfig(
        name="safir_sc",
        original_file="query_starburst_safir_sc.sql",
        corrected_file="query_starburst_safir_sc_corrected.sql",
        description="SAFIR Social - Caractéristiques (métadonnées bilans)",
        corrections=["#14: Jointure extract_date", "#15: Bilan le plus récent", "#16: Typo"]
    ),
    QueryConfig(
        name="safir_sd",
        original_file="query_starburst_safir_sd.sql",
        corrected_file="query_starburst_safir_sd_corrected.sql",
        description="SAFIR Social - Détail (postes comptables)",
        corrections=["#12: Filtre d_der_maj", "#14: Jointure extract_date"]
    ),
]


# =============================================================================
# CLASSES DE RÉSULTATS
# =============================================================================

@dataclass
class QueryResult:
    """Résultat de l'exécution d'une requête."""
    success: bool
    duration_seconds: float
    row_count: int
    column_count: int
    dataframe: Optional[pl.DataFrame]
    error_message: Optional[str] = None
    
    @property
    def duration_formatted(self) -> str:
        """Retourne la durée formatée."""
        if self.duration_seconds < 60:
            return f"{self.duration_seconds:.2f}s"
        elif self.duration_seconds < 3600:
            minutes = int(self.duration_seconds // 60)
            seconds = self.duration_seconds % 60
            return f"{minutes}m {seconds:.1f}s"
        else:
            hours = int(self.duration_seconds // 3600)
            minutes = int((self.duration_seconds % 3600) // 60)
            return f"{hours}h {minutes}m"


@dataclass
class ComparisonResult:
    """Résultat de la comparaison entre deux requêtes."""
    query_name: str
    original: QueryResult
    corrected: QueryResult
    
    @property
    def speedup(self) -> float:
        """Calcule le facteur d'accélération."""
        if self.corrected.duration_seconds > 0:
            return self.original.duration_seconds / self.corrected.duration_seconds
        return 0
    
    @property
    def row_diff(self) -> int:
        """Différence de nombre de lignes."""
        return self.corrected.row_count - self.original.row_count
    
    @property
    def row_diff_percent(self) -> float:
        """Différence de nombre de lignes en pourcentage."""
        if self.original.row_count > 0:
            return (self.row_diff / self.original.row_count) * 100
        return 0


# =============================================================================
# FONCTIONS UTILITAIRES
# =============================================================================

def execute_and_measure(
    connector: StarburstConnector, 
    query: str,
    query_name: str
) -> QueryResult:
    """
    Exécute une requête et mesure les performances.
    
    Args:
        connector: Instance de StarburstConnector
        query: Requête SQL
        query_name: Nom de la requête (pour les logs)
        
    Returns:
        QueryResult avec les métriques
    """
    logger.info(f"Exécution de la requête : {query_name}")
    start_time = time.time()
    
    try:
        df = connector.query(query)
        duration = time.time() - start_time
        
        logger.info(f"Requête {query_name} terminée en {duration:.2f}s - {df.height} lignes")
        
        return QueryResult(
            success=True,
            duration_seconds=duration,
            row_count=df.height,
            column_count=df.width,
            dataframe=df
        )
        
    except Exception as e:
        duration = time.time() - start_time
        logger.error(f"Erreur sur {query_name}: {e}")
        
        return QueryResult(
            success=False,
            duration_seconds=duration,
            row_count=0,
            column_count=0,
            dataframe=None,
            error_message=str(e)
        )


def print_separator(char: str = "=", length: int = 80) -> None:
    """Affiche un séparateur."""
    print(char * length)


def print_header(title: str) -> None:
    """Affiche un en-tête."""
    print_separator()
    print(f"  {title}")
    print_separator()


def print_dataframe_preview(df: Optional[pl.DataFrame], title: str, max_rows: int = 5) -> None:
    """
    Affiche un aperçu du DataFrame.
    
    Args:
        df: DataFrame à afficher
        title: Titre de l'aperçu
        max_rows: Nombre maximum de lignes à afficher
    """
    if df is None or df.is_empty():
        print(f"\n{title}: (aucune donnée)")
        return
    
    print(f"\n{title} ({df.height:,} lignes, {df.width} colonnes)")
    print("-" * 60)
    
    # Afficher avec la configuration Polars
    with pl.Config(
        tbl_rows=max_rows,
        tbl_cols=10,
        fmt_str_lengths=30,
        tbl_width_chars=120
    ):
        print(df.head(max_rows))


def compare_single_query(
    connector: StarburstConnector,
    config: QueryConfig,
    sql_original_path: str = "common/sql/queries",
    sql_corrected_path: str = "common/sql/queries_corrected"
) -> ComparisonResult:
    """
    Compare une requête originale avec sa version corrigée.
    
    Args:
        connector: Instance de StarburstConnector
        config: Configuration de la requête
        sql_original_path: Chemin des fichiers SQL originaux
        sql_corrected_path: Chemin des fichiers SQL corrigés
        
    Returns:
        ComparisonResult avec les métriques comparées
    """
    print(f"\n")
    print_header(f"📊 {config.name.upper()}")
    print(f"  Description: {config.description}")
    print(f"  Corrections: {', '.join(config.corrections)}")
    print_separator("-")
    
    # Chargement des requêtes avec retrieve_sql_query (fonction existante du projet)
    try:
        original_sql = retrieve_sql_query(config.original_file, path=sql_original_path)
        corrected_sql = retrieve_sql_query(config.corrected_file, path=sql_corrected_path)
    except FileNotFoundError as e:
        logger.error(f"Fichier non trouvé: {e}")
        raise
    
    # Exécution de la requête originale
    print("\n▶ Exécution requête ORIGINALE...")
    original_result = execute_and_measure(
        connector, 
        original_sql, 
        f"{config.name}_original"
    )
    
    if original_result.success:
        print(f"  ✓ Original: {original_result.row_count:,} lignes en {original_result.duration_formatted}")
    else:
        print(f"  ✗ Original: ERREUR - {original_result.error_message}")
    
    # Exécution de la requête corrigée
    print("\n▶ Exécution requête CORRIGÉE...")
    corrected_result = execute_and_measure(
        connector, 
        corrected_sql, 
        f"{config.name}_corrected"
    )
    
    if corrected_result.success:
        print(f"  ✓ Corrigé: {corrected_result.row_count:,} lignes en {corrected_result.duration_formatted}")
    else:
        print(f"  ✗ Corrigé: ERREUR - {corrected_result.error_message}")
    
    return ComparisonResult(
        query_name=config.name,
        original=original_result,
        corrected=corrected_result
    )


def display_comparison_table(result: ComparisonResult, config: QueryConfig) -> None:
    """
    Affiche un tableau de comparaison des résultats.
    
    Args:
        result: Résultat de la comparaison
        config: Configuration de la requête
    """
    print(f"\n📈 COMPARAISON : {config.name}")
    print("-" * 70)
    print(f"{'Métrique':<25} {'Original':>15} {'Corrigé':>15} {'Différence':>15}")
    print("-" * 70)
    
    # Durée
    if result.speedup >= 1:
        speedup_text = f"↓ {result.speedup:.1f}x plus rapide"
    else:
        speedup_text = f"↑ {1/result.speedup:.1f}x plus lent"
    
    print(f"{'⏱️  Durée':<25} {result.original.duration_formatted:>15} {result.corrected.duration_formatted:>15} {speedup_text:>15}")
    
    # Nombre de lignes
    if result.row_diff == 0:
        row_diff_text = "= Identique"
    elif result.row_diff > 0:
        row_diff_text = f"+{result.row_diff:,} ({result.row_diff_percent:+.1f}%)"
    else:
        row_diff_text = f"{result.row_diff:,} ({result.row_diff_percent:+.1f}%)"
    
    print(f"{'📊 Lignes':<25} {result.original.row_count:>15,} {result.corrected.row_count:>15,} {row_diff_text:>15}")
    
    # Nombre de colonnes
    col_diff = result.corrected.column_count - result.original.column_count
    col_diff_text = "= Identique" if col_diff == 0 else f"{col_diff:+d}"
    
    print(f"{'📋 Colonnes':<25} {result.original.column_count:>15} {result.corrected.column_count:>15} {col_diff_text:>15}")
    print("-" * 70)
    
    # Corrections appliquées
    print("\n🔧 Corrections appliquées :")
    for correction in config.corrections:
        print(f"   • {correction}")


def display_final_summary(results: list[ComparisonResult]) -> None:
    """
    Affiche le résumé final de toutes les comparaisons.
    
    Args:
        results: Liste des résultats de comparaison
    """
    print("\n")
    print_header("📊 RÉSUMÉ FINAL DES COMPARAISONS")
    
    print(f"\n{'Requête':<20} {'Original':>12} {'Corrigé':>12} {'Speedup':>12} {'Δ Lignes':>15} {'Status':>8}")
    print("=" * 85)
    
    total_original_time = 0
    total_corrected_time = 0
    
    for result in results:
        total_original_time += result.original.duration_seconds
        total_corrected_time += result.corrected.duration_seconds
        
        # Speedup
        if result.speedup >= 1.5:
            speedup_text = f"{result.speedup:.1f}x ⚡"
        elif result.speedup >= 1:
            speedup_text = f"{result.speedup:.1f}x"
        else:
            speedup_text = f"{result.speedup:.1f}x ⚠️"
        
        # Différence de lignes
        if result.row_diff == 0:
            row_diff_text = "=0"
        elif abs(result.row_diff_percent) < 1:
            row_diff_text = f"{result.row_diff:+,}"
        else:
            row_diff_text = f"{result.row_diff:+,} ({result.row_diff_percent:+.1f}%)"
        
        # Status
        if result.original.success and result.corrected.success:
            status = "✓"
        else:
            status = "✗"
        
        print(f"{result.query_name:<20} {result.original.duration_formatted:>12} {result.corrected.duration_formatted:>12} {speedup_text:>12} {row_diff_text:>15} {status:>8}")
    
    # Ligne de total
    print("-" * 85)
    total_speedup = total_original_time / total_corrected_time if total_corrected_time > 0 else 0
    print(f"{'TOTAL':<20} {total_original_time:>11.1f}s {total_corrected_time:>11.1f}s {total_speedup:>11.1f}x {'':>15} {'':>8}")
    
    # Statistiques globales
    print(f"\n📈 Statistiques globales :")
    print(f"   • Temps total original : {total_original_time:.1f}s")
    print(f"   • Temps total corrigé : {total_corrected_time:.1f}s")
    time_saved = total_original_time - total_corrected_time
    time_saved_percent = (time_saved / total_original_time * 100) if total_original_time > 0 else 0
    print(f"   • Gain de temps : {time_saved:.1f}s ({time_saved_percent:.1f}%)")


# =============================================================================
# MAIN (même pattern que batch.py)
# =============================================================================

def main(
    queries_to_run: Optional[list[str]] = None,
    sql_original_path: str = "common/sql/queries",
    sql_corrected_path: str = "common/sql/queries_corrected",
    show_preview: bool = True
) -> None:
    """
    Point d'entrée principal du script.
    
    Args:
        queries_to_run: Liste des noms de requêtes à exécuter (None = toutes)
        sql_original_path: Chemin des fichiers SQL originaux
        sql_corrected_path: Chemin des fichiers SQL corrigés
        show_preview: Afficher un aperçu des données
    """
    # ==========================================================================
    # ÉTAPE 1 : Configuration du logger (comme batch.py ligne 79)
    # ==========================================================================
    configure_logger()
    
    print_header("🔍 COMPARAISON DES REQUÊTES SQL - Projet PDO")
    print(f"  Date : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  Répertoire SQL original : {sql_original_path}")
    print(f"  Répertoire SQL corrigé : {sql_corrected_path}")
    
    # Filtrer les requêtes si spécifié
    queries = QUERIES_CONFIG
    if queries_to_run:
        queries = [q for q in queries if q.name in queries_to_run]
        print(f"  Requêtes sélectionnées : {', '.join(queries_to_run)}")
    else:
        print(f"  Requêtes : toutes ({len(queries)})")
    
    # ==========================================================================
    # ÉTAPE 2 : Chargement des configurations (comme batch.py lignes 63, 81)
    # ==========================================================================
    print("\n")
    print_header("🔐 INITIALISATION CONNEXION")
    
    logger.info("Chargement des variables d'environnement...")
    load_service_config_file()
    
    # ==========================================================================
    # ÉTAPE 3 : Initialisation Vault (comme batch.py lignes 91-94)
    # ==========================================================================
    logger.info("Chargement des credentials Vault...")
    yaml_config_path = "config/domino/starburst_dev1.yml"
    yaml_config_path_dhv2 = "config/domino/starburst_dev2.yml"
    
    VaultConnector(yaml_config_path)
    VaultConnector(yaml_config_path_dhv2)
    logger.info("Credentials Vault chargés avec succès")
    
    # ==========================================================================
    # ÉTAPE 4 : Exécution des comparaisons (comme base_transformation.py)
    # ==========================================================================
    
    results: list[ComparisonResult] = []
    
    # Utilisation du context manager (comme base_transformation.py ligne 36)
    with StarburstConnector() as connector:
        logger.info("Connexion Starburst établie")
        
        for config in queries:
            try:
                result = compare_single_query(
                    connector, 
                    config, 
                    sql_original_path, 
                    sql_corrected_path
                )
                results.append(result)
                
                # Afficher la comparaison
                display_comparison_table(result, config)
                
                # Afficher les aperçus des données si demandé
                if show_preview:
                    if result.original.success:
                        print_dataframe_preview(
                            result.original.dataframe, 
                            "📄 Aperçu ORIGINAL"
                        )
                    if result.corrected.success:
                        print_dataframe_preview(
                            result.corrected.dataframe, 
                            "📄 Aperçu CORRIGÉ"
                        )
                
            except FileNotFoundError as e:
                print(f"  ✗ Fichier non trouvé: {e}")
                logger.error(f"Fichier non trouvé: {e}")
                continue
            except Exception as e:
                print(f"  ✗ Erreur sur {config.name}: {e}")
                logger.exception(f"Erreur sur {config.name}")
                continue
    
    # ==========================================================================
    # ÉTAPE 5 : Résumé final
    # ==========================================================================
    
    if results:
        display_final_summary(results)
    else:
        print("\n⚠️ Aucune comparaison effectuée")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Compare les requêtes SQL originales et corrigées pour le projet PDO"
    )
    parser.add_argument(
        "--queries",
        nargs="+",
        choices=[q.name for q in QUERIES_CONFIG],
        help="Requêtes spécifiques à exécuter (défaut: toutes)"
    )
    parser.add_argument(
        "--sql-original-path",
        default="common/sql/queries",
        help="Chemin des fichiers SQL originaux"
    )
    parser.add_argument(
        "--sql-corrected-path",
        default="common/sql/queries_corrected",
        help="Chemin des fichiers SQL corrigés"
    )
    parser.add_argument(
        "--no-preview",
        action="store_true",
        help="Ne pas afficher l'aperçu des données"
    )
    
    args = parser.parse_args()
    
    main(
        queries_to_run=args.queries,
        sql_original_path=args.sql_original_path,
        sql_corrected_path=args.sql_corrected_path,
        show_preview=not args.no_preview
    )
