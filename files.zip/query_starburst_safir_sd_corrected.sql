/*
 * =============================================================================
 * REQUÊTE CORRIGÉE : query_starburst_safir_sd_corrected.sql
 * =============================================================================
 * 
 * CORRECTIONS APPLIQUÉES :
 * ------------------------
 * #12 : Ajout du filtre sd_d_der_maj <= CURRENT_DATE (cohérence avec SC)
 *       → SC filtrait sur d_der_maj, SD non → incohérence corrigée
 * 
 * #14 : Jointure sur extract_date en plus de i_siren
 *       → Garantit la cohérence temporelle (même correction que SC)
 * 
 * #7  : DISTINCT excessifs supprimés
 *       → Gain performance
 * 
 * NOTES :
 * -------
 * - SD = Social Détail (postes comptables des bilans sociaux)
 * - Cette requête extrait les montants des postes comptables
 * - Pas de sélection du bilan le plus récent ici car on veut tous les postes
 *   (la sélection se fait dans le Python avec N_bilan_soc)
 * - Le mapping PDO était déjà présent (contrairement à CC/CD)
 * 
 * =============================================================================
 */

-------------Safir SD extraction-------------------------------------------------------
WITH safir_sd_extract AS (
SELECT 
        CAST(sd_i_kpi_siren AS VARCHAR(9)) AS i_siren, 
        DATE(sd_d_fin_excce) AS d_fin_excce_soc, 
        sd_c_code AS c_code, 
        sd_c_val AS c_val,
        sd_d_der_maj AS d_der_maj_soc,  /* AJOUT : pour le filtre #12 */
        extract_date 
FROM "cat_ap80414_ice"."ap01203_refined_view"."v_dlfapsd2_current"
WHERE sd_d_fin_excce IS NOT NULL              /* Filtre bilans incomplets */
  AND sd_d_fin_excce <= CURRENT_DATE          /* Filtre bilans trop récents */
  /* CORRECTION #12 : Ajout filtre d_der_maj pour cohérence avec SC */
  AND sd_d_der_maj <= CURRENT_DATE            /* Filtre MAJ futures */
  AND sd_d_fin_excce >= date_add('month', -24, CURRENT_DATE) /* Filtre bilans trop anciens */
),

-------------Safir mapping-------------------------------------------------------
fam197_light AS ( 
SELECT 
       w197_i_uniq_kpi_i,
       w197_c_mrche_b, 
       w197_c_etat_prsne,
       extract_date
FROM "cat_ap80414_ice"."ap00382_refined_view"."v_fam197s_current" 
WHERE w197_c_mrche_b = 'EN' AND w197_c_etat_prsne = 'C'
),

safir_mapping AS (
SELECT 
       w197_i_uniq_kpi_i AS i_uniq_kpi_i,
       w197_c_mrche_b AS c_mrche_b, 
       w197_c_etat_prsne AS c_etat_prsne,
       d1.extract_date,

       w096_i_uniq_kpi AS i_uniq_kpi,
       w096_i_intrn AS i_intrn,

       CAST(w098_i_siren AS VARCHAR(9)) AS i_siren
FROM fam197_light AS d1
LEFT JOIN "cat_ap80414_ice"."ap00382_refined_view"."v_fam096s_current" AS f2 
    ON d1.w197_i_uniq_kpi_i = f2.w096_i_uniq_kpi_i AND d1.extract_date = f2.extract_date
LEFT JOIN "cat_ap80414_ice"."ap00382_refined_view"."v_fam098s_current" AS f3 
    ON d1.w197_i_uniq_kpi_i = f3.w098_i_uniq_kpi_i AND d1.extract_date = f3.extract_date
WHERE w096_i_intrn IS NOT NULL AND w096_i_uniq_kpi IS NOT NULL
)

-------------Safir SD-------------------------------------------------------
SELECT 
       safir_sd_extract.i_siren, 
       safir_sd_extract.d_fin_excce_soc, 
       safir_sd_extract.c_code, 
       safir_sd_extract.c_val,

       safir_mapping.i_uniq_kpi_i,
       safir_mapping.c_mrche_b,
       safir_mapping.c_etat_prsne,
       safir_mapping.i_uniq_kpi,
       safir_mapping.i_intrn
FROM safir_sd_extract
/* Note: Jointure sur SIREN uniquement car les extract_date SAFIR et FAM sont différentes */
INNER JOIN safir_mapping ON safir_sd_extract.i_siren = safir_mapping.i_siren
