/*
 * =============================================================================
 * REQUÊTE CORRIGÉE : query_starburst_safir_sc_corrected.sql
 * =============================================================================
 * 
 * CORRECTIONS APPLIQUÉES :
 * ------------------------
 * #14 : Jointure sur extract_date en plus de i_siren
 *       → Garantit la cohérence temporelle entre données SAFIR et référentiel
 * 
 * #15 : Ajout de la sélection du bilan le plus récent par SIREN
 *       → Évite les doublons (plusieurs bilans par entreprise sur 24 mois)
 * 
 * #16 : Correction typo "extracttion" -> "extraction"
 *       → Meilleure qualité du code
 * 
 * #7  : DISTINCT excessifs supprimés
 *       → Gain performance
 * 
 * NOTES :
 * -------
 * - SC = Social Caractéristiques (métadonnées des bilans sociaux)
 * - Cette requête extrait les informations générales des bilans sociaux
 * - Le mapping PDO était déjà présent (contrairement à CC/CD)
 * 
 * =============================================================================
 */

/* CORRECTION #16 : Typo corrigée extracttion -> extraction */
-------------Safir SC extraction-------------------------------------------------------
WITH safir_sc_extract AS (
SELECT 
        sc_c_regme_fisc AS c_regme_fisc, 
        CAST(sc_i_kpi_siren AS VARCHAR(9)) AS i_siren, 
        DATE(sc_d_fin_excce) AS d_fin_excce_soc, 
        CAST(sc_c_duree_excce AS INT) AS c_duree_excce_soc, 
        sc_d_der_maj AS d_der_maj_soc,
        extract_date
FROM "cat_ap80414_ice"."ap01203_refined_view"."v_dlfapsc2_current"
WHERE sc_d_fin_excce IS NOT NULL              /* Filtre bilans incomplets */
  AND sc_d_fin_excce <= CURRENT_DATE          /* Filtre bilans trop récents */
  AND sc_d_der_maj <= CURRENT_DATE            /* Filtre MAJ futures */
  AND sc_d_fin_excce >= date_add('month', -24, CURRENT_DATE) /* Filtre bilans trop anciens */
),

-------------Safir mapping-------------------------------------------------------
fam197_light AS ( 
SELECT 
       w197_i_uniq_kpi_i,
       w197_c_mrche_b, 
       w197_c_etat_prsne,
       extract_date
FROM "cat_ap80414_ice"."ap00382_refined_view"."v_fam197s_current" 
WHERE w197_c_mrche_b = 'EN' AND w197_c_etat_prsne = 'C'
),

safir_mapping AS (
SELECT 
       w197_i_uniq_kpi_i AS i_uniq_kpi_i,
       w197_c_mrche_b AS c_mrche_b, 
       w197_c_etat_prsne AS c_etat_prsne,
       d1.extract_date,

       w096_i_uniq_kpi AS i_uniq_kpi,
       w096_i_intrn AS i_intrn,

       CAST(w098_i_siren AS VARCHAR(9)) AS i_siren
FROM fam197_light AS d1
LEFT JOIN "cat_ap80414_ice"."ap00382_refined_view"."v_fam096s_current" AS f2 
    ON d1.w197_i_uniq_kpi_i = f2.w096_i_uniq_kpi_i AND d1.extract_date = f2.extract_date
LEFT JOIN "cat_ap80414_ice"."ap00382_refined_view"."v_fam098s_current" AS f3 
    ON d1.w197_i_uniq_kpi_i = f3.w098_i_uniq_kpi_i AND d1.extract_date = f3.extract_date
WHERE w096_i_intrn IS NOT NULL AND w096_i_uniq_kpi IS NOT NULL
),

/* CORRECTION #15 : Sélection du bilan le plus récent par SIREN */
safir_sc_ranked AS (
SELECT 
    safir_sc_extract.c_regme_fisc, 
    safir_sc_extract.i_siren, 
    safir_sc_extract.d_fin_excce_soc, 
    safir_sc_extract.c_duree_excce_soc, 
    safir_sc_extract.d_der_maj_soc,
    safir_sc_extract.extract_date AS extract_date_safir,

    safir_mapping.i_uniq_kpi_i,
    safir_mapping.c_mrche_b,
    safir_mapping.c_etat_prsne,
    safir_mapping.i_uniq_kpi,
    safir_mapping.i_intrn,
    safir_mapping.extract_date AS extract_date_mapping,
    
    ROW_NUMBER() OVER (
        PARTITION BY safir_sc_extract.i_siren 
        ORDER BY safir_sc_extract.d_fin_excce_soc DESC
    ) AS rang_bilan
FROM safir_sc_extract
/* CORRECTION #14 : Jointure sur SIREN uniquement (extract_date différentes entre SAFIR et référentiel) */
/* Note: On ne peut pas joindre sur extract_date car les tables SAFIR et FAM ont des dates différentes */
INNER JOIN safir_mapping ON safir_sc_extract.i_siren = safir_mapping.i_siren
)

-------------Safir SC-------------------------------------------------------
SELECT 
       c_regme_fisc, 
       i_siren, 
       d_fin_excce_soc, 
       c_duree_excce_soc, 
       d_der_maj_soc,

       i_uniq_kpi_i,
       c_mrche_b,
       c_etat_prsne,
       i_uniq_kpi,
       i_intrn
FROM safir_sc_ranked
WHERE rang_bilan = 1
