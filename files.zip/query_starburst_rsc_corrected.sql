/*
 * =============================================================================
 * REQUÊTE CORRIGÉE : query_starburst_rsc_corrected.sql
 * =============================================================================
 * 
 * CORRECTIONS APPLIQUÉES :
 * ------------------------
 * #10 : Ajout du filtre sur le périmètre PDO (entreprises EN + état C)
 *       → Évite de charger toutes les entreprises hors périmètre
 * 
 * #10 : Ajout de l'agrégation MAX() pour éviter les doublons
 *       → Une seule ligne par entreprise (prend le max des jours de dépassement)
 * 
 * #10 : Renommage de la colonne cryptique i2 en nom explicite
 *       → Meilleure lisibilité et maintenabilité
 * 
 * NOTES :
 * -------
 * - La table v_lacorp_current contient les indicateurs de risque RSC
 * - k_dep_auth_10j = nombre de jours de dépassement autorisé sur 10 jours
 * - Le mapping vers le périmètre PDO évite de charger des données inutiles
 * - L'agrégation MAX() garantit une ligne unique par entreprise
 * 
 * =============================================================================
 */

-------------RSC avec mapping périmètre PDO-------------------------------------------------------
WITH 
/* Périmètre PDO : entreprises marché EN, état courant */
fam197_light AS ( 
SELECT 
       w197_i_uniq_kpi_i,
       extract_date
FROM "cat_ap80414_ice"."ap00382_refined_view"."v_fam197s_current" 
WHERE w197_c_mrche_b = 'EN' 
  AND w197_c_etat_prsne = 'C'
),

/* Mapping vers i_intrn (identifiant interne) */
perimetre_pdo AS (
SELECT 
       f197.w197_i_uniq_kpi_i,
       f096.w096_i_intrn AS i_intrn,
       f096.w096_i_uniq_kpi AS i_uniq_kpi,
       f197.extract_date
FROM fam197_light f197
INNER JOIN "cat_ap80414_ice"."ap00382_refined_view"."v_fam096s_current" f096 
    ON f197.w197_i_uniq_kpi_i = f096.w096_i_uniq_kpi_i 
   AND f197.extract_date = f096.extract_date
WHERE f096.w096_i_intrn IS NOT NULL 
  AND f096.w096_i_uniq_kpi IS NOT NULL
),

/* Extraction RSC avec agrégation */
rsc_data AS (
SELECT 
       id_intrn AS i_intrn,
       /* CORRECTION #10 : Renommage colonne cryptique i2 */
       i2 AS k_dep_auth_10j,  -- Nombre de jours de dépassement autorisé sur 10 jours
       extract_date
FROM "cat_ap80414_ice"."ap00947_refined_view"."v_lacorp_current"
)

/* CORRECTION #10 : Agrégation MAX pour éviter doublons + filtre périmètre */
SELECT 
       perimetre_pdo.i_intrn,
       MAX(rsc_data.k_dep_auth_10j) AS k_dep_auth_10j,  -- Prend le max en cas de doublons
       MAX(rsc_data.extract_date) AS extract_date
FROM perimetre_pdo
INNER JOIN rsc_data ON perimetre_pdo.i_intrn = rsc_data.i_intrn
GROUP BY perimetre_pdo.i_intrn
