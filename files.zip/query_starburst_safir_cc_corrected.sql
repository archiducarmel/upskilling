/*
 * =============================================================================
 * REQUÊTE CORRIGÉE : query_starburst_safir_cc_corrected.sql
 * =============================================================================
 * 
 * CORRECTIONS APPLIQUÉES :
 * ------------------------
 * #13 : Ajout du mapping vers le périmètre PDO (comme SC et SD)
 *       → Cohérence avec les autres requêtes SAFIR
 *       → Évite de charger des bilans hors périmètre
 * 
 * #15 : Ajout de la sélection du bilan le plus récent par SIREN
 *       → Évite les doublons (plusieurs bilans par entreprise sur 24 mois)
 * 
 * NOTES :
 * -------
 * - CC = Comptes Consolidés (caractéristiques)
 * - Cette requête extrait les métadonnées des bilans consolidés
 * - Le filtre sur 24 mois peut retourner plusieurs bilans par entreprise
 * - ROW_NUMBER permet de ne garder que le plus récent
 * 
 * =============================================================================
 */

-------------Safir CC avec mapping périmètre PDO-------------------------------------------------------
WITH 
/* Périmètre PDO : entreprises marché EN, état courant */
fam197_light AS ( 
SELECT 
       w197_i_uniq_kpi_i,
       extract_date
FROM "cat_ap80414_ice"."ap00382_refined_view"."v_fam197s_current" 
WHERE w197_c_mrche_b = 'EN' 
  AND w197_c_etat_prsne = 'C'
),

/* CORRECTION #13 : Mapping vers SIREN pour filtrer sur périmètre PDO */
safir_mapping AS (
SELECT 
       w197_i_uniq_kpi_i AS i_uniq_kpi_i,
       f197.extract_date,
       w096_i_uniq_kpi AS i_uniq_kpi,
       w096_i_intrn AS i_intrn,
       CAST(w098_i_siren AS VARCHAR(9)) AS i_siren
FROM fam197_light f197
LEFT JOIN "cat_ap80414_ice"."ap00382_refined_view"."v_fam096s_current" f096 
    ON f197.w197_i_uniq_kpi_i = f096.w096_i_uniq_kpi_i 
   AND f197.extract_date = f096.extract_date
LEFT JOIN "cat_ap80414_ice"."ap00382_refined_view"."v_fam098s_current" f098 
    ON f197.w197_i_uniq_kpi_i = f098.w098_i_uniq_kpi_i 
   AND f197.extract_date = f098.extract_date
WHERE w096_i_intrn IS NOT NULL 
  AND w096_i_uniq_kpi IS NOT NULL
),

/* Extraction des bilans consolidés */
safir_cc_extract AS (
SELECT 
        cc_c_nture_excce AS c_nture_excce,
        CAST(cc_i_kpi_siren AS VARCHAR(9)) AS i_siren,
        DATE(cc_d_fin_excce) AS d_fin_excce_conso, 
        CAST(cc_c_duree_excce AS INT) AS c_duree_excce_conso, 
        DATE(cc_d_der_maj) AS d_der_maj_conso,
        extract_date
FROM "cat_ap80414_ice"."ap01203_refined_view"."v_dlfapcc1_current"
WHERE cc_d_fin_excce IS NOT NULL 
  AND cc_d_fin_excce <= CURRENT_DATE           /* Filtre bilans trop récents */
  AND cc_d_der_maj <= CURRENT_DATE             /* Filtre MAJ futures */
  AND cc_d_fin_excce >= date_add('month', -24, CURRENT_DATE) /* Filtre bilans trop anciens */
),

/* CORRECTION #15 : Sélection du bilan le plus récent par SIREN */
safir_cc_ranked AS (
SELECT 
    safir_cc_extract.*,
    safir_mapping.i_uniq_kpi_i,
    safir_mapping.i_uniq_kpi,
    safir_mapping.i_intrn,
    ROW_NUMBER() OVER (
        PARTITION BY safir_cc_extract.i_siren 
        ORDER BY safir_cc_extract.d_fin_excce_conso DESC
    ) AS rang_bilan
FROM safir_cc_extract
INNER JOIN safir_mapping ON safir_cc_extract.i_siren = safir_mapping.i_siren
)

/* Retourner uniquement le bilan le plus récent par SIREN */
SELECT 
    c_nture_excce,
    i_siren,
    d_fin_excce_conso, 
    c_duree_excce_conso, 
    d_der_maj_conso,
    extract_date,
    i_uniq_kpi_i,
    i_uniq_kpi,
    i_intrn
FROM safir_cc_ranked
WHERE rang_bilan = 1
