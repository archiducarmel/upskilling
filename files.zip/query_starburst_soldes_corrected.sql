/*
 * =============================================================================
 * REQUÊTE CORRIGÉE : query_starburst_soldes_corrected.sql
 * =============================================================================
 * 
 * CORRECTIONS APPLIQUÉES :
 * ------------------------
 * #2 : Alias i_uniq_ttlre défini deux fois (lignes 49 et 52) - suppression doublon
 *      → Corrige une perte de données silencieuse
 * 
 * #4 : YEAR(extract_date) = YEAR(CURRENT_DATE) remplacé par filtre sur plage
 *      → Permet le partition pruning Iceberg (~30x plus rapide)
 * 
 * #7 : DISTINCT excessifs supprimés
 *      → Gain performance ~5-10%
 * 
 * NOTES :
 * -------
 * - Le filtre sur extract_date utilise maintenant DATE_TRUNC pour permettre
 *   à Iceberg de ne scanner que les partitions du mois en cours
 * - L'alias i_uniq_ttlre n'était défini qu'une fois (la 2ème écrasait la 1ère)
 * 
 * =============================================================================
 */

-------------Soldes extractions-------------------------------------------------------
WITH extract_date_max AS (
/* CORRECTION #4 : Filtre optimisé pour partition pruning */
SELECT max(extract_date) AS extract_date_max
FROM "cat_ap80414_ice"."ap00325_refined_view"."v_btiasld2_detail"
WHERE extract_date >= DATE_TRUNC('month', CURRENT_DATE)  -- Début du mois en cours
  AND extract_date <= CURRENT_DATE                        -- Jusqu'à aujourd'hui
  AND DAY(extract_date) <= 5                              -- Seulement les 5 premiers jours
),
/* utiliser les données soldes du 5 ou dernières données dispo avant le 05 */

soldes_extract AS (
SELECT 
       pref_i_uniq_cpt,
       pref_m_ctrvl_sld_arr,
       pref_c_type_cntrt,
       extract_date
FROM "cat_ap80414_ice"."ap00325_refined_view"."v_btiasld2_detail"
WHERE pref_c_type_cntrt = '101' 
AND extract_date = (SELECT extract_date_max FROM extract_date_max)
),

-------------Soldes mapping-------------------------------------------------------
fam197_light AS ( 
SELECT 
       w197_i_uniq_kpi_i,
       w197_c_mrche_b, 
       w197_c_etat_prsne,
       extract_date
FROM "cat_ap80414_ice"."ap00382_refined_view"."v_fam197s_current" 
WHERE w197_c_mrche_b='EN' AND w197_c_etat_prsne='C'
),

rmpm_mapping AS (
SELECT 
       w197_i_uniq_kpi_i AS i_uniq_kpi_i,
       w197_c_mrche_b AS c_mrche_b, 
       w197_c_etat_prsne AS c_etat_prsne,
       d1.extract_date,

       w096_i_uniq_kpi AS i_uniq_kpi,
       w096_i_intrn AS i_intrn,
       w096_c_njur_prsne AS c_njur_prsne
FROM fam197_light AS d1
LEFT JOIN "cat_ap80414_ice"."ap00382_refined_view"."v_fam096s_current" AS f2 ON (d1.w197_i_uniq_kpi_i = f2.w096_i_uniq_kpi_i AND d1.extract_date = f2.extract_date)
WHERE w096_i_intrn IS NOT NULL AND w096_i_uniq_kpi IS NOT NULL
),

/* CORRECTION #2 : Suppression du doublon d'alias i_uniq_ttlre */
titulaire_mapping AS (
SELECT 
       w161_i_uniq_kac_intne AS pref_i_uniq_cpt,
       w161_i_uniq_ttlre AS i_uniq_ttlre,  -- Gardé : lien compte -> titulaire
       w165_i_uniq_kpi_membr AS i_uniq_kpi  -- CORRECTION : était "i_uniq_ttlre" (doublon)
       -- w165_i_uniq_tit non nécessaire car redondant avec w161_i_uniq_ttlre via la jointure
FROM "cat_ap80414_ice"."ap00382_refined_view"."v_fam161s_current" AS d1
INNER JOIN "cat_ap80414_ice"."ap00382_refined_view"."v_fam165s_current" AS f2 ON (d1."w161_i_uniq_ttlre" = f2."w165_i_uniq_tit" AND d1."extract_date" = f2."extract_date")
),

soldes_mapping AS (
SELECT 
       rmpm_mapping.i_uniq_kpi_i,
       rmpm_mapping.c_mrche_b,
       rmpm_mapping.c_etat_prsne,
       rmpm_mapping.i_uniq_kpi,
       rmpm_mapping.i_intrn,
       rmpm_mapping.c_njur_prsne,

       titulaire_mapping.pref_i_uniq_cpt
FROM rmpm_mapping
INNER JOIN titulaire_mapping ON (rmpm_mapping.i_uniq_kpi = titulaire_mapping.i_uniq_kpi)
)

-------------Soldes-------------------------------------------------------
SELECT DISTINCT
       soldes_extract.pref_i_uniq_cpt,
       soldes_extract.pref_m_ctrvl_sld_arr,
       soldes_extract.pref_c_type_cntrt,

       soldes_mapping.i_uniq_kpi_i,
       soldes_mapping.c_mrche_b,
       soldes_mapping.c_etat_prsne,
       soldes_mapping.i_uniq_kpi,
       soldes_mapping.i_intrn,
       soldes_mapping.c_njur_prsne
FROM soldes_extract
INNER JOIN soldes_mapping ON soldes_extract.pref_i_uniq_cpt = soldes_mapping.pref_i_uniq_cpt
