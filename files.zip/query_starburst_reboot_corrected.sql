/*
 * =============================================================================
 * REQUÊTE CORRIGÉE : query_starburst_reboot_corrected.sql
 * =============================================================================
 * 
 * CORRECTIONS APPLIQUÉES :
 * ------------------------
 * #3 : ORDER BY dans le CTE supprimé (ignoré par SQL, code mort)
 *      → Code plus clair, pas d'impact fonctionnel
 * 
 * #4 : YEAR(d_histo) = YEAR(CURRENT_DATE) remplacé par filtre sur plage
 *      → Permet le partition pruning (~30x plus rapide)
 * 
 * #7 : DISTINCT excessifs supprimés
 *      → Gain performance ~5-10%
 * 
 * NOTES :
 * -------
 * - Le ORDER BY dans le CTE était ignoré car SQL ne garantit pas l'ordre
 *   dans les CTEs. Le max(d_not) est correctement calculé dans d_note_max.
 * - Les filtres sur d_histo utilisent maintenant DATE_TRUNC pour le 
 *   partition pruning
 * 
 * =============================================================================
 */

-------------Histo notes-------------------------------------------------------
WITH extract_histo_notes AS (
SELECT 
       d_histo,
       i_uniq_kpi,
       c_int_modele,
       d_not,
       d_rev_notation,
       c_not,
       c_type_prsne,
       b_bddf_gestionnaire,
       extract_date
FROM "cat_ap80414_ice"."ap01202_refined_view"."v_hisnot"
/* CORRECTION #4 : Filtre optimisé pour partition pruning */
WHERE d_histo >= DATE_TRUNC('month', CURRENT_DATE)  -- Début du mois en cours
  AND d_histo <= CURRENT_DATE                        -- Jusqu'à aujourd'hui
  AND b_bddf_gestionnaire = 'O'
  AND c_int_modele IN ('011', '111', '012', '112', '013', '113')
/* CORRECTION #3 : ORDER BY supprimé - était ignoré dans un CTE */
),

d_note_max AS (
SELECT 
       i_uniq_kpi,
       max(d_not) AS d_not_max
FROM extract_histo_notes
GROUP BY i_uniq_kpi
),

histo_notes AS (
SELECT 
       extract_histo_notes.d_histo,
       extract_histo_notes.i_uniq_kpi,
       extract_histo_notes.c_int_modele,
       extract_histo_notes.d_not,
       extract_histo_notes.d_rev_notation,
       extract_histo_notes.c_not,
       extract_histo_notes.c_type_prsne,
       extract_histo_notes.b_bddf_gestionnaire,
       extract_histo_notes.extract_date
FROM extract_histo_notes
INNER JOIN d_note_max ON extract_histo_notes.i_uniq_kpi = d_note_max.i_uniq_kpi 
                      AND extract_histo_notes.d_not = d_note_max.d_not_max
/* Note: WHERE d_not = d_not_max redondant avec la condition de jointure, supprimé */
),

-------------Histo drivers-------------------------------------------------------
histo_drivers AS (
SELECT 
       d_histo,                
       i_uniq_kpi,
       d_rev_modele,
       c_driver,
       c_donnee,
       c_val_donnee,
       q_score,
       extract_date
FROM "cat_ap80414_ice"."ap01202_refined_view"."v_drvnot"
/* CORRECTION #4 : Filtre optimisé pour partition pruning */
WHERE d_histo >= DATE_TRUNC('month', CURRENT_DATE)  -- Début du mois en cours
  AND d_histo <= CURRENT_DATE                        -- Jusqu'à aujourd'hui
  AND Q_SCORE != ''
  AND c_int_modele IN ('011', '111', '012', '112', '013', '113')
)

SELECT 
       histo_notes.d_histo,
       histo_notes.i_uniq_kpi,
       histo_notes.c_int_modele,
       histo_notes.d_not,
       histo_notes.d_rev_notation,
       histo_notes.c_not,
       histo_notes.c_type_prsne,
       histo_notes.b_bddf_gestionnaire,
    
       histo_drivers.d_rev_modele,
       histo_drivers.c_driver,
       histo_drivers.c_donnee,
       histo_drivers.c_val_donnee,
       histo_drivers.q_score
FROM histo_notes
LEFT JOIN histo_drivers ON histo_notes.i_uniq_kpi = histo_drivers.i_uniq_kpi 
  AND histo_notes.d_rev_notation = histo_drivers.d_rev_modele
  AND histo_notes.d_histo = histo_drivers.d_histo
  AND histo_notes.extract_date = histo_drivers.extract_date
