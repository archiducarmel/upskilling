/*
 * =============================================================================
 * REQUÊTE CORRIGÉE : query_starburst_safir_cd_corrected.sql
 * =============================================================================
 * 
 * CORRECTIONS APPLIQUÉES :
 * ------------------------
 * #11 : Ajout du filtre cd_d_der_maj <= CURRENT_DATE (cohérence avec CC)
 *       → CC filtrait sur d_der_maj, CD non → incohérence corrigée
 * 
 * #13 : Ajout du mapping vers le périmètre PDO (comme SC et SD)
 *       → Cohérence avec les autres requêtes SAFIR
 *       → Évite de charger des bilans hors périmètre
 * 
 * NOTES :
 * -------
 * - CD = Comptes Consolidés Détail (données chiffrées)
 * - Cette requête extrait les postes comptables des bilans consolidés
 * - Le filtre d_der_maj évite d'avoir des MAJ datées dans le futur
 * - Pas de sélection du bilan le plus récent ici car on veut tous les postes
 *   (la sélection se fait dans le Python avec N_bilan_conso)
 * 
 * =============================================================================
 */

-------------Safir CD avec mapping périmètre PDO-------------------------------------------------------
WITH 
/* Périmètre PDO : entreprises marché EN, état courant */
fam197_light AS ( 
SELECT 
       w197_i_uniq_kpi_i,
       extract_date
FROM "cat_ap80414_ice"."ap00382_refined_view"."v_fam197s_current" 
WHERE w197_c_mrche_b = 'EN' 
  AND w197_c_etat_prsne = 'C'
),

/* CORRECTION #13 : Mapping vers SIREN pour filtrer sur périmètre PDO */
safir_mapping AS (
SELECT 
       w197_i_uniq_kpi_i AS i_uniq_kpi_i,
       f197.extract_date,
       w096_i_uniq_kpi AS i_uniq_kpi,
       w096_i_intrn AS i_intrn,
       CAST(w098_i_siren AS VARCHAR(9)) AS i_siren
FROM fam197_light f197
LEFT JOIN "cat_ap80414_ice"."ap00382_refined_view"."v_fam096s_current" f096 
    ON f197.w197_i_uniq_kpi_i = f096.w096_i_uniq_kpi_i 
   AND f197.extract_date = f096.extract_date
LEFT JOIN "cat_ap80414_ice"."ap00382_refined_view"."v_fam098s_current" f098 
    ON f197.w197_i_uniq_kpi_i = f098.w098_i_uniq_kpi_i 
   AND f197.extract_date = f098.extract_date
WHERE w096_i_intrn IS NOT NULL 
  AND w096_i_uniq_kpi IS NOT NULL
),

/* Extraction des postes comptables consolidés */
safir_cd_extract AS (
SELECT 
        CAST(cd_i_kpi_siren AS VARCHAR(9)) AS i_siren,
        DATE(cd_d_fin_excce) AS d_fin_excce_conso, 
        cd_c_code AS c_code, 
        cd_c_val AS c_val,
        extract_date 
FROM "cat_ap80414_ice"."ap01203_refined_view"."v_dlfapcd1_current"
WHERE cd_d_fin_excce IS NOT NULL 
  AND cd_d_fin_excce <= CURRENT_DATE              /* Filtre bilans trop récents */
  /* CORRECTION #11 : Ajout filtre d_der_maj pour cohérence avec CC */
  AND cd_d_der_maj <= CURRENT_DATE                /* Filtre MAJ futures */
  AND cd_d_fin_excce >= date_add('month', -24, CURRENT_DATE) /* Filtre bilans trop anciens */
)

/* CORRECTION #13 : Jointure avec périmètre PDO */
SELECT 
    safir_cd_extract.i_siren, 
    safir_cd_extract.d_fin_excce_conso, 
    safir_cd_extract.c_code, 
    safir_cd_extract.c_val,
    safir_cd_extract.extract_date,
    safir_mapping.i_uniq_kpi_i,
    safir_mapping.i_uniq_kpi,
    safir_mapping.i_intrn
FROM safir_cd_extract
INNER JOIN safir_mapping ON safir_cd_extract.i_siren = safir_mapping.i_siren
