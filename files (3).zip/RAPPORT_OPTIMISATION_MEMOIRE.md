# 📊 RAPPORT D'OPTIMISATION MÉMOIRE ET CPU - PDO Pipeline

## 🔴 SYNTHÈSE EXÉCUTIVE

Le code actuel **peut consommer jusqu'à 10x plus de mémoire** que nécessaire à cause de plusieurs anti-patterns identifiés. Avec 32 GB de RAM et un overflow, les optimisations proposées devraient ramener la consommation à **10-15 GB maximum**.

---

## 📋 PROBLÈMES IDENTIFIÉS PAR ORDRE DE CRITICITÉ

### 1. 🚨 CRITIQUE - Rétention de toutes les données sources (batch.py)

**Impact estimé**: +16-24 GB de mémoire inutile

```python
# ACTUEL - PROBLÉMATIQUE
initial_data = base_transformation.load_data()  # 8 DataFrames chargés
# ... 100 lignes plus tard, TOUT est encore en mémoire
df_main_transac = base_transformation.preprocess_donnees_transac(
    df_main_reboot,
    initial_data["donnees_transac"],  # Toujours là !
)
```

**Solution**: Libérer chaque source après utilisation avec `del` + `gc.collect()`

---

### 2. 🚨 CRITIQUE - Accumulation de DataFrames intermédiaires (batch.py)

**Impact estimé**: +8-16 GB de mémoire inutile

```python
# ACTUEL - 9 variables différentes accumulées
df_main_encoded = ...   # ~2GB
df_main_risk = ...      # ~2GB (total: 4GB)
df_main_soldes = ...    # ~2GB (total: 6GB)
df_main_reboot = ...    # ~2GB (total: 8GB)
# etc.
```

**Solution**: Réutiliser une seule variable `df_main` et ne pas créer de nouvelles références.

---

### 3. 🔴 MAJEUR - with_columns successifs (calcul_pdo.py, preprocessing_*.py)

**Impact estimé**: +2-4 GB par fichier concerné

| Fichier | Nb appels séparés | Impact |
|---------|-------------------|--------|
| calcul_pdo.py | 16 | Critique |
| preprocessing_format_variables.py | 10 | Élevé |
| preprocessing_df_main.py | 3 | Modéré |
| preprocessing_safir_soc.py | 5 | Élevé |

**Solution**: Regrouper tous les `with_columns` en un seul appel.

---

### 4. 🔴 MAJEUR - Mode Eager au lieu de Lazy

**Impact estimé**: Perte d'optimisation de 30-50%

```python
# ACTUEL (Eager) - Chaque opération exécutée immédiatement
df = df.filter(...)
df = df.with_columns(...)
df = df.join(...)

# OPTIMISÉ (Lazy) - Plan d'exécution optimisé par Polars
df = (df.lazy()
      .filter(...)
      .with_columns(...)
      .join(...)
      .collect())
```

---

### 5. 🟠 MODÉRÉ - unique() redondants après group_by

**Fichiers concernés**: preprocessing_soldes.py, preprocessing_reboot.py

```python
# INUTILE - group_by produit déjà des clés uniques
cav_values = soldes.group_by("i_intrn").agg(...)
cav_values = cav_values.unique(subset=["i_intrn"])  # ← SUPPRIMER
```

---

### 6. 🟠 MODÉRÉ - pl.DataFrame() créant des copies

**Fichier**: preprocessing_reboot.py, ligne 10

```python
# ACTUEL - Copie inutile
df_score_reboot = pl.DataFrame(reboot.group_by(...).agg(...))

# OPTIMISÉ - Pas de copie
df_score_reboot = reboot.group_by(...).agg(...)
```

---

### 7. 🟡 MINEUR - Pas de sélection précoce des colonnes

Les DataFrames transportent toutes leurs colonnes jusqu'à la fin alors que seules quelques-unes sont utilisées.

```python
# OPTIMISATION recommandée
COLS_NEEDED = ["i_uniq_kpi", "col1", "col2", ...]
df = df.select(COLS_NEEDED)  # Dès que possible
```

---

## ✅ ACTIONS CORRECTIVES PAR FICHIER

### batch.py
- [ ] Libérer chaque source de données après utilisation
- [ ] Utiliser une seule variable `df_main` au lieu de 9
- [ ] Ajouter `gc.collect()` après chaque libération

### calcul_pdo.py
- [ ] Regrouper les 16 `with_columns` en 2-3 blocs maximum

### preprocessing_format_variables.py
- [ ] Regrouper les 10 `with_columns` en 1 seul bloc

### preprocessing_transac.py
- [ ] Cast des types numériques à l'entrée
- [ ] Cast de COL1 après unpivot
- [ ] Utiliser `pl.concat_str()` au lieu de `+`

### preprocessing_soldes.py
- [ ] Combiner les deux `group_by` en un seul
- [ ] Supprimer les `unique()` redondants

### preprocessing_reboot.py
- [ ] Supprimer `pl.DataFrame()` wrapper
- [ ] Supprimer `unique()` redondant

---

## 📈 ESTIMATION DES GAINS

| Optimisation | Gain mémoire estimé |
|--------------|---------------------|
| Libération sources après usage | -16 GB |
| Réutilisation variable df_main | -8 GB |
| with_columns groupés | -4 GB |
| Mode Lazy | -2 GB |
| Autres | -2 GB |
| **TOTAL** | **~32 GB → ~10 GB** |

---

## 🔧 OPTIMISATIONS AVANCÉES (SI INSUFFISANT)

### 1. Streaming Polars pour très gros volumes
```python
# Pour des datasets > 10M lignes
df = pl.scan_parquet("data.parquet")  # Lazy par défaut
    .filter(...)
    .collect(streaming=True)  # Traitement par chunks
```

### 2. Réduction des types de données
```python
# Convertir Float64 → Float32 si précision suffisante
df = df.cast({col: pl.Float32 for col in float_cols})

# Convertir Int64 → Int32 si valeurs < 2 milliards
df = df.cast({col: pl.Int32 for col in int_cols})
```

### 3. Partitionnement des données
```python
# Traiter par batches si le dataset est trop gros
for batch in df.iter_slices(n_rows=100_000):
    process(batch)
```

### 4. Écriture intermédiaire sur disque
```python
# Sauvegarder les résultats intermédiaires
df.write_parquet("/tmp/intermediate.parquet")
del df
gc.collect()
df = pl.read_parquet("/tmp/intermediate.parquet")
```

---

## 📚 RÉFÉRENCES

- [Polars Memory Optimization Guide](https://pola-rs.github.io/polars/user-guide/concepts/memory/)
- [Polars Lazy vs Eager](https://pola-rs.github.io/polars/user-guide/concepts/lazy-vs-eager/)
- [Python Memory Management](https://docs.python.org/3/c-api/memory.html)
