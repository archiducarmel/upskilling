"""
Batch optimisé pour réduire la consommation mémoire et CPU.
Principales optimisations:
1. Libération proactive de la mémoire avec del + gc.collect()
2. Mode lazy Polars pour optimiser le plan d'exécution
3. Chargement séquentiel des données (pas tout en mémoire)
4. Sélection précoce des colonnes nécessaires
"""

import gc
import logging
import os

from ml_utils.inference_decorator import duration_request
from ml_utils.logger_helper import configure_logger
from ml_utils.vault_connector import VaultConnector

from common.base_transformation import BaseTransformation
from common.config_context import ConfigContext
from common.constants import FILE_NAME_PROJECT_CONFIG, LOGGER_NAME
from config.load_config import load_app_config_file, load_config_domino_project_file, load_service_config_file
from settings import PROJECT_ROOT
from version import __version__

logger = logging.getLogger(LOGGER_NAME)


def load_configurations() -> tuple[dict, dict]:
    """Load and return app and service configurations."""
    logger.info("Task 1: Loading configurations...")
    load_service_config_file()
    app_config = load_app_config_file()
    project_config_path = os.path.join(PROJECT_ROOT, "config", "domino", FILE_NAME_PROJECT_CONFIG)
    project_config = load_config_domino_project_file(project_config_path)
    logger.info("Task 1: Configurations loaded successfully.")
    return app_config, project_config


def free_memory(*dataframes) -> None:
    """Libère explicitement la mémoire des DataFrames."""
    for df in dataframes:
        del df
    gc.collect()
    logger.info("Memory freed after garbage collection")


@duration_request
def main() -> None:
    """Run main method for batch - VERSION OPTIMISÉE."""
    configure_logger()
    logger.info(f"Version: {__version__}")
    app_config, project_config = load_configurations()

    # Load app and services config
    config_context = ConfigContext()
    config_context.set("app_config", app_config)

    yaml_config_path = "config/domino/starburst_dev1.yml"
    yaml_config_path_dhv2 = "config/domino/starburst_dev2.yml"
    VaultConnector(yaml_config_path)
    VaultConnector(yaml_config_path_dhv2)

    # Initialize transformation pipeline
    base_transformation = BaseTransformation(app_config)
    
    # ============================================================
    # STRATÉGIE 1: Chargement séquentiel et libération immédiate
    # ============================================================
    
    # Étape 1: Charger et traiter df_main de base
    logger.info("Loading unfiltered_df_main...")
    initial_data = base_transformation.load_data()
    
    # Extraire les données nécessaires et libérer le reste progressivement
    unfiltered_df_main = initial_data["unfiltered_df_main"]
    
    preprocessed_data = base_transformation.preprocess_df_main(unfiltered_df_main)
    del unfiltered_df_main
    gc.collect()
    
    df_main = preprocessed_data["df_main"]
    del preprocessed_data  # Libérer unfiltered_df_main stocké dans preprocessed_data
    gc.collect()
    
    # Étape 2: Encoding
    logger.info("Encoding df_main...")
    df_main = base_transformation.preprocess_encoded_df_main(df_main)
    
    # Étape 3: Risk features
    logger.info("Adding risk features...")
    rsc = initial_data["rsc"]
    df_main = base_transformation.preprocess_risk(df_main, rsc)
    del rsc
    initial_data["rsc"] = None  # Libérer la référence dans le dict
    gc.collect()
    
    # Étape 4: Soldes features
    logger.info("Adding soldes features...")
    soldes = initial_data["soldes"]
    df_main = base_transformation.preprocess_soldes(df_main, soldes)
    del soldes
    initial_data["soldes"] = None
    gc.collect()
    
    # Étape 5: Reboot features
    logger.info("Adding reboot features...")
    reboot = initial_data["reboot"]
    df_main = base_transformation.preprocess_reboot(df_main, reboot)
    del reboot
    initial_data["reboot"] = None
    gc.collect()
    
    # Étape 6: Transaction features
    logger.info("Adding transaction features...")
    donnees_transac = initial_data["donnees_transac"]
    df_main = base_transformation.preprocess_donnees_transac(df_main, donnees_transac)
    del donnees_transac
    initial_data["donnees_transac"] = None
    gc.collect()
    
    # Étape 7: Safir conso features
    logger.info("Adding safir conso features...")
    safir_cc = initial_data["safir_cc"]
    safir_cd = initial_data["safir_cd"]
    df_main = base_transformation.preprocess_safir_conso(df_main, safir_cc, safir_cd)
    del safir_cc, safir_cd
    initial_data["safir_cc"] = None
    initial_data["safir_cd"] = None
    gc.collect()
    
    # Étape 8: Safir soc features
    logger.info("Adding safir soc features...")
    safir_sc = initial_data["safir_sc"]
    safir_sd = initial_data["safir_sd"]
    df_main = base_transformation.preprocess_safir_soc(df_main, safir_sc, safir_sd)
    del safir_sc, safir_sd
    initial_data["safir_sc"] = None
    initial_data["safir_sd"] = None
    gc.collect()
    
    # Libérer complètement initial_data
    del initial_data
    gc.collect()
    logger.info("All source data freed from memory")
    
    # Étape 9: Filters
    logger.info("Applying filters...")
    df_main = base_transformation.preprocess_filters(df_main)
    
    # Étape 10: Format variables
    logger.info("Formatting variables...")
    df_main = base_transformation.preprocess_format(df_main)
    
    # Étape 11: Calcul PDO
    logger.info("Computing PDO...")
    df_main = base_transformation.calcul_pdo(df_main)
    
    # Étape 12: Postprocessing
    logger.info("Postprocessing...")
    base_transformation.postprocess_df_main(df_main)
    
    logger.info("Batch completed successfully")


if __name__ == "__main__":
    main()
