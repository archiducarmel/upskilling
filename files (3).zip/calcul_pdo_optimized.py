"""
Calcul PDO optimisé - with_columns groupés pour réduire les copies mémoire.
"""
import polars as pl


def calcul_pdo(df_main_ilc: pl.DataFrame) -> pl.DataFrame:
    """Preprocess data for PDO prediction : calculating pdo - VERSION OPTIMISÉE."""
    
    # ============================================================
    # OPTIMISATION: Tous les coefficients calculés en UN SEUL with_columns
    # Au lieu de 16 appels séparés, on regroupe tout
    # ============================================================
    
    df_main_ilc = df_main_ilc.with_columns([
        # RP - nat_jur_a_coeffs
        pl.when(pl.col("nat_jur_a") == "4-6")
        .then(pl.lit(0.242841372870074))
        .when(pl.col("nat_jur_a") == ">=7")
        .then(pl.lit(1.14619110439058))
        .otherwise(0)
        .alias("nat_jur_a_coeffs"),
        
        # RP - secto_b_coeffs
        pl.when(pl.col("secto_b") == "1")
        .then(pl.lit(0.945818754757707))
        .when(pl.col("secto_b") == "2")
        .then(pl.lit(0.945818754757707))
        .when(pl.col("secto_b") == "3")
        .then(pl.lit(0.302139711824692))
        .otherwise(0)
        .alias("secto_b_coeffs"),
        
        # RP - seg_nae_coeffs
        pl.when(pl.col("c_sgmttn_nae") == "autres")
        .then(pl.lit(0.699122196727483))
        .otherwise(0)
        .alias("seg_nae_coeffs"),
        
        # RP - top_ga_coeffs
        pl.when(pl.col("top_ga") == "1")
        .then(pl.lit(0.381966549691793))
        .otherwise(0)
        .alias("top_ga_coeffs"),
        
        # RSC - nbj_coeffs
        pl.when(pl.col("nbj") == "<=12")
        .then(pl.lit(0.739002401887176))
        .otherwise(0)
        .alias("nbj_coeffs"),
        
        # Soldes - solde_cav_char_coeffs
        pl.when(pl.col("solde_cav_char") == "2")
        .then(pl.lit(0.138176642753287))
        .when(pl.col("solde_cav_char") == "3")
        .then(pl.lit(0.475979161230845))
        .when(pl.col("solde_cav_char") == "4")
        .then(pl.lit(0.923960586241845))
        .otherwise(0)
        .alias("solde_cav_char_coeffs"),
        
        # Reboot - reboot_score_char2_coeffs
        pl.when(pl.col("reboot_score_char2") == "1")
        .then(pl.lit(3.92364486708385))
        .when(pl.col("reboot_score_char2") == "2")
        .then(pl.lit(1.74758134681695))
        .when(pl.col("reboot_score_char2") == "3")
        .then(pl.lit(1.34323461962549))
        .when(pl.col("reboot_score_char2") == "4")
        .then(pl.lit(1.09920154963862))
        .when(pl.col("reboot_score_char2") == "5")
        .then(pl.lit(0.756387308936913))
        .when(pl.col("reboot_score_char2") == "6")
        .then(pl.lit(0.756387308936913))
        .when(pl.col("reboot_score_char2") == "7")
        .then(pl.lit(0.756387308936913))
        .when(pl.col("reboot_score_char2") == "8")
        .then(pl.lit(0.340053879161636))
        .otherwise(0)
        .alias("reboot_score_char2_coeffs"),
        
        # Transac - remb_sepa_max_coeffs
        pl.when(pl.col("remb_sepa_max") == "2")
        .then(pl.lit(1.34614367878806))
        .otherwise(0)
        .alias("remb_sepa_max_coeffs"),
        
        # Transac - pres_prlv_retourne_coeffs
        pl.when(pl.col("pres_prlv_retourne") == "2")
        .then(pl.lit(0.917163902080624))
        .otherwise(0)
        .alias("pres_prlv_retourne_coeffs"),
        
        # Transac - pres_saisie_coeffs
        pl.when(pl.col("pres_saisie") == "2")
        .then(pl.lit(0.805036359316808))
        .otherwise(0)
        .alias("pres_saisie_coeffs"),
        
        # Transac - net_int_turnover_coeffs
        pl.when(pl.col("net_int_turnover") == "2")
        .then(pl.lit(0.479376606177871))
        .otherwise(0)
        .alias("net_int_turnover_coeffs"),
        
        # Safir conso - rn_ca_conso_023b_coeffs
        pl.when(pl.col("rn_ca_conso_023b") == "2")
        .then(pl.lit(1.17070023813324))
        .when(pl.col("rn_ca_conso_023b") == "3")
        .then(pl.lit(1.64465207886908))
        .otherwise(0)
        .alias("rn_ca_conso_023b_coeffs"),
        
        # Safir soc - caf_dmlt_005_coeffs
        pl.when(pl.col("caf_dmlt_005") == "2")
        .then(pl.lit(0.552998315798404))
        .otherwise(0)
        .alias("caf_dmlt_005_coeffs"),
        
        # Safir soc - res_total_passif_035_coeffs
        pl.when(pl.col("res_total_passif_035") == "2")
        .then(pl.lit(0.332604372992466))
        .when(pl.col("res_total_passif_035") == "3")
        .then(pl.lit(0.676018969566685))
        .when(pl.col("res_total_passif_035") == "4")
        .then(pl.lit(0.977499984983427))
        .otherwise(0)
        .alias("res_total_passif_035_coeffs"),
        
        # Safir soc - immob_total_passif_055_coeffs
        pl.when(pl.col("immob_total_passif_055") == "2")
        .then(pl.lit(0.32870481469531))
        .when(pl.col("immob_total_passif_055") == "3")
        .then(pl.lit(0.572596945524726))
        .otherwise(0)
        .alias("immob_total_passif_055_coeffs"),
        
        # Intercept
        pl.lit(-3.86402362750751).alias("intercept"),
    ])

    # Calcul final PDO en un seul bloc
    df_main_ilc = df_main_ilc.with_columns([
        # Somme des coefficients
        (
            pl.col("nat_jur_a_coeffs")
            + pl.col("secto_b_coeffs")
            + pl.col("seg_nae_coeffs")
            + pl.col("top_ga_coeffs")
            + pl.col("nbj_coeffs")
            + pl.col("solde_cav_char_coeffs")
            + pl.col("reboot_score_char2_coeffs")
            + pl.col("remb_sepa_max_coeffs")
            + pl.col("pres_prlv_retourne_coeffs")
            + pl.col("pres_saisie_coeffs")
            + pl.col("net_int_turnover_coeffs")
            + pl.col("rn_ca_conso_023b_coeffs")
            + pl.col("caf_dmlt_005_coeffs")
            + pl.col("res_total_passif_035_coeffs")
            + pl.col("immob_total_passif_055_coeffs")
        ).alias("sum_total_coeffs"),
    ])
    
    # PDO finale
    df_main_ilc = df_main_ilc.with_columns([
        (1 - 1 / (1 + ((-1 * pl.col("sum_total_coeffs")).exp()))).alias("PDO_compute"),
    ])
    
    df_main_ilc = df_main_ilc.with_columns([
        pl.when(pl.col("PDO_compute") < 0.0001)
        .then(pl.lit(0.0001))
        .otherwise(pl.col("PDO_compute").round(4))
        .alias("PDO"),
        pl.lit("OK").alias("flag_pdo"),
    ])

    return df_main_ilc
