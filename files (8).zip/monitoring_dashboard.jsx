import React, { useState } from 'react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, Legend } from 'recharts';

const batchData = [
  { uc: 'ML4AML', volume: 7000000, type: 'Tabulaire Classification', statut: 'En dév' },
  { uc: 'Scores de FID', volume: 5000000, type: 'Tabulaire Classification', statut: 'En dév' },
  { uc: 'Pitch Easy', volume: 4500000, type: 'Recommandation', statut: 'En prod' },
  { uc: 'ILC/PDO', volume: 70000, type: 'Tabulaire Régression', statut: 'En dév' },
  { uc: 'Advocacy Classification', volume: 1500, type: 'NLP Classification', statut: 'En dév' },
  { uc: 'Advocacy Tonalité', volume: 1500, type: 'NLP Classification', statut: 'En dév' },
  { uc: 'Vox Compliance Contrôle', volume: 1500, type: 'NLP Génératif', statut: 'En dév' },
];

const apiData = [
  { uc: 'Fraude Virement', volume: 18000, type: 'Tabulaire Classification', statut: 'En dév' },
  { uc: 'Simplimmo', volume: 5000, type: 'Tabulaire Régression', statut: 'En prod' },
  { uc: 'Fraude Chèque', volume: 2700, type: 'Tabulaire Classification', statut: 'En dév' },
  { uc: 'CR Auto Summary', volume: 1600, type: 'NLP Génératif', statut: 'En prod' },
  { uc: 'Smartinbox Classification', volume: 1000, type: 'NLP Classification', statut: 'En prod' },
  { uc: 'SAV Guardrails Safety', volume: 650, type: 'NLP Classification', statut: 'En prod' },
  { uc: 'SAV Guardrails Irrelevancy', volume: 650, type: 'NLP Classification', statut: 'En prod' },
  { uc: 'SAV Guardrails Toxicity', volume: 650, type: 'NLP Classification', statut: 'En prod' },
  { uc: 'SAV Guardrails Intentions', volume: 650, type: 'NLP Classification', statut: 'En prod' },
  { uc: 'SAV RAG', volume: 650, type: 'NLP RAG', statut: 'En prod' },
  { uc: 'Smartinbox Outlook', volume: 467, type: 'NLP RAG', statut: 'En dév' },
  { uc: 'Réclamations', volume: 25, type: 'NLP Génératif', statut: 'En dév' },
];

const HOURS_PER_MONTH = 270;

const totalBatchDataPoints = batchData.reduce((acc, item) => acc + item.volume, 0);
const totalApiCallsPerHour = apiData.reduce((acc, item) => acc + item.volume, 0);
const totalApiCallsPerMonth = totalApiCallsPerHour * HOURS_PER_MONTH;
const batchDataPerHour = Math.round(totalBatchDataPoints / HOURS_PER_MONTH);
const totalInteractionsPerHour = totalApiCallsPerHour + batchDataPerHour;
const totalInteractionsPerMonth = totalBatchDataPoints + totalApiCallsPerMonth;

const batchTop3 = batchData.slice(0, 3);
const apiTop3 = apiData.slice(0, 3);

const BATCH_COLORS = ['#06b6d4', '#0891b2', '#0e7490', '#155e75', '#164e63', '#083344', '#042f2e'];
const API_COLORS = ['#8b5cf6', '#7c3aed', '#6d28d9', '#5b21b6', '#4c1d95', '#3b0764', '#2e1065', '#1e1b4b', '#312e81', '#3730a3', '#4338ca', '#4f46e5'];

const formatNumber = (num) => {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
  return num.toString();
};

const formatFullNumber = (num) => num.toLocaleString('fr-FR');

const CustomTooltip = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div style={{
        background: 'linear-gradient(135deg, rgba(15, 23, 42, 0.98) 0%, rgba(30, 41, 59, 0.98) 100%)',
        border: '1px solid rgba(148, 163, 184, 0.2)',
        borderRadius: '12px',
        padding: '16px 20px',
        backdropFilter: 'blur(20px)',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)'
      }}>
        <p style={{ color: '#f1f5f9', fontWeight: '600', fontSize: '14px', margin: '0 0 8px 0' }}>{data.uc}</p>
        <p style={{ color: '#94a3b8', fontSize: '13px', margin: '0 0 4px 0' }}>{data.type}</p>
        <p style={{ color: '#38bdf8', fontWeight: '700', fontSize: '16px', margin: '0' }}>{formatFullNumber(data.volume)}</p>
      </div>
    );
  }
  return null;
};

const StatCard = ({ title, value, subtitle, icon, gradient, color, delay }) => (
  <div style={{
    background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.8) 0%, rgba(15, 23, 42, 0.9) 100%)',
    borderRadius: '20px',
    padding: '28px',
    border: '1px solid rgba(148, 163, 184, 0.1)',
    position: 'relative',
    overflow: 'hidden',
    animation: `fadeSlideUp 0.6s ease-out ${delay}s both`
  }}>
    <div style={{
      position: 'absolute',
      top: 0,
      right: 0,
      width: '120px',
      height: '120px',
      background: gradient,
      borderRadius: '50%',
      filter: 'blur(40px)',
      opacity: 0.3,
      transform: 'translate(30%, -30%)'
    }} />
    <div style={{ position: 'relative', zIndex: 1 }}>
      <div style={{ fontSize: '28px', marginBottom: '12px' }}>{icon}</div>
      <p style={{ 
        color: '#64748b', 
        fontSize: '13px', 
        textTransform: 'uppercase', 
        letterSpacing: '1.5px',
        fontWeight: '600',
        margin: '0 0 8px 0'
      }}>{title}</p>
      <p style={{ 
        color: color,
        fontSize: '36px', 
        fontWeight: '800',
        margin: '0 0 6px 0'
      }}>{value}</p>
      <p style={{ color: '#94a3b8', fontSize: '13px', margin: 0 }}>{subtitle}</p>
    </div>
  </div>
);

const TopUCCard = ({ rank, uc, volume, type, statut, color, unit }) => (
  <div style={{
    display: 'flex',
    alignItems: 'center',
    gap: '16px',
    padding: '16px 20px',
    background: 'rgba(30, 41, 59, 0.5)',
    borderRadius: '14px',
    border: '1px solid rgba(148, 163, 184, 0.08)',
    transition: 'all 0.3s ease',
    cursor: 'default'
  }}
  onMouseEnter={(e) => {
    e.currentTarget.style.background = 'rgba(51, 65, 85, 0.6)';
    e.currentTarget.style.transform = 'translateX(8px)';
    e.currentTarget.style.borderColor = color;
  }}
  onMouseLeave={(e) => {
    e.currentTarget.style.background = 'rgba(30, 41, 59, 0.5)';
    e.currentTarget.style.transform = 'translateX(0)';
    e.currentTarget.style.borderColor = 'rgba(148, 163, 184, 0.08)';
  }}>
    <div style={{
      width: '44px',
      height: '44px',
      borderRadius: '12px',
      background: `linear-gradient(135deg, ${color}40, ${color}20)`,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontWeight: '800',
      fontSize: '18px',
      color: color,
      border: `2px solid ${color}60`
    }}>#{rank}</div>
    <div style={{ flex: 1 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '4px' }}>
        <span style={{ color: '#f1f5f9', fontWeight: '700', fontSize: '15px' }}>{uc}</span>
        <span style={{
          background: statut === 'En prod' ? 'rgba(34, 197, 94, 0.15)' : 'rgba(251, 191, 36, 0.15)',
          color: statut === 'En prod' ? '#4ade80' : '#fbbf24',
          padding: '3px 10px',
          borderRadius: '20px',
          fontSize: '11px',
          fontWeight: '600',
          textTransform: 'uppercase',
          letterSpacing: '0.5px'
        }}>{statut}</span>
      </div>
      <p style={{ color: '#64748b', fontSize: '12px', margin: 0 }}>{type}</p>
    </div>
    <div style={{ textAlign: 'right' }}>
      <p style={{ color: color, fontWeight: '800', fontSize: '18px', margin: '0 0 2px 0' }}>{formatNumber(volume)}</p>
      <p style={{ color: '#64748b', fontSize: '11px', margin: 0 }}>{unit}</p>
    </div>
  </div>
);

const SectionTitle = ({ icon, title, subtitle }) => (
  <div style={{ marginBottom: '28px' }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '6px' }}>
      <span style={{ fontSize: '24px' }}>{icon}</span>
      <h2 style={{ 
        color: '#f1f5f9', 
        fontSize: '22px', 
        fontWeight: '700', 
        margin: 0,
        letterSpacing: '-0.5px'
      }}>{title}</h2>
    </div>
    <p style={{ color: '#64748b', fontSize: '14px', margin: 0, marginLeft: '36px' }}>{subtitle}</p>
  </div>
);

export default function MonitoringDashboard() {
  const [hoveredBatch, setHoveredBatch] = useState(null);
  const [hoveredApi, setHoveredApi] = useState(null);

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(180deg, #0f172a 0%, #020617 100%)',
      fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      padding: '40px',
      position: 'relative',
      overflow: 'hidden'
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
        @keyframes fadeSlideUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.7; }
        }
        @keyframes float {
          0%, 100% { transform: translateY(0) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(5deg); }
        }
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: rgba(15, 23, 42, 0.5); }
        ::-webkit-scrollbar-thumb { background: rgba(100, 116, 139, 0.5); border-radius: 4px; }
      `}</style>

      {/* Background decorations */}
      <div style={{
        position: 'fixed',
        top: '10%',
        left: '5%',
        width: '600px',
        height: '600px',
        background: 'radial-gradient(circle, rgba(6, 182, 212, 0.08) 0%, transparent 70%)',
        borderRadius: '50%',
        pointerEvents: 'none',
        animation: 'float 20s ease-in-out infinite'
      }} />
      <div style={{
        position: 'fixed',
        bottom: '10%',
        right: '5%',
        width: '500px',
        height: '500px',
        background: 'radial-gradient(circle, rgba(139, 92, 246, 0.08) 0%, transparent 70%)',
        borderRadius: '50%',
        pointerEvents: 'none',
        animation: 'float 25s ease-in-out infinite reverse'
      }} />

      <div style={{ maxWidth: '1600px', margin: '0 auto', position: 'relative', zIndex: 1 }}>
        {/* Header */}
        <div style={{ 
          textAlign: 'center', 
          marginBottom: '50px',
          animation: 'fadeSlideUp 0.6s ease-out'
        }}>
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.15), rgba(139, 92, 246, 0.15))',
            padding: '8px 20px',
            borderRadius: '30px',
            marginBottom: '20px',
            border: '1px solid rgba(148, 163, 184, 0.1)'
          }}>
            <div style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              background: '#22c55e',
              animation: 'pulse 2s ease-in-out infinite'
            }} />
            <span style={{ color: '#94a3b8', fontSize: '13px', fontWeight: '600', letterSpacing: '1px' }}>
              PLATEFORME ML MONITORING
            </span>
          </div>
          <h1 style={{ 
            color: '#f8fafc', 
            fontSize: '48px', 
            fontWeight: '900',
            margin: '0 0 12px 0',
            letterSpacing: '-2px',
            background: 'linear-gradient(135deg, #f8fafc 0%, #94a3b8 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text'
          }}>
            Dimensionnement Infrastructure
          </h1>
          <p style={{ color: '#64748b', fontSize: '18px', margin: 0, fontWeight: '500' }}>
            Vue consolidée des volumétries Batch & API • {batchData.length + apiData.length} Use Cases monitorés
          </p>
        </div>

        {/* Main Stats Grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: '24px',
          marginBottom: '50px'
        }}>
          <StatCard 
            title="Interactions / Heure"
            value={formatNumber(totalInteractionsPerHour)}
            subtitle="Batch + API combinés"
            icon="⚡"
            gradient="linear-gradient(135deg, #f59e0b, #d97706)"
            color="#fbbf24"
            delay={0.1}
          />
          <StatCard 
            title="Interactions / Mois"
            value={formatNumber(totalInteractionsPerMonth)}
            subtitle={`${formatFullNumber(totalInteractionsPerMonth)} total`}
            icon="📊"
            gradient="linear-gradient(135deg, #10b981, #059669)"
            color="#4ade80"
            delay={0.2}
          />
          <StatCard 
            title="Appels API / Heure"
            value={formatNumber(totalApiCallsPerHour)}
            subtitle={`${apiData.length} endpoints actifs`}
            icon="🔌"
            gradient="linear-gradient(135deg, #8b5cf6, #6d28d9)"
            color="#a78bfa"
            delay={0.3}
          />
          <StatCard 
            title="Data Points / Mois"
            value={formatNumber(totalBatchDataPoints)}
            subtitle={`${batchData.length} batches actifs`}
            icon="📦"
            gradient="linear-gradient(135deg, #06b6d4, #0891b2)"
            color="#22d3ee"
            delay={0.4}
          />
        </div>

        {/* Two Column Layout */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px', marginBottom: '50px' }}>
          
          {/* BATCH Section */}
          <div style={{
            background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.8) 100%)',
            borderRadius: '24px',
            padding: '32px',
            border: '1px solid rgba(6, 182, 212, 0.15)',
            animation: 'fadeSlideUp 0.6s ease-out 0.3s both'
          }}>
            <SectionTitle 
              icon="📦" 
              title="Traitements Batch" 
              subtitle="Volumétrie de data points par Use Case"
            />
            
            <div style={{ display: 'flex', gap: '30px', marginBottom: '30px' }}>
              <div style={{ flex: '1', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                <ResponsiveContainer width={280} height={280}>
                  <PieChart>
                    <Pie
                      data={batchData}
                      dataKey="volume"
                      nameKey="uc"
                      cx="50%"
                      cy="50%"
                      innerRadius={70}
                      outerRadius={110}
                      paddingAngle={3}
                      onMouseEnter={(_, index) => setHoveredBatch(index)}
                      onMouseLeave={() => setHoveredBatch(null)}
                    >
                      {batchData.map((entry, index) => (
                        <Cell 
                          key={`batch-${index}`} 
                          fill={BATCH_COLORS[index % BATCH_COLORS.length]}
                          stroke="rgba(15, 23, 42, 0.8)"
                          strokeWidth={2}
                          style={{
                            filter: hoveredBatch === index ? 'brightness(1.3) drop-shadow(0 0 8px rgba(6, 182, 212, 0.5))' : 'none',
                            transition: 'all 0.3s ease',
                            cursor: 'pointer'
                          }}
                        />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div style={{
              background: 'rgba(6, 182, 212, 0.08)',
              borderRadius: '14px',
              padding: '20px',
              marginBottom: '24px',
              border: '1px solid rgba(6, 182, 212, 0.15)'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ color: '#94a3b8', fontSize: '14px', fontWeight: '600' }}>Total Data Points / Mois</span>
                <span style={{ 
                  color: '#22d3ee', 
                  fontSize: '28px', 
                  fontWeight: '800',
                  textShadow: '0 0 30px rgba(34, 211, 238, 0.3)'
                }}>{formatFullNumber(totalBatchDataPoints)}</span>
              </div>
            </div>

            <div>
              <p style={{ color: '#94a3b8', fontSize: '12px', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '16px' }}>
                🏆 Top 3 Use Cases
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {batchTop3.map((item, idx) => (
                  <TopUCCard 
                    key={item.uc}
                    rank={idx + 1}
                    uc={item.uc}
                    volume={item.volume}
                    type={item.type}
                    statut={item.statut}
                    color={BATCH_COLORS[idx]}
                    unit="data points/mois"
                  />
                ))}
              </div>
            </div>
          </div>

          {/* API Section */}
          <div style={{
            background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.8) 100%)',
            borderRadius: '24px',
            padding: '32px',
            border: '1px solid rgba(139, 92, 246, 0.15)',
            animation: 'fadeSlideUp 0.6s ease-out 0.4s both'
          }}>
            <SectionTitle 
              icon="🔌" 
              title="Appels API" 
              subtitle="Volumétrie d'appels par heure par Use Case"
            />
            
            <div style={{ display: 'flex', gap: '30px', marginBottom: '30px' }}>
              <div style={{ flex: '1', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                <ResponsiveContainer width={280} height={280}>
                  <PieChart>
                    <Pie
                      data={apiData}
                      dataKey="volume"
                      nameKey="uc"
                      cx="50%"
                      cy="50%"
                      innerRadius={70}
                      outerRadius={110}
                      paddingAngle={2}
                      onMouseEnter={(_, index) => setHoveredApi(index)}
                      onMouseLeave={() => setHoveredApi(null)}
                    >
                      {apiData.map((entry, index) => (
                        <Cell 
                          key={`api-${index}`} 
                          fill={API_COLORS[index % API_COLORS.length]}
                          stroke="rgba(15, 23, 42, 0.8)"
                          strokeWidth={2}
                          style={{
                            filter: hoveredApi === index ? 'brightness(1.3) drop-shadow(0 0 8px rgba(139, 92, 246, 0.5))' : 'none',
                            transition: 'all 0.3s ease',
                            cursor: 'pointer'
                          }}
                        />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '24px' }}>
              <div style={{
                background: 'rgba(139, 92, 246, 0.08)',
                borderRadius: '14px',
                padding: '20px',
                border: '1px solid rgba(139, 92, 246, 0.15)'
              }}>
                <p style={{ color: '#94a3b8', fontSize: '12px', fontWeight: '600', margin: '0 0 8px 0' }}>Appels / Heure</p>
                <p style={{ 
                  color: '#a78bfa', 
                  fontSize: '24px', 
                  fontWeight: '800',
                  margin: 0,
                  textShadow: '0 0 30px rgba(167, 139, 250, 0.3)'
                }}>{formatFullNumber(totalApiCallsPerHour)}</p>
              </div>
              <div style={{
                background: 'rgba(139, 92, 246, 0.08)',
                borderRadius: '14px',
                padding: '20px',
                border: '1px solid rgba(139, 92, 246, 0.15)'
              }}>
                <p style={{ color: '#94a3b8', fontSize: '12px', fontWeight: '600', margin: '0 0 8px 0' }}>Appels / Mois</p>
                <p style={{ 
                  color: '#a78bfa', 
                  fontSize: '24px', 
                  fontWeight: '800',
                  margin: 0,
                  textShadow: '0 0 30px rgba(167, 139, 250, 0.3)'
                }}>{formatNumber(totalApiCallsPerMonth)}</p>
              </div>
            </div>

            <div>
              <p style={{ color: '#94a3b8', fontSize: '12px', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '16px' }}>
                🏆 Top 3 Use Cases
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {apiTop3.map((item, idx) => (
                  <TopUCCard 
                    key={item.uc}
                    rank={idx + 1}
                    uc={item.uc}
                    volume={item.volume}
                    type={item.type}
                    statut={item.statut}
                    color={API_COLORS[idx]}
                    unit="appels/heure"
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Aggregated Section */}
        <div style={{
          background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.8) 100%)',
          borderRadius: '24px',
          padding: '36px',
          border: '1px solid rgba(251, 191, 36, 0.15)',
          animation: 'fadeSlideUp 0.6s ease-out 0.5s both'
        }}>
          <SectionTitle 
            icon="🎯" 
            title="Métriques Agrégées API + Batch" 
            subtitle="Vue consolidée des interactions avec la plateforme ML"
          />

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '24px', marginBottom: '32px' }}>
            <div style={{
              background: 'linear-gradient(135deg, rgba(251, 191, 36, 0.1), rgba(245, 158, 11, 0.05))',
              borderRadius: '16px',
              padding: '28px',
              border: '1px solid rgba(251, 191, 36, 0.2)',
              textAlign: 'center'
            }}>
              <p style={{ color: '#fbbf24', fontSize: '40px', fontWeight: '900', margin: '0 0 8px 0' }}>{formatNumber(totalInteractionsPerHour)}</p>
              <p style={{ color: '#94a3b8', fontSize: '13px', margin: 0, fontWeight: '600' }}>Interactions / Heure</p>
            </div>
            <div style={{
              background: 'linear-gradient(135deg, rgba(34, 197, 94, 0.1), rgba(16, 185, 129, 0.05))',
              borderRadius: '16px',
              padding: '28px',
              border: '1px solid rgba(34, 197, 94, 0.2)',
              textAlign: 'center'
            }}>
              <p style={{ color: '#4ade80', fontSize: '40px', fontWeight: '900', margin: '0 0 8px 0' }}>{formatNumber(totalInteractionsPerMonth)}</p>
              <p style={{ color: '#94a3b8', fontSize: '13px', margin: 0, fontWeight: '600' }}>Interactions / Mois</p>
            </div>
            <div style={{
              background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.1), rgba(14, 116, 144, 0.05))',
              borderRadius: '16px',
              padding: '28px',
              border: '1px solid rgba(6, 182, 212, 0.2)',
              textAlign: 'center'
            }}>
              <p style={{ color: '#22d3ee', fontSize: '40px', fontWeight: '900', margin: '0 0 8px 0' }}>{batchData.length}</p>
              <p style={{ color: '#94a3b8', fontSize: '13px', margin: 0, fontWeight: '600' }}>Use Cases Batch</p>
            </div>
            <div style={{
              background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(109, 40, 217, 0.05))',
              borderRadius: '16px',
              padding: '28px',
              border: '1px solid rgba(139, 92, 246, 0.2)',
              textAlign: 'center'
            }}>
              <p style={{ color: '#a78bfa', fontSize: '40px', fontWeight: '900', margin: '0 0 8px 0' }}>{apiData.length}</p>
              <p style={{ color: '#94a3b8', fontSize: '13px', margin: 0, fontWeight: '600' }}>Use Cases API</p>
            </div>
          </div>

          <div style={{
            background: 'rgba(15, 23, 42, 0.6)',
            borderRadius: '16px',
            padding: '24px',
            border: '1px solid rgba(148, 163, 184, 0.1)'
          }}>
            <p style={{ color: '#94a3b8', fontSize: '12px', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '20px' }}>
              📐 Règle de calcul appliquée
            </p>
            <div style={{ display: 'flex', gap: '40px', flexWrap: 'wrap' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#06b6d4' }} />
                <span style={{ color: '#e2e8f0', fontSize: '14px' }}>1 jour = <strong style={{ color: '#22d3ee' }}>10 heures</strong></span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#8b5cf6' }} />
                <span style={{ color: '#e2e8f0', fontSize: '14px' }}>1 semaine = <strong style={{ color: '#a78bfa' }}>6 jours</strong></span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#f59e0b' }} />
                <span style={{ color: '#e2e8f0', fontSize: '14px' }}>1 mois = <strong style={{ color: '#fbbf24' }}>4,5 semaines</strong> = <strong style={{ color: '#fbbf24' }}>270 heures</strong></span>
              </div>
            </div>
          </div>
        </div>

        {/* Distribution Bar Charts */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px', marginTop: '30px' }}>
          <div style={{
            background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.8) 100%)',
            borderRadius: '24px',
            padding: '32px',
            border: '1px solid rgba(6, 182, 212, 0.15)',
            animation: 'fadeSlideUp 0.6s ease-out 0.6s both'
          }}>
            <SectionTitle 
              icon="📊" 
              title="Distribution Batch" 
              subtitle="Répartition complète des data points"
            />
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={batchData} layout="vertical" margin={{ left: 60, right: 30 }}>
                <XAxis type="number" tickFormatter={formatNumber} stroke="#64748b" fontSize={12} />
                <YAxis type="category" dataKey="uc" stroke="#64748b" fontSize={11} width={100} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="volume" radius={[0, 8, 8, 0]}>
                  {batchData.map((entry, index) => (
                    <Cell key={`bar-batch-${index}`} fill={BATCH_COLORS[index % BATCH_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div style={{
            background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.8) 100%)',
            borderRadius: '24px',
            padding: '32px',
            border: '1px solid rgba(139, 92, 246, 0.15)',
            animation: 'fadeSlideUp 0.6s ease-out 0.7s both'
          }}>
            <SectionTitle 
              icon="📈" 
              title="Distribution API" 
              subtitle="Répartition complète des appels/heure"
            />
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={apiData} layout="vertical" margin={{ left: 60, right: 30 }}>
                <XAxis type="number" tickFormatter={formatNumber} stroke="#64748b" fontSize={12} />
                <YAxis type="category" dataKey="uc" stroke="#64748b" fontSize={10} width={120} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="volume" radius={[0, 8, 8, 0]}>
                  {apiData.map((entry, index) => (
                    <Cell key={`bar-api-${index}`} fill={API_COLORS[index % API_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Footer */}
        <div style={{ 
          textAlign: 'center', 
          marginTop: '50px', 
          paddingTop: '30px',
          borderTop: '1px solid rgba(148, 163, 184, 0.1)'
        }}>
          <p style={{ color: '#475569', fontSize: '13px', margin: 0 }}>
            Dashboard Dimensionnement Plateforme ML Monitoring • Données consolidées • {new Date().toLocaleDateString('fr-FR', { year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>
      </div>
    </div>
  );
}
