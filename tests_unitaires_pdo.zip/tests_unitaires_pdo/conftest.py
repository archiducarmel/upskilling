"""Pytest configuration and shared fixtures for PDO unit tests.

This module provides common test fixtures, mock objects, and configuration
for all unit tests in the PDO calculation pipeline.
"""

import os
import sys
from unittest.mock import MagicMock, patch
from typing import Dict, Any, Generator

import pytest
import polars as pl


# Add project root to path for imports
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)


# ============================================================================
# Environment Fixtures
# ============================================================================

@pytest.fixture
def mock_env_starburst() -> Generator[Dict[str, str], None, None]:
    """Fixture providing mock Starburst environment variables."""
    env_vars = {
        'STARBURST_HOST_QUAL': 'test-host.example.com',
        'STARBURST_USERNAME': 'test_user',
        'STARBURST_PASSWORD': 'test_password',
        'STARBURST_PORT': '443',
        'STARBURST_CATALOG': 'test_catalog',
    }
    with patch.dict(os.environ, env_vars):
        yield env_vars


@pytest.fixture
def mock_env_cos() -> Generator[Dict[str, str], None, None]:
    """Fixture providing mock COS environment variables."""
    env_vars = {
        'COS_ML_API_KEY_ID': 'test_api_key',
        'COS_ML_SERVICE_INSTANCE_ID': 'test_instance_id',
        'COS_ML_ENDPOINT_URL': 'https://s3.test.example.com',
        'COS_ML_AUTH_URL': 'https://iam.test.example.com/identity/token',
    }
    with patch.dict(os.environ, env_vars):
        yield env_vars


@pytest.fixture
def mock_env_all(mock_env_starburst: Dict[str, str], mock_env_cos: Dict[str, str]) -> Dict[str, str]:
    """Fixture combining all environment variables."""
    return {**mock_env_starburst, **mock_env_cos}


# ============================================================================
# DataFrame Fixtures
# ============================================================================

@pytest.fixture
def sample_df_main() -> pl.DataFrame:
    """Fixture providing a sample df_main DataFrame with required columns."""
    return pl.DataFrame({
        "i_uniq_kpi": ["E001", "E002", "E003"],
        "i_intrn": ["A001", "A002", "A003"],
        "i_siren": ["111111111", "222222222", "333333333"],
        "c_njur_prsne": ["26", "55", "22"],
        "c_sectrl_1": ["420053", "360120", "380020"],
        "i_g_affre_rmpm": ["G001", None, "G002"],
        "c_sgmttn_nae": ["ME", "GR", "A3"],
        "c_crisq": ["0", "0", "0"],
        "c_profl_immbr": ["0", "0", "0"],
        "c_eco": ["999", "999", "999"],
        "c_naf": ["1234A", "5678B", "9012C"],
    })


@pytest.fixture
def sample_rsc() -> pl.DataFrame:
    """Fixture providing a sample RSC (Risk Score Components) DataFrame."""
    return pl.DataFrame({
        "i_intrn": ["A001", "A001", "A002", "A003"],
        "k_dep_auth_10j": [3, 7, 5, 2],
    })


@pytest.fixture
def sample_soldes() -> pl.DataFrame:
    """Fixture providing a sample SOLDES (account balances) DataFrame."""
    return pl.DataFrame({
        "i_intrn": ["A001", "A001", "A002", "A003"],
        "pref_i_uniq_cpt": ["CPT001", "CPT002", "CPT003", "CPT004"],
        "pref_m_ctrvl_sld_arr": [100000, 50000, 200000, -50000],  # In cents
    })


@pytest.fixture
def sample_reboot() -> pl.DataFrame:
    """Fixture providing a sample REBOOT score DataFrame."""
    return pl.DataFrame({
        "i_uniq_kpi": ["E001", "E002", "E003"],
        "q_score": ["1,5", "-0,75", "0,0"],  # European decimal format
        "d_score": ["2024-01-15", "2024-01-14", "2024-01-13"],
    })


@pytest.fixture
def sample_transac() -> pl.DataFrame:
    """Fixture providing a sample transaction DataFrame."""
    return pl.DataFrame({
        "i_uniq_kpi": ["E001", "E001", "E001", "E002", "E003"],
        "category": ["interets", "turnover", "rembt_prlv_sepa", "prlv_sepa_retourne", "attri_blocage"],
        "netamount": [-100.0, 50000.0, 5000.0, 200.0, 150.0],
        "nops_category": [10, 100, 5, 3, 2],
        "min_amount": [-100.0, 1000.0, 1000.0, 100.0, 75.0],
        "max_amount": [-100.0, 10000.0, 5000.0, 200.0, 150.0],
    })


@pytest.fixture
def sample_safir_sc() -> pl.DataFrame:
    """Fixture providing a sample SAFIR SC (social header) DataFrame."""
    return pl.DataFrame({
        "i_siren": ["111111111", "222222222", "333333333"],
        "d_fin_excce_soc": ["2024-12-31", "2024-12-31", "2024-06-30"],
        "c_duree_excce_soc": [12, 12, 6],
        "c_regme_fisc": ["1", "2", "1"],
    })


@pytest.fixture
def sample_safir_sd() -> pl.DataFrame:
    """Fixture providing a sample SAFIR SD (social detail) DataFrame."""
    return pl.DataFrame({
        "i_siren": ["111111111", "111111111", "222222222", "333333333"],
        "d_fin_excce_soc": ["2024-12-31", "2024-12-31", "2024-12-31", "2024-06-30"],
        "c_code": ["00066", "00112", "00066", "00066"],  # mt_182 (res_net), mt_310 (CA)
        "c_val": [50000.0, 1000000.0, 30000.0, 25000.0],
    })


@pytest.fixture
def sample_safir_cc() -> pl.DataFrame:
    """Fixture providing a sample SAFIR CC (consolidated header) DataFrame."""
    return pl.DataFrame({
        "i_g_affre_rmpm": ["G001", "G002"],
        "d_fin_excce_conso": ["2024-12-31", "2024-12-31"],
        "c_duree_excce_conso": [12, 12],
        "top_ga_mm": ["1", "1"],
    })


@pytest.fixture
def sample_safir_cd() -> pl.DataFrame:
    """Fixture providing a sample SAFIR CD (consolidated detail) DataFrame."""
    return pl.DataFrame({
        "i_g_affre_rmpm": ["G001", "G001", "G002"],
        "d_fin_excce_conso": ["2024-12-31", "2024-12-31", "2024-12-31"],
        "c_code": ["00112", "00182", "00112"],  # mt_310 (CA), mt_182 (res_net)
        "c_val": [5000000.0, 250000.0, 3000000.0],
    })


@pytest.fixture
def empty_df_main() -> pl.DataFrame:
    """Fixture providing an empty DataFrame with correct schema."""
    return pl.DataFrame({
        "i_uniq_kpi": pl.Series([], dtype=pl.Utf8),
        "i_intrn": pl.Series([], dtype=pl.Utf8),
        "i_siren": pl.Series([], dtype=pl.Utf8),
    })


# ============================================================================
# Configuration Fixtures
# ============================================================================

@pytest.fixture
def sample_project_config() -> Dict[str, Any]:
    """Fixture providing a sample project configuration."""
    return {
        'environment': 'dev',
        'starburst': {
            'schema': 'dev_schema',
            'catalog': 'dev_catalog',
        },
        'cos': {
            'bucket': 'dev-bucket',
            'model_key': 'models/pdo_model_v1.pkl',
            'output_prefix': 'outputs/pdo/',
        },
        'output': {
            'local_path': '/tmp/pdo_outputs',
            'cos_bucket': 'dev-bucket',
            'cos_prefix': 'outputs/',
        },
        'model': {
            'intercept': -3.864,
            'pdo_floor': 0.0001,
            'pdo_ceiling': 1.0,
        },
    }


@pytest.fixture
def sample_app_config() -> Dict[str, Any]:
    """Fixture providing a sample application configuration."""
    return {
        'logging': {
            'level': 'INFO',
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        },
        'preprocessing': {
            'encoding': True,
            'filtering': True,
        },
        'model': {
            'version': '1.0.0',
        },
    }


# ============================================================================
# Mock Object Fixtures
# ============================================================================

@pytest.fixture
def mock_starburst_connector() -> MagicMock:
    """Fixture providing a mock StarburstConnector."""
    mock = MagicMock()
    mock.query.return_value = pl.DataFrame({
        "i_uniq_kpi": ["E001"],
        "i_intrn": ["A001"],
        "i_siren": ["111111111"],
    })
    mock.__enter__ = MagicMock(return_value=mock)
    mock.__exit__ = MagicMock(return_value=False)
    return mock


@pytest.fixture
def mock_cos_manager() -> MagicMock:
    """Fixture providing a mock CosManager."""
    mock = MagicMock()
    mock.download_file.return_value = None
    mock.upload_file.return_value = None
    mock.list_files.return_value = [
        {'Key': 'models/model_v1.pkl', 'Size': 1024},
    ]
    return mock


# ============================================================================
# Model Coefficient Fixtures
# ============================================================================

@pytest.fixture
def pdo_reference_coefficients() -> Dict[str, float]:
    """Fixture providing PDO model reference coefficients."""
    return {
        'intercept': -3.864,
        'nat_jur_a_4-6': 0.495,
        'nat_jur_a_>=7': 1.146,
        'secto_b_1': 0.306,
        'secto_b_2': 0.185,
        'secto_b_3': 0.132,
        'top_ga_1': 0.38,
        'solde_cav_char_2': -0.319,
        'solde_cav_char_3': -0.437,
        'solde_cav_char_4': -0.636,
        'reboot_score_char2_1': 3.924,
        'reboot_score_char2_2': 2.896,
        'reboot_score_char2_3': 2.251,
        'reboot_score_char2_4': 1.799,
        'reboot_score_char2_5': 1.313,
        'reboot_score_char2_6': 0.987,
        'reboot_score_char2_7': 0.606,
        'reboot_score_char2_8': 0.357,
        # Add remaining coefficients as needed
    }


# ============================================================================
# Pytest Configuration
# ============================================================================

def pytest_configure(config: Any) -> None:
    """Configure pytest with custom markers."""
    config.addinivalue_line(
        "markers", "slow: marks tests as slow (deselect with '-m \"not slow\"')"
    )
    config.addinivalue_line(
        "markers", "integration: marks tests as integration tests"
    )
    config.addinivalue_line(
        "markers", "unit: marks tests as unit tests"
    )
