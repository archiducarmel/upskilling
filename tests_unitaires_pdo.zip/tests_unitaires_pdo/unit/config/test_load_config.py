"""Unit tests for the load_config module.

This module contains tests for YAML configuration file loading functions
including error handling for missing files and invalid YAML syntax.

Test IDs: TU-083 to TU-088
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch, mock_open
import os


class TestLoadYamlConfig(TestCase):
    """Unit tests for the load_yaml_config function."""

    def setUp(self) -> None:
        """Set up test fixtures with sample YAML content."""
        self.valid_yaml_content = """
database:
  host: localhost
  port: 5432
  name: test_db
model:
  threshold: 0.5
  features:
    - feature_1
    - feature_2
"""
        self.invalid_yaml_content = """
database:
  host: localhost
  port: 5432
  name: test_db
    invalid_indent: value
"""

    @patch("builtins.open", new_callable=mock_open)
    @patch("os.path.exists")
    @patch("yaml.safe_load")
    def test_tu_083_load_yaml_config_valid_file(
        self, 
        mock_yaml_load: MagicMock,
        mock_exists: MagicMock,
        mock_file: MagicMock
    ) -> None:
        """TU-083: Verify correct loading of a valid YAML configuration file.
        
        Tests that a well-formed YAML file is correctly parsed and
        returned as a Python dictionary.
        """
        # Arrange
        from config.load_config import load_yaml_config
        
        mock_exists.return_value = True
        mock_file.return_value.read.return_value = self.valid_yaml_content
        mock_yaml_load.return_value = {
            'database': {'host': 'localhost', 'port': 5432, 'name': 'test_db'},
            'model': {'threshold': 0.5, 'features': ['feature_1', 'feature_2']}
        }
        
        # Act
        result = load_yaml_config('config/application/app_config.yml')
        
        # Assert
        self.assertIsInstance(result, dict)
        self.assertIn('database', result)
        self.assertIn('model', result)
        self.assertEqual(result['database']['host'], 'localhost')
        self.assertEqual(result['model']['threshold'], 0.5)

    @patch("os.path.exists")
    def test_tu_084_load_yaml_config_file_not_found(
        self,
        mock_exists: MagicMock
    ) -> None:
        """TU-084: Test FileNotFoundError for non-existent configuration file.
        
        When the specified configuration file does not exist, the function
        should raise FileNotFoundError with the file path in the message.
        """
        # Arrange
        from config.load_config import load_yaml_config
        
        mock_exists.return_value = False
        
        # Act & Assert
        with self.assertRaises(FileNotFoundError) as context:
            load_yaml_config('config/application/fichier_inexistant.yml')
        
        self.assertIn('fichier_inexistant.yml', str(context.exception))

    @patch("builtins.open", new_callable=mock_open)
    @patch("os.path.exists")
    @patch("yaml.safe_load")
    def test_tu_085_load_yaml_config_invalid_yaml_syntax(
        self,
        mock_yaml_load: MagicMock,
        mock_exists: MagicMock,
        mock_file: MagicMock
    ) -> None:
        """TU-085: Test behavior with invalid YAML syntax.
        
        A YAML file with invalid syntax (bad indentation, invalid characters)
        should raise yaml.YAMLError with details about the syntax error.
        """
        # Arrange
        from config.load_config import load_yaml_config
        import yaml
        
        mock_exists.return_value = True
        mock_file.return_value.read.return_value = self.invalid_yaml_content
        mock_yaml_load.side_effect = yaml.YAMLError("Invalid YAML syntax at line 5")
        
        # Act & Assert
        with self.assertRaises(yaml.YAMLError):
            load_yaml_config('config/application/invalid_config.yml')

    @patch("builtins.open", new_callable=mock_open)
    @patch("os.path.exists")
    @patch("yaml.safe_load")
    def test_tu_086_load_yaml_config_empty_file(
        self,
        mock_yaml_load: MagicMock,
        mock_exists: MagicMock,
        mock_file: MagicMock
    ) -> None:
        """TU-086: Test behavior with empty YAML file.
        
        An empty YAML file should return None or an empty dict,
        depending on implementation, without raising an exception.
        """
        # Arrange
        from config.load_config import load_yaml_config
        
        mock_exists.return_value = True
        mock_file.return_value.read.return_value = ""
        mock_yaml_load.return_value = None
        
        # Act
        result = load_yaml_config('config/application/empty_config.yml')
        
        # Assert
        # Empty YAML returns None
        self.assertIsNone(result)


class TestLoadProjectConfig(TestCase):
    """Unit tests for the load_project_config function."""

    @patch("config.load_config.load_yaml_config")
    def test_tu_087_load_project_config_by_environment(
        self,
        mock_load_yaml: MagicMock
    ) -> None:
        """TU-087: Verify correct config file is loaded based on environment.
        
        Tests that passing 'dev', 'pprod', or 'prod' loads the corresponding
        project_config_{env}.yml file.
        """
        # Arrange
        from config.load_config import load_project_config
        
        mock_load_yaml.return_value = {
            'environment': 'dev',
            'starburst': {'schema': 'dev_schema'}
        }
        
        # Act
        result = load_project_config('dev')
        
        # Assert
        mock_load_yaml.assert_called_once()
        call_args = mock_load_yaml.call_args[0][0]
        self.assertIn('project_config_dev', call_args)

    @patch("config.load_config.load_yaml_config")
    def test_tu_088_load_project_config_invalid_environment(
        self,
        mock_load_yaml: MagicMock
    ) -> None:
        """TU-088: Test behavior with invalid environment name.
        
        Passing an unknown environment like 'staging' or 'test' should
        raise ValueError or FileNotFoundError.
        """
        # Arrange
        from config.load_config import load_project_config
        
        mock_load_yaml.side_effect = FileNotFoundError(
            "Configuration file for environment 'staging' not found"
        )
        
        # Act & Assert
        with self.assertRaises(FileNotFoundError):
            load_project_config('staging')


if __name__ == "__main__":
    main()
