"""Unit tests for the retrieve_sql_query module.

This module contains tests for SQL query file retrieval functions
including parameter substitution and file path handling.

Test IDs: TU-089 to TU-091
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch, mock_open
import os


class TestRetrieveSqlQuery(TestCase):
    """Unit tests for the retrieve_sql_query function."""

    def setUp(self) -> None:
        """Set up test fixtures with sample SQL content."""
        self.sample_sql = """
SELECT 
    i_uniq_kpi,
    i_intrn,
    i_siren
FROM {schema}.{table}
WHERE d_calcul = '{date}'
"""

    @patch("builtins.open", new_callable=mock_open)
    @patch("os.path.exists")
    def test_tu_089_retrieve_sql_query_valid_file(
        self,
        mock_exists: MagicMock,
        mock_file: MagicMock
    ) -> None:
        """TU-089: Verify correct retrieval and reading of SQL query file.
        
        Tests that a valid .sql file is correctly read and its content
        returned as a string.
        """
        # Arrange
        from common.sql.retrieve_sql_query import retrieve_sql_query
        
        mock_exists.return_value = True
        mock_file.return_value.read.return_value = self.sample_sql
        
        # Act
        result = retrieve_sql_query('query_starburst_df_main.sql')
        
        # Assert
        self.assertIsInstance(result, str)
        self.assertIn('SELECT', result)
        self.assertIn('i_uniq_kpi', result)
        self.assertIn('{schema}', result)

    @patch("os.path.exists")
    def test_tu_090_retrieve_sql_query_file_not_found(
        self,
        mock_exists: MagicMock
    ) -> None:
        """TU-090: Test FileNotFoundError for non-existent SQL file.
        
        When the specified SQL file does not exist, the function should
        raise FileNotFoundError with the file name in the message.
        """
        # Arrange
        from common.sql.retrieve_sql_query import retrieve_sql_query
        
        mock_exists.return_value = False
        
        # Act & Assert
        with self.assertRaises(FileNotFoundError) as context:
            retrieve_sql_query('query_inexistante.sql')
        
        self.assertIn('query_inexistante.sql', str(context.exception))

    @patch("builtins.open", new_callable=mock_open)
    @patch("os.path.exists")
    def test_tu_091_retrieve_sql_query_parameter_placeholders(
        self,
        mock_exists: MagicMock,
        mock_file: MagicMock
    ) -> None:
        """TU-091: Verify SQL query contains expected parameter placeholders.
        
        Tests that SQL query preserves {schema}, {table}, {date} placeholders
        which will be substituted later via .format() method.
        """
        # Arrange
        from common.sql.retrieve_sql_query import retrieve_sql_query
        
        mock_exists.return_value = True
        mock_file.return_value.read.return_value = self.sample_sql
        
        # Act
        result = retrieve_sql_query('query_starburst_df_main.sql')
        
        # Assert
        self.assertIn('{schema}', result)
        self.assertIn('{table}', result)
        self.assertIn('{date}', result)
        
        # Verify placeholders can be substituted
        formatted = result.format(schema='test_schema', table='test_table', date='2024-01-01')
        self.assertNotIn('{schema}', formatted)
        self.assertIn('test_schema', formatted)


if __name__ == "__main__":
    main()
