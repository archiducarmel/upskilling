"""Unit tests for the utils module.

This module contains tests for general utility functions including
DataFrame validation, path handling, and data conversion helpers.

Test IDs: TU-099 to TU-104
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch
import polars as pl
import os


class TestValidateDataframe(TestCase):
    """Unit tests for the validate_dataframe function."""

    def setUp(self) -> None:
        """Set up test fixtures with sample DataFrames."""
        self.valid_df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003"],
            "i_intrn": ["A001", "A002", "A003"],
            "i_siren": ["111111111", "222222222", "333333333"],
            "PDO": [0.02, 0.03, 0.04],
        })

    def test_tu_099_validate_dataframe_required_columns_present(self) -> None:
        """TU-099: Verify validation passes when all required columns are present.
        
        Tests that validation function returns True when all columns
        specified in the required list are present in the DataFrame.
        """
        # Arrange
        from common.utils import validate_dataframe
        
        required_columns = ["i_uniq_kpi", "i_intrn", "PDO"]
        
        # Act
        result = validate_dataframe(self.valid_df, required_columns)
        
        # Assert
        self.assertTrue(result)

    def test_tu_100_validate_dataframe_missing_column_raises_error(self) -> None:
        """TU-100: Test validation failure when required column is missing.
        
        When a column from required_columns is missing, should raise
        ValueError with the missing column name in the message.
        """
        # Arrange
        from common.utils import validate_dataframe
        
        required_columns = ["i_uniq_kpi", "missing_column", "PDO"]
        
        # Act & Assert
        with self.assertRaises(ValueError) as context:
            validate_dataframe(self.valid_df, required_columns)
        
        self.assertIn("missing_column", str(context.exception))

    def test_tu_101_validate_dataframe_empty_dataframe(self) -> None:
        """TU-101: Test validation with empty DataFrame (no rows).
        
        An empty DataFrame with correct schema should pass validation
        (columns exist even if no data rows).
        """
        # Arrange
        from common.utils import validate_dataframe
        
        empty_df = pl.DataFrame({
            "i_uniq_kpi": pl.Series([], dtype=pl.Utf8),
            "i_intrn": pl.Series([], dtype=pl.Utf8),
            "PDO": pl.Series([], dtype=pl.Float64),
        })
        required_columns = ["i_uniq_kpi", "i_intrn", "PDO"]
        
        # Act
        result = validate_dataframe(empty_df, required_columns)
        
        # Assert
        self.assertTrue(result)


class TestCheckDtypes(TestCase):
    """Unit tests for the check_dtypes function."""

    def setUp(self) -> None:
        """Set up test fixtures with typed DataFrames."""
        self.typed_df = pl.DataFrame({
            "i_uniq_kpi": pl.Series(["E001", "E002"], dtype=pl.Utf8),
            "PDO": pl.Series([0.02, 0.03], dtype=pl.Float64),
            "count": pl.Series([1, 2], dtype=pl.Int64),
        })

    def test_tu_102_check_dtypes_correct_types(self) -> None:
        """TU-102: Verify dtype check passes with matching expected types.
        
        Tests that check_dtypes returns True when all columns have
        the expected Polars data types.
        """
        # Arrange
        from common.utils import check_dtypes
        
        expected_dtypes = {
            "i_uniq_kpi": pl.Utf8,
            "PDO": pl.Float64,
            "count": pl.Int64,
        }
        
        # Act
        result = check_dtypes(self.typed_df, expected_dtypes)
        
        # Assert
        self.assertTrue(result)

    def test_tu_103_check_dtypes_type_mismatch(self) -> None:
        """TU-103: Test behavior when column dtype doesn't match expected type.
        
        When a column has Float64 but expected is Int64, should either
        return False or raise TypeError with details.
        """
        # Arrange
        from common.utils import check_dtypes
        
        expected_dtypes = {
            "PDO": pl.Int64,  # Mismatch: actual is Float64
        }
        
        # Act
        result = check_dtypes(self.typed_df, expected_dtypes)
        
        # Assert
        self.assertFalse(result)


class TestSafeCastColumn(TestCase):
    """Unit tests for the safe_cast_column function."""

    def test_tu_104_safe_cast_column_string_to_float(self) -> None:
        """TU-104: Verify safe casting from string to float handles errors.
        
        Tests that invalid strings ('N/A', 'ERROR') become NULL after
        safe casting, while valid numeric strings are converted.
        """
        # Arrange
        from common.utils import safe_cast_column
        
        df = pl.DataFrame({
            "value_str": ["1.5", "2.0", "N/A", "ERROR", "3.5"],
        })
        
        # Act
        result = safe_cast_column(df, "value_str", pl.Float64)
        
        # Assert
        values = result["value_str"].to_list()
        self.assertAlmostEqual(values[0], 1.5)
        self.assertAlmostEqual(values[1], 2.0)
        self.assertIsNone(values[2])  # 'N/A' -> NULL
        self.assertIsNone(values[3])  # 'ERROR' -> NULL
        self.assertAlmostEqual(values[4], 3.5)


class TestEnsureDirectory(TestCase):
    """Unit tests for the ensure_directory function."""

    @patch("os.makedirs")
    @patch("os.path.exists")
    def test_tu_105_ensure_directory_creates_missing(
        self,
        mock_exists: MagicMock,
        mock_makedirs: MagicMock
    ) -> None:
        """TU-105: Verify directory is created when it doesn't exist.
        
        Tests that ensure_directory calls os.makedirs when the
        specified directory path does not exist.
        """
        # Arrange
        from common.utils import ensure_directory
        
        mock_exists.return_value = False
        
        # Act
        ensure_directory('/path/to/new/directory')
        
        # Assert
        mock_makedirs.assert_called_once_with('/path/to/new/directory', exist_ok=True)

    @patch("os.makedirs")
    @patch("os.path.exists")
    def test_tu_106_ensure_directory_already_exists(
        self,
        mock_exists: MagicMock,
        mock_makedirs: MagicMock
    ) -> None:
        """TU-106: Verify no action when directory already exists.
        
        When the directory already exists, makedirs should not be called
        or should use exist_ok=True to avoid errors.
        """
        # Arrange
        from common.utils import ensure_directory
        
        mock_exists.return_value = True
        
        # Act
        ensure_directory('/path/to/existing/directory')
        
        # Assert
        # Either not called, or called with exist_ok=True
        if mock_makedirs.called:
            call_kwargs = mock_makedirs.call_args[1]
            self.assertTrue(call_kwargs.get('exist_ok', False))


if __name__ == "__main__":
    main()
