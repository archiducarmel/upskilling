"""Unit tests for the con_cos module.

This module contains tests for the CosManager class that handles
IBM Cloud Object Storage (COS) connections and file operations.

Test IDs: TU-092 to TU-098
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch, ANY
import os
import io


class TestCosManagerInit(TestCase):
    """Unit tests for CosManager.__init__()."""

    @patch.dict(os.environ, {
        'COS_ML_API_KEY_ID': 'test_api_key',
        'COS_ML_SERVICE_INSTANCE_ID': 'test_instance_id',
        'COS_ML_ENDPOINT_URL': 'https://s3.example.com',
        'COS_ML_AUTH_URL': 'https://iam.example.com/identity/token',
    })
    @patch('common.con_cos.ibm_boto3')
    def test_tu_092_init_retrieves_all_env_variables(
        self,
        mock_boto3: MagicMock
    ) -> None:
        """TU-092: Verify constructor retrieves 4 required COS environment variables.
        
        Tests that __init__ correctly retrieves COS_ML_API_KEY_ID,
        COS_ML_SERVICE_INSTANCE_ID, COS_ML_ENDPOINT_URL, COS_ML_AUTH_URL.
        """
        # Arrange
        from common.con_cos import CosManager
        
        mock_client = MagicMock()
        mock_boto3.client.return_value = mock_client
        
        # Act
        cos_manager = CosManager()
        
        # Assert
        self.assertEqual(cos_manager.api_key_id, 'test_api_key')
        self.assertEqual(cos_manager.service_instance_id, 'test_instance_id')
        self.assertEqual(cos_manager.endpoint_url, 'https://s3.example.com')
        mock_boto3.client.assert_called_once()

    @patch.dict(os.environ, {
        'COS_ML_SERVICE_INSTANCE_ID': 'test_instance_id',
        'COS_ML_ENDPOINT_URL': 'https://s3.example.com',
        'COS_ML_AUTH_URL': 'https://iam.example.com/identity/token',
    }, clear=True)
    def test_tu_096_init_missing_api_key_raises_error(self) -> None:
        """TU-096: Test ValueError when COS_ML_API_KEY_ID is missing.
        
        Missing API key should raise ValueError with explicit message
        identifying which variable is missing.
        """
        # Arrange
        from common.con_cos import CosManager
        
        # Act & Assert
        with self.assertRaises(ValueError) as context:
            CosManager()
        
        self.assertIn('COS_ML_API_KEY_ID', str(context.exception))


class TestCosManagerDownload(TestCase):
    """Unit tests for CosManager download operations."""

    @patch.dict(os.environ, {
        'COS_ML_API_KEY_ID': 'test_api_key',
        'COS_ML_SERVICE_INSTANCE_ID': 'test_instance_id',
        'COS_ML_ENDPOINT_URL': 'https://s3.example.com',
        'COS_ML_AUTH_URL': 'https://iam.example.com/identity/token',
    })
    @patch('common.con_cos.ibm_boto3')
    def test_tu_093_download_file_success(
        self,
        mock_boto3: MagicMock
    ) -> None:
        """TU-093: Verify successful file download from COS bucket.
        
        Tests that download_file correctly retrieves a file from the
        specified bucket and key, saving it to the local path.
        """
        # Arrange
        from common.con_cos import CosManager
        
        mock_client = MagicMock()
        mock_boto3.client.return_value = mock_client
        
        cos_manager = CosManager()
        
        # Act
        cos_manager.download_file(
            bucket='test-bucket',
            key='models/model_v1.pkl',
            local_path='/tmp/model.pkl'
        )
        
        # Assert
        mock_client.download_file.assert_called_once_with(
            'test-bucket',
            'models/model_v1.pkl',
            '/tmp/model.pkl'
        )

    @patch.dict(os.environ, {
        'COS_ML_API_KEY_ID': 'test_api_key',
        'COS_ML_SERVICE_INSTANCE_ID': 'test_instance_id',
        'COS_ML_ENDPOINT_URL': 'https://s3.example.com',
        'COS_ML_AUTH_URL': 'https://iam.example.com/identity/token',
    })
    @patch('common.con_cos.ibm_boto3')
    def test_tu_094_download_file_not_found(
        self,
        mock_boto3: MagicMock
    ) -> None:
        """TU-094: Test behavior when requested file does not exist in COS.
        
        When the key does not exist in the bucket, download_file should
        raise a clear exception (botocore.exceptions.ClientError).
        """
        # Arrange
        from common.con_cos import CosManager
        from botocore.exceptions import ClientError
        
        mock_client = MagicMock()
        mock_client.download_file.side_effect = ClientError(
            {'Error': {'Code': '404', 'Message': 'Not Found'}},
            'GetObject'
        )
        mock_boto3.client.return_value = mock_client
        
        cos_manager = CosManager()
        
        # Act & Assert
        with self.assertRaises(ClientError):
            cos_manager.download_file(
                bucket='test-bucket',
                key='models/inexistant.pkl',
                local_path='/tmp/model.pkl'
            )


class TestCosManagerUpload(TestCase):
    """Unit tests for CosManager upload operations."""

    @patch.dict(os.environ, {
        'COS_ML_API_KEY_ID': 'test_api_key',
        'COS_ML_SERVICE_INSTANCE_ID': 'test_instance_id',
        'COS_ML_ENDPOINT_URL': 'https://s3.example.com',
        'COS_ML_AUTH_URL': 'https://iam.example.com/identity/token',
    })
    @patch('common.con_cos.ibm_boto3')
    def test_tu_095_upload_file_success(
        self,
        mock_boto3: MagicMock
    ) -> None:
        """TU-095: Verify successful file upload to COS bucket.
        
        Tests that upload_file correctly sends a local file to the
        specified bucket and key.
        """
        # Arrange
        from common.con_cos import CosManager
        
        mock_client = MagicMock()
        mock_boto3.client.return_value = mock_client
        
        cos_manager = CosManager()
        
        # Act
        cos_manager.upload_file(
            local_path='/tmp/results.csv',
            bucket='test-bucket',
            key='outputs/results_2024.csv'
        )
        
        # Assert
        mock_client.upload_file.assert_called_once_with(
            '/tmp/results.csv',
            'test-bucket',
            'outputs/results_2024.csv'
        )

    @patch.dict(os.environ, {
        'COS_ML_API_KEY_ID': 'test_api_key',
        'COS_ML_SERVICE_INSTANCE_ID': 'test_instance_id',
        'COS_ML_ENDPOINT_URL': 'https://s3.example.com',
        'COS_ML_AUTH_URL': 'https://iam.example.com/identity/token',
    })
    @patch('common.con_cos.ibm_boto3')
    @patch('os.path.exists')
    def test_tu_097_upload_file_local_not_found(
        self,
        mock_exists: MagicMock,
        mock_boto3: MagicMock
    ) -> None:
        """TU-097: Test behavior when local file does not exist for upload.
        
        When the local file to upload does not exist, should raise
        FileNotFoundError before attempting the upload.
        """
        # Arrange
        from common.con_cos import CosManager
        
        mock_client = MagicMock()
        mock_client.upload_file.side_effect = FileNotFoundError(
            "Local file not found: /tmp/inexistant.csv"
        )
        mock_boto3.client.return_value = mock_client
        mock_exists.return_value = False
        
        cos_manager = CosManager()
        
        # Act & Assert
        with self.assertRaises(FileNotFoundError):
            cos_manager.upload_file(
                local_path='/tmp/inexistant.csv',
                bucket='test-bucket',
                key='outputs/results.csv'
            )


class TestCosManagerListFiles(TestCase):
    """Unit tests for CosManager list operations."""

    @patch.dict(os.environ, {
        'COS_ML_API_KEY_ID': 'test_api_key',
        'COS_ML_SERVICE_INSTANCE_ID': 'test_instance_id',
        'COS_ML_ENDPOINT_URL': 'https://s3.example.com',
        'COS_ML_AUTH_URL': 'https://iam.example.com/identity/token',
    })
    @patch('common.con_cos.ibm_boto3')
    def test_tu_098_list_files_with_prefix(
        self,
        mock_boto3: MagicMock
    ) -> None:
        """TU-098: Verify list_files returns files matching prefix pattern.
        
        Tests that listing files in a bucket with a prefix correctly
        filters and returns only matching keys.
        """
        # Arrange
        from common.con_cos import CosManager
        
        mock_client = MagicMock()
        mock_client.list_objects_v2.return_value = {
            'Contents': [
                {'Key': 'models/model_v1.pkl', 'Size': 1024},
                {'Key': 'models/model_v2.pkl', 'Size': 2048},
                {'Key': 'models/config.yml', 'Size': 512},
            ]
        }
        mock_boto3.client.return_value = mock_client
        
        cos_manager = CosManager()
        
        # Act
        result = cos_manager.list_files(bucket='test-bucket', prefix='models/')
        
        # Assert
        mock_client.list_objects_v2.assert_called_once_with(
            Bucket='test-bucket',
            Prefix='models/'
        )
        self.assertEqual(len(result), 3)
        self.assertIn('models/model_v1.pkl', [f['Key'] for f in result])


if __name__ == "__main__":
    main()
