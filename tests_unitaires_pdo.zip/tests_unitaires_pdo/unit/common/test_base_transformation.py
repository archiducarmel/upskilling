"""Unit tests for the base_transformation module.

This module contains tests for the BaseTransformation class that provides
common DataFrame transformation utilities and pipeline orchestration.

Test IDs: TU-119 to TU-122
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch, ANY
import polars as pl


class TestBaseTransformationInit(TestCase):
    """Unit tests for BaseTransformation initialization."""

    def test_tu_119_init_with_valid_config(self) -> None:
        """TU-119: Verify initialization with valid configuration dictionary.
        
        Tests that BaseTransformation correctly initializes with a
        configuration dict containing transformation parameters.
        """
        # Arrange
        from common.base_transformation import BaseTransformation
        
        config = {
            'transformations': {
                'encoding': True,
                'scaling': False,
            },
            'columns': ['col_a', 'col_b'],
        }
        
        # Act
        transformer = BaseTransformation(config=config)
        
        # Assert
        self.assertIsNotNone(transformer)
        self.assertEqual(transformer.config, config)
        self.assertTrue(transformer.config['transformations']['encoding'])

    def test_tu_120_init_with_none_config(self) -> None:
        """TU-120: Test initialization when config is None.
        
        When no config is provided, BaseTransformation should use
        default configuration or raise ValueError.
        """
        # Arrange
        from common.base_transformation import BaseTransformation
        
        # Act & Assert
        try:
            transformer = BaseTransformation(config=None)
            # If no exception, verify default config is used
            self.assertIsNotNone(transformer.config)
        except (ValueError, TypeError) as e:
            # Expected: explicit error when config is None
            self.assertIsInstance(e, (ValueError, TypeError))


class TestBaseTransformationTransform(TestCase):
    """Unit tests for BaseTransformation.transform() method."""

    def setUp(self) -> None:
        """Set up test fixtures with sample DataFrames."""
        self.sample_df = pl.DataFrame({
            "col_a": [1, 2, 3, 4, 5],
            "col_b": ["a", "b", "c", "d", "e"],
            "col_c": [1.0, 2.0, 3.0, 4.0, 5.0],
        })

    def test_tu_121_transform_applies_configured_operations(self) -> None:
        """TU-121: Verify transform applies all configured operations.
        
        Tests that the transform method applies encoding, filtering,
        and other operations specified in the configuration.
        """
        # Arrange
        from common.base_transformation import BaseTransformation
        
        config = {
            'transformations': {
                'rename': {'col_a': 'column_a'},
                'select': ['column_a', 'col_b'],
            },
        }
        
        transformer = BaseTransformation(config=config)
        
        # Act
        result = transformer.transform(self.sample_df)
        
        # Assert
        self.assertIn('column_a', result.columns)
        self.assertNotIn('col_a', result.columns)

    def test_tu_122_transform_preserves_row_count(self) -> None:
        """TU-122: Verify transform preserves row count when no filtering.
        
        When configuration doesn't include filtering operations,
        the output DataFrame should have the same number of rows.
        """
        # Arrange
        from common.base_transformation import BaseTransformation
        
        config = {
            'transformations': {
                'encoding': True,
            },
        }
        
        transformer = BaseTransformation(config=config)
        original_count = len(self.sample_df)
        
        # Act
        result = transformer.transform(self.sample_df)
        
        # Assert
        self.assertEqual(len(result), original_count)


class TestBaseTransformationValidate(TestCase):
    """Unit tests for BaseTransformation.validate() method."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.valid_df = pl.DataFrame({
            "required_col": [1, 2, 3],
            "optional_col": ["a", "b", "c"],
        })

    def test_tu_123_validate_required_columns_present(self) -> None:
        """TU-123: Verify validation passes with all required columns.
        
        Tests that validate returns True when all columns specified
        in required_columns configuration are present.
        """
        # Arrange
        from common.base_transformation import BaseTransformation
        
        config = {
            'required_columns': ['required_col'],
        }
        
        transformer = BaseTransformation(config=config)
        
        # Act
        result = transformer.validate(self.valid_df)
        
        # Assert
        self.assertTrue(result)

    def test_tu_124_validate_missing_column_raises_error(self) -> None:
        """TU-124: Test validation fails when required column is missing.
        
        When a required column is missing from the DataFrame,
        validate should return False or raise ValueError.
        """
        # Arrange
        from common.base_transformation import BaseTransformation
        
        config = {
            'required_columns': ['required_col', 'missing_col'],
        }
        
        transformer = BaseTransformation(config=config)
        
        # Act
        result = transformer.validate(self.valid_df)
        
        # Assert
        self.assertFalse(result)


if __name__ == "__main__":
    main()
