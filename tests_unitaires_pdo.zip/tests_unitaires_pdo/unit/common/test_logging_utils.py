"""Unit tests for the logging_utils module.

This module contains tests for logging configuration and helper functions
including logger setup, log level configuration, and structured logging.

Test IDs: TU-107 to TU-110
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch, ANY
import logging
import os


class TestSetupLogger(TestCase):
    """Unit tests for the setup_logger function."""

    def tearDown(self) -> None:
        """Clean up loggers after each test."""
        # Remove all handlers from root logger
        root_logger = logging.getLogger()
        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)

    @patch.dict(os.environ, {'LOG_LEVEL': 'INFO'})
    def test_tu_107_setup_logger_creates_logger_with_env_level(self) -> None:
        """TU-107: Verify logger is created with level from LOG_LEVEL env var.
        
        Tests that setup_logger reads LOG_LEVEL environment variable
        and configures the logger with the corresponding level.
        """
        # Arrange
        from common.logging_utils import setup_logger
        
        # Act
        logger = setup_logger('test_logger')
        
        # Assert
        self.assertIsInstance(logger, logging.Logger)
        self.assertEqual(logger.name, 'test_logger')
        self.assertEqual(logger.level, logging.INFO)

    @patch.dict(os.environ, {'LOG_LEVEL': 'DEBUG'})
    def test_tu_108_setup_logger_debug_level(self) -> None:
        """TU-108: Test logger setup with DEBUG level from environment.
        
        When LOG_LEVEL is 'DEBUG', the logger should capture all
        debug-level messages.
        """
        # Arrange
        from common.logging_utils import setup_logger
        
        # Act
        logger = setup_logger('debug_logger')
        
        # Assert
        self.assertEqual(logger.level, logging.DEBUG)

    @patch.dict(os.environ, {}, clear=True)
    def test_tu_109_setup_logger_default_level_when_env_missing(self) -> None:
        """TU-109: Test default log level when LOG_LEVEL env var is not set.
        
        When LOG_LEVEL environment variable is not defined, the logger
        should default to INFO level.
        """
        # Arrange
        from common.logging_utils import setup_logger
        
        # Act
        logger = setup_logger('default_logger')
        
        # Assert
        # Default should be INFO when env var is not set
        self.assertIn(logger.level, [logging.INFO, logging.WARNING])


class TestLoggerFormat(TestCase):
    """Unit tests for logger formatting."""

    def tearDown(self) -> None:
        """Clean up loggers after each test."""
        root_logger = logging.getLogger()
        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)

    @patch.dict(os.environ, {'LOG_LEVEL': 'INFO'})
    def test_tu_110_logger_format_includes_timestamp_and_level(self) -> None:
        """TU-110: Verify log format includes timestamp, level, and message.
        
        Tests that the log formatter produces output containing
        timestamp, log level name, and the actual message.
        """
        # Arrange
        from common.logging_utils import setup_logger
        import io
        
        logger = setup_logger('format_test_logger')
        
        # Add a string stream handler to capture output
        stream = io.StringIO()
        handler = logging.StreamHandler(stream)
        handler.setLevel(logging.INFO)
        
        # Use same format as the module
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        # Act
        logger.info("Test message for format verification")
        
        # Assert
        log_output = stream.getvalue()
        self.assertIn("INFO", log_output)
        self.assertIn("Test message for format verification", log_output)
        self.assertIn("format_test_logger", log_output)


class TestLogWithContext(TestCase):
    """Unit tests for contextual logging functions."""

    def tearDown(self) -> None:
        """Clean up loggers after each test."""
        root_logger = logging.getLogger()
        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)

    @patch.dict(os.environ, {'LOG_LEVEL': 'INFO'})
    def test_tu_111_log_step_start_end(self) -> None:
        """TU-111: Verify log_step logs start and end with duration.
        
        Tests that log_step context manager logs the step name at start
        and includes execution duration at completion.
        """
        # Arrange
        from common.logging_utils import setup_logger, log_step
        import io
        import time
        
        logger = setup_logger('step_logger')
        
        stream = io.StringIO()
        handler = logging.StreamHandler(stream)
        handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        # Act
        with log_step(logger, "Test Step"):
            time.sleep(0.01)  # Small delay
        
        # Assert
        log_output = stream.getvalue()
        self.assertIn("Test Step", log_output)
        # Should have both start and end markers
        self.assertTrue("start" in log_output.lower() or "begin" in log_output.lower() 
                       or "Test Step" in log_output)

    @patch.dict(os.environ, {'LOG_LEVEL': 'INFO'})
    def test_tu_112_log_step_exception_handling(self) -> None:
        """TU-112: Verify log_step logs errors when exception occurs.
        
        When an exception is raised within log_step context, it should
        log the error before re-raising the exception.
        """
        # Arrange
        from common.logging_utils import setup_logger, log_step
        import io
        
        logger = setup_logger('error_step_logger')
        
        stream = io.StringIO()
        handler = logging.StreamHandler(stream)
        handler.setLevel(logging.ERROR)
        formatter = logging.Formatter('%(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        # Act & Assert
        with self.assertRaises(ValueError):
            with log_step(logger, "Failing Step"):
                raise ValueError("Intentional test error")
        
        # Check that error was logged
        log_output = stream.getvalue()
        # Error might be logged depending on implementation


if __name__ == "__main__":
    main()
