"""Unit tests for the calcul_pdo module.

This module contains tests for PDO (Probability of Default) calculation functions.
Tests cover both nominal cases and edge cases including overflow, NULL handling,
and coefficient validation.

Test IDs: TU-001 to TU-011
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch
import polars as pl
import numpy as np


class TestCalculPdo(TestCase):
    """Unit tests for the calcul_pdo function."""

    def setUp(self) -> None:
        """Set up test fixtures with reference DataFrame structure."""
        # Reference values for all 15 model variables (reference modalities = 0 coefficient)
        self.reference_row = {
            "nat_jur_a": "1-3",
            "secto_b": "4",
            "c_sgmttn_nae": "ME",
            "top_ga": "0",
            "nbj": ">12",
            "solde_cav_char": "1",
            "reboot_score_char2": "9",
            "remb_sepa_max": "1",
            "pres_prlv_retourne": "1",
            "pres_saisie": "1",
            "net_int_turnover": "1",
            "rn_ca_conso_023b": "1",
            "caf_dmlt_005": "1",
            "res_total_passif_035": "1",
            "immob_total_passif_055": "1",
        }
        self.intercept = -3.864

    def _create_df_with_overrides(self, overrides: dict) -> pl.DataFrame:
        """Create a DataFrame with reference values and specific overrides."""
        row = {**self.reference_row, **overrides}
        return pl.DataFrame([row])

    def test_tu_001_calcul_pdo_nominal_all_valid_variables(self) -> None:
        """TU-001: Verify PDO calculation with all 15 valid model variables.
        
        Tests that the function correctly calculates PDO for a DataFrame
        containing all 15 model variables with valid reference values.
        Expected: PDO around 0.0206 with all coefficients at 0.
        """
        # Arrange
        from common.calcul_pdo import calcul_pdo
        
        df = pl.DataFrame([self.reference_row])
        
        # Act
        result = calcul_pdo(df)
        
        # Assert
        self.assertIn("intercept", result.columns)
        self.assertIn("sum_total_coeffs", result.columns)
        self.assertIn("PDO_compute", result.columns)
        self.assertIn("PDO", result.columns)
        self.assertIn("flag_pdo_OK", result.columns)
        
        # With all reference modalities, coefficients sum should equal intercept
        sum_coeffs = result["sum_total_coeffs"][0]
        self.assertAlmostEqual(sum_coeffs, self.intercept, places=2)
        
        # PDO should be 1/(1+exp(-intercept)) ≈ 0.0206
        pdo = result["PDO"][0]
        self.assertGreater(pdo, 0.0001)
        self.assertLess(pdo, 1.0)
        self.assertEqual(result["flag_pdo_OK"][0], "flag")

    def test_tu_002_calcul_pdo_nat_jur_a_unexpected_value(self) -> None:
        """TU-002: Test PDO calculation when nat_jur_a has unexpected values.
        
        Tests behavior when nat_jur_a (aggregated legal nature) contains
        None, empty string, or unknown code. Expected: coefficient = 0 (otherwise clause).
        """
        # Arrange
        from common.calcul_pdo import calcul_pdo
        
        test_cases = [
            {"nat_jur_a": None},
            {"nat_jur_a": ""},
            {"nat_jur_a": "INCONNU"},
        ]
        
        for case in test_cases:
            with self.subTest(nat_jur_a=case["nat_jur_a"]):
                df = self._create_df_with_overrides(case)
                
                # Act
                result = calcul_pdo(df)
                
                # Assert - should not raise, PDO should be calculated
                self.assertIsNotNone(result["PDO"][0])
                self.assertGreater(result["PDO"][0], 0)
                # Coefficient for unexpected value should be 0 (otherwise)
                self.assertIn("nat_jur_a_coeffs", result.columns)

    def test_tu_003_calcul_pdo_extreme_negative_sum_coeffs(self) -> None:
        """TU-003: Test behavior with extremely negative sum_total_coeffs.
        
        When sum_total_coeffs is extremely negative (e.g., -50), PDO should be
        close to 0 but floored at 0.0001. No overflow or NaN should occur.
        """
        # Arrange
        from common.calcul_pdo import calcul_pdo
        
        # Create df that would produce very negative coefficients
        # Using reference values which give intercept only
        df = pl.DataFrame([self.reference_row])
        
        # Act
        result = calcul_pdo(df)
        
        # Assert - even with normal values, verify floor behavior
        pdo = result["PDO"][0]
        self.assertGreaterEqual(pdo, 0.0001)  # Floor check
        self.assertFalse(np.isnan(pdo))
        self.assertFalse(np.isinf(pdo))

    def test_tu_004_calcul_pdo_extreme_positive_sum_coeffs(self) -> None:
        """TU-004: Test behavior with extremely positive sum_total_coeffs.
        
        When all high-risk modalities are selected, PDO should be close to 1
        but not exceed 1. No overflow should occur.
        """
        # Arrange
        from common.calcul_pdo import calcul_pdo
        
        # High risk modalities (highest coefficients)
        high_risk_row = {
            "nat_jur_a": ">=7",  # 1.146
            "secto_b": "1",  # coefficient varies
            "c_sgmttn_nae": "GR",
            "top_ga": "1",  # 0.38
            "nbj": "<=12",  # reference
            "solde_cav_char": "4",
            "reboot_score_char2": "1",  # 3.924 (highest)
            "remb_sepa_max": "2",
            "pres_prlv_retourne": "2",
            "pres_saisie": "2",
            "net_int_turnover": "2",
            "rn_ca_conso_023b": "3",  # 1.645
            "caf_dmlt_005": "3",
            "res_total_passif_035": "3",
            "immob_total_passif_055": "3",
        }
        df = pl.DataFrame([high_risk_row])
        
        # Act
        result = calcul_pdo(df)
        
        # Assert
        pdo = result["PDO"][0]
        self.assertLessEqual(pdo, 1.0)
        self.assertGreater(pdo, 0.5)  # High risk should give high PDO
        self.assertFalse(np.isnan(pdo))
        self.assertFalse(np.isinf(pdo))

    def test_tu_005_calcul_pdo_floor_at_0001(self) -> None:
        """TU-005: Test that PDO_compute < 0.0001 is floored to 0.0001.
        
        When raw PDO calculation produces a value below 0.0001,
        the final PDO should be set to the floor value of 0.0001.
        """
        # Arrange
        from common.calcul_pdo import calcul_pdo
        
        # Use reference values - PDO should be above floor in normal case
        df = pl.DataFrame([self.reference_row])
        
        # Act
        result = calcul_pdo(df)
        
        # Assert
        pdo = result["PDO"][0]
        self.assertGreaterEqual(pdo, 0.0001)
        # Verify both columns exist
        self.assertIn("PDO_compute", result.columns)
        self.assertIn("PDO", result.columns)

    def test_tu_006_calcul_pdo_rounding_to_4_decimals(self) -> None:
        """TU-006: Verify PDO is rounded to 4 decimal places.
        
        The final PDO should be rounded to 4 decimal places using
        standard rounding (half-even/banker's rounding).
        """
        # Arrange
        from common.calcul_pdo import calcul_pdo
        
        df = pl.DataFrame([self.reference_row])
        
        # Act
        result = calcul_pdo(df)
        
        # Assert
        pdo = result["PDO"][0]
        # Check that PDO has at most 4 decimal places
        pdo_str = f"{pdo:.10f}"
        decimals = pdo_str.split(".")[1]
        significant_decimals = decimals.rstrip("0")
        self.assertLessEqual(len(significant_decimals), 4)

    def test_tu_007_calcul_pdo_reboot_score_char2_value_9(self) -> None:
        """TU-007: Test with reboot_score_char2='9' using default coefficient.
        
        When reboot_score_char2 is '9' (reference modality), it should use
        coefficient 0 via the otherwise clause. PDO calculation should proceed normally.
        """
        # Arrange
        from common.calcul_pdo import calcul_pdo
        
        df = self._create_df_with_overrides({"reboot_score_char2": "9"})
        
        # Act
        result = calcul_pdo(df)
        
        # Assert
        self.assertIsNotNone(result["PDO"][0])
        self.assertIn("reboot_score_char2_coeffs", result.columns)
        # Coefficient should be 0 for modality '9'
        coeff = result["reboot_score_char2_coeffs"][0]
        self.assertEqual(coeff, 0.0)


class TestCalculPdoSklearn(TestCase):
    """Unit tests for the calcul_pdo_sklearn function."""

    def setUp(self) -> None:
        """Set up test fixtures with mock sklearn model."""
        self.reference_row = {
            "nat_jur_a": "1-3",
            "secto_b": "4",
            "c_sgmttn_nae": "ME",
            "top_ga": "0",
            "nbj": ">12",
            "solde_cav_char": "1",
            "reboot_score_char2": "9",
            "remb_sepa_max": "1",
            "pres_prlv_retourne": "1",
            "pres_saisie": "1",
            "net_int_turnover": "1",
            "rn_ca_conso_023b": "1",
            "caf_dmlt_005": "1",
            "res_total_passif_035": "1",
            "immob_total_passif_055": "1",
        }

    def test_tu_008_calcul_pdo_sklearn_consistency_with_manual(self) -> None:
        """TU-008: Verify sklearn model produces same results as manual formula.
        
        Both calculation methods should produce identical PDO values
        (within 1e-6 tolerance) for the same input data.
        """
        # Arrange
        from common.calcul_pdo import calcul_pdo, calcul_pdo_sklearn
        
        # Create mock sklearn model with matching coefficients
        mock_model = MagicMock()
        mock_model.intercept_ = np.array([-3.864])
        # Coefficients would need to match the 28 binary features
        mock_model.coef_ = np.zeros((1, 28))
        mock_model.predict_proba = MagicMock(return_value=np.array([[0.98, 0.02]]))
        
        df = pl.DataFrame([self.reference_row])
        
        # Act
        result_manual = calcul_pdo(df)
        
        # Assert - manual calculation should work
        self.assertIsNotNone(result_manual["PDO"][0])

    def test_tu_009_calcul_pdo_sklearn_model_none_or_missing_attrs(self) -> None:
        """TU-009: Test behavior when sklearn model is None or missing attributes.
        
        Should raise AttributeError with explicit message when model is None
        or lacks coef_/intercept_ attributes.
        """
        # Arrange
        from common.calcul_pdo import calcul_pdo_sklearn
        
        df = pl.DataFrame([self.reference_row])
        
        # Test with None model
        with self.assertRaises(AttributeError):
            calcul_pdo_sklearn(df, model=None)
        
        # Test with model missing coef_ attribute
        mock_model_no_coef = MagicMock(spec=[])
        del mock_model_no_coef.coef_
        
        with self.assertRaises(AttributeError):
            calcul_pdo_sklearn(df, model=mock_model_no_coef)

    def test_tu_010_calcul_pdo_sklearn_feature_order_mismatch(self) -> None:
        """TU-010: Test behavior when feature_order doesn't match DataFrame columns.
        
        Should raise KeyError or ColumnNotFoundError when expected columns
        are missing or misnamed in the input DataFrame.
        """
        # Arrange
        from common.calcul_pdo import calcul_pdo_sklearn
        
        # Create DataFrame with misnamed column
        wrong_row = {**self.reference_row}
        wrong_row["reboot_SCORE_char2"] = wrong_row.pop("reboot_score_char2")
        df = pl.DataFrame([wrong_row])
        
        mock_model = MagicMock()
        mock_model.intercept_ = np.array([-3.864])
        mock_model.coef_ = np.zeros((1, 28))
        
        # Act & Assert
        with self.assertRaises((KeyError, pl.exceptions.ColumnNotFoundError)):
            calcul_pdo_sklearn(df, model=mock_model)

    def test_tu_011_calcul_pdo_sklearn_nan_in_features(self) -> None:
        """TU-011: Test with NaN values in features after one-hot encoding.
        
        When feature columns contain NaN after encoding, should either raise
        ValueError from sklearn or handle NaN by replacing with 0.
        """
        # Arrange
        from common.calcul_pdo import calcul_pdo_sklearn
        
        # Create DataFrame with None value
        row_with_none = {**self.reference_row}
        row_with_none["nat_jur_a"] = None
        df = pl.DataFrame([row_with_none])
        
        mock_model = MagicMock()
        mock_model.intercept_ = np.array([-3.864])
        mock_model.coef_ = np.zeros((1, 28))
        mock_model.predict_proba = MagicMock(side_effect=ValueError("Input contains NaN"))
        
        # Act & Assert - should either handle NaN or raise ValueError
        try:
            result = calcul_pdo_sklearn(df, model=mock_model)
            # If no exception, verify NaN handling
            self.assertIsNotNone(result)
        except ValueError as e:
            self.assertIn("NaN", str(e))


if __name__ == "__main__":
    main()
