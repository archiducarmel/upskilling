"""Unit tests for the retrieve_sql_query module.

This module contains tests for SQL query retrieval functions that load
SQL files from the queries directory with parameter substitution.

Test IDs: TU-101 to TU-105
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch, mock_open
import os


class TestRetrieveSqlQuery(TestCase):
    """Unit tests for the retrieve_sql_query function."""

    def setUp(self) -> None:
        """Set up test fixtures with sample SQL content."""
        self.sample_sql = """
        SELECT 
            i_uniq_kpi,
            i_intrn,
            i_siren
        FROM {schema}.{table}
        WHERE d_calcul = '{date}'
        """
        self.expected_sql = """
        SELECT 
            i_uniq_kpi,
            i_intrn,
            i_siren
        FROM hive_prod.enterprise_table
        WHERE d_calcul = '2024-01-15'
        """

    @patch('builtins.open', new_callable=mock_open)
    def test_tu_101_retrieve_sql_query_valid_file(
        self, 
        mock_file: MagicMock
    ) -> None:
        """TU-101: Verify retrieve_sql_query reads SQL file correctly.
        
        Tests that a valid SQL file is correctly read and returned
        as a string without modification.
        """
        # Arrange
        from common.sql.retrieve_sql_query import retrieve_sql_query
        
        mock_file.return_value.read.return_value = self.sample_sql
        query_name = 'query_starburst_df_main'
        
        # Act
        result = retrieve_sql_query(query_name)
        
        # Assert
        self.assertIsInstance(result, str)
        self.assertIn('SELECT', result)
        self.assertIn('i_uniq_kpi', result)

    @patch('builtins.open', side_effect=FileNotFoundError("File not found"))
    def test_tu_102_retrieve_sql_query_file_not_found(
        self, 
        mock_file: MagicMock
    ) -> None:
        """TU-102: Test behavior when SQL file doesn't exist.
        
        Should raise FileNotFoundError with explicit message
        containing the query name or file path.
        """
        # Arrange
        from common.sql.retrieve_sql_query import retrieve_sql_query
        
        nonexistent_query = 'query_nonexistent'
        
        # Act & Assert
        with self.assertRaises(FileNotFoundError):
            retrieve_sql_query(nonexistent_query)

    @patch('builtins.open', new_callable=mock_open)
    def test_tu_103_retrieve_sql_query_parameter_substitution(
        self, 
        mock_file: MagicMock
    ) -> None:
        """TU-103: Verify parameter substitution in SQL query.
        
        Tests that placeholders like {schema}, {table}, {date} are
        correctly replaced with provided parameter values.
        """
        # Arrange
        from common.sql.retrieve_sql_query import retrieve_sql_query
        
        mock_file.return_value.read.return_value = self.sample_sql
        query_name = 'query_starburst_df_main'
        params = {
            'schema': 'hive_prod',
            'table': 'enterprise_table',
            'date': '2024-01-15'
        }
        
        # Act
        result = retrieve_sql_query(query_name, **params)
        
        # Assert
        self.assertIn('hive_prod', result)
        self.assertIn('enterprise_table', result)
        self.assertIn('2024-01-15', result)
        # Placeholders should be replaced
        self.assertNotIn('{schema}', result)
        self.assertNotIn('{table}', result)
        self.assertNotIn('{date}', result)

    @patch('builtins.open', new_callable=mock_open)
    def test_tu_104_retrieve_sql_query_missing_parameter(
        self, 
        mock_file: MagicMock
    ) -> None:
        """TU-104: Test behavior when required parameter is missing.
        
        When a placeholder exists but the corresponding parameter
        is not provided, should raise KeyError.
        """
        # Arrange
        from common.sql.retrieve_sql_query import retrieve_sql_query
        
        mock_file.return_value.read.return_value = self.sample_sql
        query_name = 'query_starburst_df_main'
        incomplete_params = {
            'schema': 'hive_prod',
            # 'table' and 'date' are missing
        }
        
        # Act & Assert
        with self.assertRaises(KeyError):
            result = retrieve_sql_query(query_name, **incomplete_params)
            # Force format to trigger KeyError
            result.format(**incomplete_params)

    @patch('builtins.open', new_callable=mock_open, read_data="SELECT * FROM table -- {comment}")
    def test_tu_105_retrieve_sql_query_comments_with_placeholders(
        self, 
        mock_file: MagicMock
    ) -> None:
        """TU-105: Test SQL with placeholders in comments.
        
        Placeholders in SQL comments should also be substituted
        or handled gracefully to avoid KeyError.
        """
        # Arrange
        from common.sql.retrieve_sql_query import retrieve_sql_query
        
        query_name = 'query_with_comments'
        params = {'comment': 'This is a test comment'}
        
        # Act
        result = retrieve_sql_query(query_name, **params)
        
        # Assert
        self.assertIn('SELECT * FROM table', result)
        self.assertIn('This is a test comment', result)


class TestGetQueryPath(TestCase):
    """Unit tests for the get_query_path helper function."""

    def test_get_query_path_constructs_correct_path(self) -> None:
        """Test that query path is correctly constructed.
        
        The path should include the queries directory and .sql extension.
        """
        # Arrange
        from common.sql.retrieve_sql_query import get_query_path
        
        query_name = 'query_starburst_df_main'
        
        # Act
        result = get_query_path(query_name)
        
        # Assert
        self.assertIn('queries', result)
        self.assertTrue(result.endswith('.sql'))
        self.assertIn(query_name, result)


if __name__ == "__main__":
    main()
