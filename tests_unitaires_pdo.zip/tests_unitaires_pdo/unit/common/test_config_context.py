"""Unit tests for the config_context module.

This module contains tests for the ConfigContext class that manages
configuration state across the application pipeline.

Test IDs: TU-125 to TU-128
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch
import os


class TestConfigContextSingleton(TestCase):
    """Unit tests for ConfigContext singleton pattern."""

    def test_tu_125_config_context_singleton_instance(self) -> None:
        """TU-125: Verify ConfigContext implements singleton pattern.
        
        Tests that multiple calls to get_instance return the same
        ConfigContext object (same memory address).
        """
        # Arrange
        from common.config_context import ConfigContext
        
        # Act
        instance1 = ConfigContext.get_instance()
        instance2 = ConfigContext.get_instance()
        
        # Assert
        self.assertIs(instance1, instance2)

    def test_tu_126_config_context_reset(self) -> None:
        """TU-126: Verify reset method clears singleton state.
        
        After calling reset(), a new call to get_instance should
        return a fresh instance with default configuration.
        """
        # Arrange
        from common.config_context import ConfigContext
        
        instance1 = ConfigContext.get_instance()
        instance1.set('test_key', 'test_value')
        
        # Act
        ConfigContext.reset()
        instance2 = ConfigContext.get_instance()
        
        # Assert
        # New instance should not have the old key
        self.assertIsNone(instance2.get('test_key', default=None))


class TestConfigContextGetSet(TestCase):
    """Unit tests for ConfigContext get/set operations."""

    def setUp(self) -> None:
        """Reset ConfigContext before each test."""
        from common.config_context import ConfigContext
        ConfigContext.reset()

    def test_tu_127_config_context_get_set(self) -> None:
        """TU-127: Verify get and set methods work correctly.
        
        Tests that set() stores values and get() retrieves them
        with the correct data types.
        """
        # Arrange
        from common.config_context import ConfigContext
        
        ctx = ConfigContext.get_instance()
        
        # Act
        ctx.set('string_val', 'hello')
        ctx.set('int_val', 42)
        ctx.set('float_val', 3.14)
        ctx.set('dict_val', {'key': 'value'})
        
        # Assert
        self.assertEqual(ctx.get('string_val'), 'hello')
        self.assertEqual(ctx.get('int_val'), 42)
        self.assertAlmostEqual(ctx.get('float_val'), 3.14)
        self.assertEqual(ctx.get('dict_val'), {'key': 'value'})

    def test_tu_128_config_context_get_default(self) -> None:
        """TU-128: Verify get returns default for missing keys.
        
        When a key doesn't exist, get() should return the specified
        default value without raising KeyError.
        """
        # Arrange
        from common.config_context import ConfigContext
        
        ctx = ConfigContext.get_instance()
        
        # Act
        result_none = ctx.get('nonexistent_key')
        result_default = ctx.get('nonexistent_key', default='fallback')
        
        # Assert
        self.assertIsNone(result_none)
        self.assertEqual(result_default, 'fallback')


class TestConfigContextEnvironment(TestCase):
    """Unit tests for ConfigContext environment handling."""

    def setUp(self) -> None:
        """Reset ConfigContext before each test."""
        from common.config_context import ConfigContext
        ConfigContext.reset()

    @patch.dict(os.environ, {'APP_ENV': 'production'})
    def test_tu_129_config_context_loads_from_env(self) -> None:
        """TU-129: Verify ConfigContext can load values from environment.
        
        Tests that ConfigContext can read environment variables
        and make them available through get() method.
        """
        # Arrange
        from common.config_context import ConfigContext
        
        ctx = ConfigContext.get_instance()
        
        # Act
        ctx.load_from_env('APP_ENV')
        
        # Assert
        self.assertEqual(ctx.get('APP_ENV'), 'production')

    def test_tu_130_config_context_environment_property(self) -> None:
        """TU-130: Verify environment property returns current environment.
        
        Tests that the environment property correctly returns
        'dev', 'pprod', or 'prod' based on configuration.
        """
        # Arrange
        from common.config_context import ConfigContext
        
        ctx = ConfigContext.get_instance()
        ctx.set('environment', 'dev')
        
        # Act
        env = ctx.environment
        
        # Assert
        self.assertEqual(env, 'dev')
        self.assertIn(env, ['dev', 'pprod', 'prod'])


if __name__ == "__main__":
    main()
