"""Unit tests for the get_env_var module.

This module contains tests for environment variable retrieval functions
used throughout the application for configuration.

Test IDs: TU-096 to TU-100
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch
import os


class TestGetEnvVar(TestCase):
    """Unit tests for the get_env_var function."""

    @patch.dict(os.environ, {'TEST_VAR': 'test_value'})
    def test_tu_096_get_env_var_existing_variable(self) -> None:
        """TU-096: Verify retrieval of existing environment variable.
        
        When the environment variable exists, should return its value
        as a string without modification.
        """
        # Arrange
        from common.utils.get_env_var import get_env_var
        
        # Act
        result = get_env_var('TEST_VAR')
        
        # Assert
        self.assertEqual(result, 'test_value')
        self.assertIsInstance(result, str)

    @patch.dict(os.environ, {}, clear=True)
    def test_tu_097_get_env_var_missing_raises_error(self) -> None:
        """TU-097: Test ValueError when environment variable is missing.
        
        When the environment variable is not set, should raise ValueError
        with explicit message containing the variable name.
        """
        # Arrange
        from common.utils.get_env_var import get_env_var
        
        # Act & Assert
        with self.assertRaises(ValueError) as context:
            get_env_var('NONEXISTENT_VAR')
        
        self.assertIn('NONEXISTENT_VAR', str(context.exception))
        self.assertIn('not set', str(context.exception).lower())

    @patch.dict(os.environ, {'EMPTY_VAR': ''})
    def test_tu_098_get_env_var_empty_string_value(self) -> None:
        """TU-098: Test behavior when variable is set to empty string.
        
        An empty string is a valid value and should be returned as-is,
        not treated as missing.
        """
        # Arrange
        from common.utils.get_env_var import get_env_var
        
        # Act
        result = get_env_var('EMPTY_VAR')
        
        # Assert
        self.assertEqual(result, '')
        self.assertIsInstance(result, str)

    @patch.dict(os.environ, {'WHITESPACE_VAR': '   '})
    def test_tu_099_get_env_var_whitespace_value(self) -> None:
        """TU-099: Test behavior when variable contains only whitespace.
        
        Whitespace-only value should be returned as-is without trimming.
        The caller is responsible for validation if needed.
        """
        # Arrange
        from common.utils.get_env_var import get_env_var
        
        # Act
        result = get_env_var('WHITESPACE_VAR')
        
        # Assert
        self.assertEqual(result, '   ')
        self.assertEqual(len(result), 3)

    @patch.dict(os.environ, {'SPECIAL_VAR': 'value=with=equals&special!chars'})
    def test_tu_100_get_env_var_special_characters(self) -> None:
        """TU-100: Test retrieval of variable with special characters.
        
        Variables containing special characters (=, &, !, etc.) should
        be returned exactly as set, without escaping or modification.
        """
        # Arrange
        from common.utils.get_env_var import get_env_var
        
        # Act
        result = get_env_var('SPECIAL_VAR')
        
        # Assert
        self.assertEqual(result, 'value=with=equals&special!chars')


class TestGetEnvVarWithDefault(TestCase):
    """Unit tests for get_env_var with default value parameter."""

    @patch.dict(os.environ, {}, clear=True)
    def test_get_env_var_with_default_missing_variable(self) -> None:
        """Test that default value is returned when variable is missing.
        
        When the variable is not set and a default is provided,
        should return the default value instead of raising.
        """
        # Arrange
        from common.utils.get_env_var import get_env_var_with_default
        
        # Act
        result = get_env_var_with_default('MISSING_VAR', default='default_value')
        
        # Assert
        self.assertEqual(result, 'default_value')

    @patch.dict(os.environ, {'EXISTING_VAR': 'actual_value'})
    def test_get_env_var_with_default_existing_variable(self) -> None:
        """Test that actual value is returned when variable exists.
        
        When the variable is set, should return its value,
        ignoring the default.
        """
        # Arrange
        from common.utils.get_env_var import get_env_var_with_default
        
        # Act
        result = get_env_var_with_default('EXISTING_VAR', default='ignored')
        
        # Assert
        self.assertEqual(result, 'actual_value')


if __name__ == "__main__":
    main()
