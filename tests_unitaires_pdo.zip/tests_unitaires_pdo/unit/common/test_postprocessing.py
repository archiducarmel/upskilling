"""Unit tests for the postprocessing module.

This module contains tests for DataFrame postprocessing functions including
date addition, deduplication, column renaming, and final file preparation.

Test IDs: TU-070 to TU-075
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch
import polars as pl
from datetime import date


class TestDfPostprocessing(TestCase):
    """Unit tests for the df_postprocessing function."""

    def setUp(self) -> None:
        """Set up test fixtures with base DataFrame structures."""
        self.df_main_ilc = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111111111", "222222222"],
            "PDO": [0.0206, 0.0350],
            "nat_jur_a": ["1-3", ">=7"],
        })
        
        self.unfiltered_df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003"],
            "i_intrn": ["A001", "A002", "A003"],
            "i_siren": ["111111111", "222222222", "333333333"],
        })

    def test_tu_070_df_postprocessing_date_column_added(self) -> None:
        """TU-070: Verify D_CALCUL_PDO is added with current date.
        
        Tests that a date column with today's date is correctly
        added to the output DataFrame.
        """
        # Arrange
        from common.postprocessing import df_postprocessing
        
        # Act
        result_ilc, result_audit = df_postprocessing(
            self.df_main_ilc, 
            self.unfiltered_df_main
        )
        
        # Assert
        self.assertIn("D_CALCUL_PDO", result_ilc.columns)
        
        # Date should be today
        calc_date = result_ilc["D_CALCUL_PDO"][0]
        self.assertEqual(calc_date, date.today())

    def test_tu_071_df_postprocessing_deduplication(self) -> None:
        """TU-071: Verify deduplication on i_uniq_kpi keeps first row.
        
        Tests that unique(keep='first') correctly removes duplicates,
        keeping only the first occurrence of each i_uniq_kpi.
        """
        # Arrange
        from common.postprocessing import df_postprocessing
        
        # DataFrame with duplicates
        df_with_dupes = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E001", "E002", "E002", "E003"],
            "i_intrn": ["A001", "A001", "A002", "A002", "A003"],
            "i_siren": ["111", "111", "222", "222", "333"],
            "PDO": [0.01, 0.02, 0.03, 0.04, 0.05],
            "nat_jur_a": ["1-3", ">=7", "1-3", "4-6", "1-3"],
        })
        
        # Act
        result_ilc, _ = df_postprocessing(df_with_dupes, self.unfiltered_df_main)
        
        # Assert
        # Should have 3 unique rows
        self.assertEqual(len(result_ilc), 3)
        
        # First occurrence should be kept
        pdo_values = result_ilc.sort("i_uniq_kpi")["PDO"].to_list()
        self.assertEqual(pdo_values[0], 0.01)  # E001 first
        self.assertEqual(pdo_values[1], 0.03)  # E002 first
        self.assertEqual(pdo_values[2], 0.05)  # E003 first

    def test_tu_072_df_postprocessing_column_renaming(self) -> None:
        """TU-072: Verify column renaming (i_uniq_kpi->ID_RP, etc.).
        
        Tests that the 3 key columns are correctly renamed:
        - i_uniq_kpi -> ID_RP
        - i_intrn -> ID_RMPM  
        - i_siren -> SIREN
        """
        # Arrange
        from common.postprocessing import df_postprocessing
        
        # Act
        result_ilc, _ = df_postprocessing(
            self.df_main_ilc, 
            self.unfiltered_df_main
        )
        
        # Assert
        self.assertIn("ID_RP", result_ilc.columns)
        self.assertIn("ID_RMPM", result_ilc.columns)
        self.assertIn("SIREN", result_ilc.columns)
        
        # Original names should not exist
        self.assertNotIn("i_uniq_kpi", result_ilc.columns)
        self.assertNotIn("i_intrn", result_ilc.columns)
        self.assertNotIn("i_siren", result_ilc.columns)
        
        # Values should be preserved
        self.assertEqual(result_ilc["ID_RP"][0], "E001")
        self.assertEqual(result_ilc["ID_RMPM"][0], "A001")

    def test_tu_073_df_postprocessing_audit_left_join(self) -> None:
        """TU-073: Verify df_main_audit_final contains all enterprises via LEFT JOIN.
        
        Tests that the audit DataFrame preserves all enterprises from
        unfiltered_df_main, with NULL PDO for non-eligible ones.
        """
        # Arrange
        from common.postprocessing import df_postprocessing
        
        # df_main_ilc has 2 enterprises, unfiltered has 3
        # E003 is not eligible (not in df_main_ilc)
        
        # Act
        _, result_audit = df_postprocessing(
            self.df_main_ilc, 
            self.unfiltered_df_main
        )
        
        # Assert
        # Audit should have all 3 enterprises
        self.assertEqual(len(result_audit), 3)
        
        # E001, E002 should have PDO values
        row_e001 = result_audit.filter(pl.col("i_uniq_kpi") == "E001")
        self.assertIsNotNone(row_e001["PDO"][0])
        
        # E003 should have NULL PDO (not eligible)
        row_e003 = result_audit.filter(pl.col("i_uniq_kpi") == "E003")
        self.assertIsNone(row_e003["PDO"][0])

    def test_tu_074_df_postprocessing_empty_ilc_dataframe(self) -> None:
        """TU-074: Test with empty df_main_ilc (no eligible enterprises).
        
        When df_main_ilc is empty after filtering, the function should
        produce a valid empty CSV file, not raise an exception.
        """
        # Arrange
        from common.postprocessing import df_postprocessing
        
        # Empty DataFrame with correct schema
        empty_df = pl.DataFrame({
            "i_uniq_kpi": pl.Series([], dtype=pl.Utf8),
            "i_intrn": pl.Series([], dtype=pl.Utf8),
            "i_siren": pl.Series([], dtype=pl.Utf8),
            "PDO": pl.Series([], dtype=pl.Float64),
            "nat_jur_a": pl.Series([], dtype=pl.Utf8),
        })
        
        # Act
        result_ilc, result_audit = df_postprocessing(
            empty_df, 
            self.unfiltered_df_main
        )
        
        # Assert
        self.assertEqual(len(result_ilc), 0)  # Empty but valid
        self.assertGreater(len(result_audit), 0)  # All enterprises with NULL PDO

    def test_tu_075_df_postprocessing_missing_column(self) -> None:
        """TU-075: Test behavior when expected column is missing.
        
        When a required column (from cols_to_keep_all) is missing,
        should raise KeyError or ColumnNotFoundError.
        """
        # Arrange
        from common.postprocessing import df_postprocessing
        
        # DataFrame missing 'nat_jur_a' (one of the 91 expected columns)
        incomplete_df = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
            "PDO": [0.02],
            # 'nat_jur_a' is missing
        })
        
        # Act & Assert
        # Should either raise an exception or handle gracefully
        try:
            result_ilc, _ = df_postprocessing(
                incomplete_df, 
                self.unfiltered_df_main
            )
            # If no exception, verify behavior
            self.assertIsNotNone(result_ilc)
        except (KeyError, pl.exceptions.ColumnNotFoundError) as e:
            # Expected behavior: explicit error for missing column
            self.assertIsInstance(e, (KeyError, pl.exceptions.ColumnNotFoundError))


if __name__ == "__main__":
    main()
