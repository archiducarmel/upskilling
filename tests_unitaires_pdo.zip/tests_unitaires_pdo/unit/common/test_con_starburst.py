"""Unit tests for the con_starburst module.

This module contains tests for the StarburstConnector class that handles
database connections and query execution against Starburst.

Test IDs: TU-076 to TU-082
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch, PropertyMock
import polars as pl
import os


class TestStarburstConnectorInit(TestCase):
    """Unit tests for StarburstConnector.__init__()."""

    @patch.dict(os.environ, {
        'STARBURST_HOST_QUAL': 'host.example.com',
        'STARBURST_USERNAME': 'user',
        'STARBURST_PASSWORD': 'password',
        'STARBURST_PORT': '443',
        'STARBURST_CATALOG': 'catalog',
    })
    @patch('common.con_starburst.StarburstManager')
    def test_tu_076_init_retrieves_env_variables(self, mock_manager_class: MagicMock) -> None:
        """TU-076: Verify constructor retrieves 4 required environment variables.
        
        Tests that __init__ correctly retrieves STARBURST_HOST_QUAL,
        STARBURST_USERNAME, STARBURST_PASSWORD, and STARBURST_CATALOG.
        Raises ValueError if any is missing.
        """
        # Arrange
        from common.con_starburst import StarburstConnector
        
        # Act
        connector = StarburstConnector()
        
        # Assert
        self.assertEqual(connector.host, 'host.example.com')
        self.assertEqual(connector.user, 'user')
        self.assertEqual(connector.password, 'password')
        mock_manager_class.assert_called_once()

    @patch.dict(os.environ, {
        'STARBURST_USERNAME': 'user',
        'STARBURST_PASSWORD': 'password',
        'STARBURST_PORT': '443',
        'STARBURST_CATALOG': 'catalog',
    }, clear=True)
    def test_tu_076_init_missing_env_variable_raises_error(self) -> None:
        """TU-076b: Verify ValueError when environment variable is missing."""
        # Arrange
        from common.con_starburst import StarburstConnector
        
        # Act & Assert
        with self.assertRaises(ValueError) as context:
            StarburstConnector()
        
        self.assertIn('STARBURST_HOST_QUAL', str(context.exception))

    @patch.dict(os.environ, {
        'STARBURST_HOST_QUAL': 'invalid-host-that-does-not-exist.fake',
        'STARBURST_USERNAME': 'user',
        'STARBURST_PASSWORD': 'password',
        'STARBURST_PORT': '443',
        'STARBURST_CATALOG': 'catalog',
    })
    @patch('common.con_starburst.StarburstManager')
    def test_tu_077_init_invalid_host_url(self, mock_manager_class: MagicMock) -> None:
        """TU-077: Test with invalid STARBURST_HOST_QUAL URL.
        
        An invalid or non-existent host should raise an exception
        either during initialization or when building session.
        """
        # Arrange
        from common.con_starburst import StarburstConnector
        
        mock_manager = MagicMock()
        mock_manager.build_session.side_effect = ConnectionError("Cannot connect to host")
        mock_manager_class.return_value = mock_manager
        
        # Act & Assert
        with self.assertRaises(ConnectionError):
            connector = StarburstConnector()
            connector.build_session()


class TestStarburstConnectorQuery(TestCase):
    """Unit tests for StarburstConnector.query()."""

    @patch.dict(os.environ, {
        'STARBURST_HOST_QUAL': 'host.example.com',
        'STARBURST_USERNAME': 'user',
        'STARBURST_PASSWORD': 'password',
        'STARBURST_PORT': '443',
        'STARBURST_CATALOG': 'catalog',
    })
    @patch('common.con_starburst.StarburstManager')
    def test_tu_078_query_returns_polars_dataframe(self, mock_manager_class: MagicMock) -> None:
        """TU-078: Verify query() executes SQL and returns Polars DataFrame.
        
        Tests that a valid SQL query returns the expected DataFrame
        with correct columns and data types.
        """
        # Arrange
        from common.con_starburst import StarburstConnector
        
        # Mock the query result
        mock_session = MagicMock()
        mock_session.execute.return_value = pl.DataFrame({
            'col_a': [1],
            'col_b': [2],
        })
        
        mock_manager = MagicMock()
        mock_manager.build_session.return_value = mock_session
        mock_manager_class.return_value = mock_manager
        
        connector = StarburstConnector()
        
        # Act
        result = connector.query('SELECT 1 as col_a, 2 as col_b')
        
        # Assert
        self.assertIsInstance(result, pl.DataFrame)
        self.assertIn('col_a', result.columns)
        self.assertIn('col_b', result.columns)

    @patch.dict(os.environ, {
        'STARBURST_HOST_QUAL': 'host.example.com',
        'STARBURST_USERNAME': 'user',
        'STARBURST_PASSWORD': 'password',
        'STARBURST_PORT': '443',
        'STARBURST_CATALOG': 'catalog',
    })
    @patch('common.con_starburst.StarburstManager')
    def test_tu_079_query_sql_error_raises_exception(self, mock_manager_class: MagicMock) -> None:
        """TU-079: Test behavior with SQL syntax error or invalid table.
        
        Invalid SQL should raise a clear exception, not return empty DataFrame.
        """
        # Arrange
        from common.con_starburst import StarburstConnector
        
        mock_session = MagicMock()
        mock_session.execute.side_effect = Exception("SQL syntax error: SELEC is not valid")
        
        mock_manager = MagicMock()
        mock_manager.build_session.return_value = mock_session
        mock_manager_class.return_value = mock_manager
        
        connector = StarburstConnector()
        
        # Act & Assert
        with self.assertRaises(Exception) as context:
            connector.query('SELEC * FROM table_inexistante')
        
        self.assertIn('SQL', str(context.exception))


class TestStarburstConnectorClose(TestCase):
    """Unit tests for StarburstConnector.close() and context manager."""

    @patch.dict(os.environ, {
        'STARBURST_HOST_QUAL': 'host.example.com',
        'STARBURST_USERNAME': 'user',
        'STARBURST_PASSWORD': 'password',
        'STARBURST_PORT': '443',
        'STARBURST_CATALOG': 'catalog',
    })
    @patch('common.con_starburst.StarburstManager')
    def test_tu_080_close_sets_session_to_none(self, mock_manager_class: MagicMock) -> None:
        """TU-080: Verify close() properly closes session and sets to None.
        
        After calling close(), self.session should be None and
        starburst_manager.close_session() should be called.
        """
        # Arrange
        from common.con_starburst import StarburstConnector
        
        mock_manager = MagicMock()
        mock_manager_class.return_value = mock_manager
        
        connector = StarburstConnector()
        connector.session = MagicMock()  # Simulate active session
        
        # Act
        connector.close()
        
        # Assert
        mock_manager.close_session.assert_called_once()
        self.assertIsNone(connector.session)

    @patch.dict(os.environ, {
        'STARBURST_HOST_QUAL': 'host.example.com',
        'STARBURST_USERNAME': 'user',
        'STARBURST_PASSWORD': 'password',
        'STARBURST_PORT': '443',
        'STARBURST_CATALOG': 'catalog',
    })
    @patch('common.con_starburst.StarburstManager')
    def test_tu_081_exit_calls_close_on_exception(self, mock_manager_class: MagicMock) -> None:
        """TU-081: Verify context manager calls close() even on exception.
        
        When an exception occurs in the with block, __exit__ should
        still call close() before propagating the exception.
        """
        # Arrange
        from common.con_starburst import StarburstConnector
        
        mock_manager = MagicMock()
        mock_manager_class.return_value = mock_manager
        
        # Act & Assert
        with self.assertRaises(ValueError):
            with StarburstConnector() as connector:
                connector.session = MagicMock()
                raise ValueError('test error')
        
        # close() should have been called
        mock_manager.close_session.assert_called()

    @patch.dict(os.environ, {
        'STARBURST_HOST_QUAL': 'host.example.com',
        'STARBURST_USERNAME': 'user',
        'STARBURST_PASSWORD': 'password',
        'STARBURST_PORT': '443',
        'STARBURST_CATALOG': 'catalog',
    })
    @patch('common.con_starburst.StarburstManager')
    def test_tu_082_query_rebuilds_none_session(self, mock_manager_class: MagicMock) -> None:
        """TU-082: Test automatic session rebuild when self.session is None.
        
        If session becomes None (e.g., after timeout), query() should
        automatically rebuild it before executing.
        """
        # Arrange
        from common.con_starburst import StarburstConnector
        
        mock_session = MagicMock()
        mock_session.execute.return_value = pl.DataFrame({'result': [1]})
        
        mock_manager = MagicMock()
        mock_manager.build_session.return_value = mock_session
        mock_manager_class.return_value = mock_manager
        
        connector = StarburstConnector()
        connector.session = None  # Simulate None session
        
        # Act
        result = connector.query('SELECT 1 as result')
        
        # Assert
        mock_manager.build_session.assert_called()
        self.assertIsNotNone(result)


if __name__ == "__main__":
    main()
