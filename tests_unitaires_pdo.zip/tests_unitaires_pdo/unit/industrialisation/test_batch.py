"""Unit tests for the batch module.

This module contains tests for the main batch processing orchestration
including the PDO calculation pipeline execution and error handling.

Test IDs: TU-113 to TU-118
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch, ANY, PropertyMock
import polars as pl
import os


class TestBatchRun(TestCase):
    """Unit tests for the Batch.run() method."""

    def setUp(self) -> None:
        """Set up test fixtures with mock dependencies."""
        self.mock_config = {
            'environment': 'dev',
            'starburst': {
                'schema': 'test_schema',
                'catalog': 'test_catalog',
            },
            'cos': {
                'bucket': 'test-bucket',
                'model_key': 'models/pdo_model.pkl',
            },
        }

    @patch('industrialisation.src.batch.StarburstConnector')
    @patch('industrialisation.src.batch.CosManager')
    @patch('industrialisation.src.batch.load_project_config')
    def test_tu_113_batch_run_orchestration_order(
        self,
        mock_load_config: MagicMock,
        mock_cos_manager: MagicMock,
        mock_starburst: MagicMock
    ) -> None:
        """TU-113: Verify batch run executes steps in correct order.
        
        Tests that the batch pipeline executes: config loading, DB connection,
        data extraction, preprocessing, model inference, postprocessing,
        and file export in the expected sequence.
        """
        # Arrange
        from industrialisation.src.batch import Batch
        
        mock_load_config.return_value = self.mock_config
        
        mock_starburst_instance = MagicMock()
        mock_starburst_instance.query.return_value = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
        })
        mock_starburst.return_value.__enter__ = MagicMock(return_value=mock_starburst_instance)
        mock_starburst.return_value.__exit__ = MagicMock(return_value=False)
        
        batch = Batch(environment='dev')
        
        # Act
        with patch.object(batch, 'preprocess') as mock_preprocess, \
             patch.object(batch, 'calculate_pdo') as mock_calculate, \
             patch.object(batch, 'postprocess') as mock_postprocess, \
             patch.object(batch, 'export_results') as mock_export:
            
            mock_preprocess.return_value = pl.DataFrame({"data": [1]})
            mock_calculate.return_value = pl.DataFrame({"PDO": [0.02]})
            mock_postprocess.return_value = (
                pl.DataFrame({"PDO": [0.02]}),
                pl.DataFrame({"audit": [1]})
            )
            
            batch.run()
        
        # Assert - verify call order
        mock_preprocess.assert_called_once()
        mock_calculate.assert_called_once()
        mock_postprocess.assert_called_once()
        mock_export.assert_called_once()

    @patch('industrialisation.src.batch.StarburstConnector')
    @patch('industrialisation.src.batch.load_project_config')
    def test_tu_114_batch_run_db_connection_error(
        self,
        mock_load_config: MagicMock,
        mock_starburst: MagicMock
    ) -> None:
        """TU-114: Test batch behavior when database connection fails.
        
        When Starburst connection fails, batch should raise ConnectionError
        and not proceed with subsequent steps.
        """
        # Arrange
        from industrialisation.src.batch import Batch
        
        mock_load_config.return_value = self.mock_config
        mock_starburst.side_effect = ConnectionError("Cannot connect to Starburst")
        
        batch = Batch(environment='dev')
        
        # Act & Assert
        with self.assertRaises(ConnectionError):
            batch.run()

    @patch('industrialisation.src.batch.StarburstConnector')
    @patch('industrialisation.src.batch.CosManager')
    @patch('industrialisation.src.batch.load_project_config')
    def test_tu_115_batch_run_empty_data_extraction(
        self,
        mock_load_config: MagicMock,
        mock_cos_manager: MagicMock,
        mock_starburst: MagicMock
    ) -> None:
        """TU-115: Test batch behavior when data extraction returns empty DataFrame.
        
        When the SQL query returns no rows, batch should either:
        - Produce empty output files with correct schema
        - Raise a clear warning/exception
        """
        # Arrange
        from industrialisation.src.batch import Batch
        
        mock_load_config.return_value = self.mock_config
        
        mock_starburst_instance = MagicMock()
        # Return empty DataFrame
        mock_starburst_instance.query.return_value = pl.DataFrame({
            "i_uniq_kpi": pl.Series([], dtype=pl.Utf8),
            "i_intrn": pl.Series([], dtype=pl.Utf8),
            "i_siren": pl.Series([], dtype=pl.Utf8),
        })
        mock_starburst.return_value.__enter__ = MagicMock(return_value=mock_starburst_instance)
        mock_starburst.return_value.__exit__ = MagicMock(return_value=False)
        
        batch = Batch(environment='dev')
        
        # Act & Assert
        # Should either complete with empty output or raise warning
        try:
            with patch.object(batch, 'export_results'):
                batch.run()
        except Exception as e:
            # If it raises, should be a clear message about empty data
            self.assertIn("empty", str(e).lower())


class TestBatchPreprocess(TestCase):
    """Unit tests for the Batch.preprocess() method."""

    @patch('industrialisation.src.batch.load_project_config')
    def test_tu_116_preprocess_calls_all_preprocessing_functions(
        self,
        mock_load_config: MagicMock
    ) -> None:
        """TU-116: Verify preprocess calls all required preprocessing functions.
        
        Tests that preprocess orchestrates: df_encoding, add_risk_features,
        add_soldes_features, add_reboot_features, add_transac_features,
        add_safir_soc_features, add_safir_conso_features, filtre_df_main.
        """
        # Arrange
        from industrialisation.src.batch import Batch
        
        mock_load_config.return_value = {
            'environment': 'dev',
            'starburst': {'schema': 'test'},
        }
        
        batch = Batch(environment='dev')
        
        # Create mock DataFrames for each source
        df_main = pl.DataFrame({"i_uniq_kpi": ["E001"], "i_intrn": ["A001"]})
        rsc = pl.DataFrame({"i_intrn": ["A001"], "k_dep_auth_10j": [5]})
        soldes = pl.DataFrame({"i_intrn": ["A001"], "pref_m_ctrvl_sld_arr": [1000]})
        reboot = pl.DataFrame({"i_uniq_kpi": ["E001"], "q_score": ["0,5"]})
        transac = pl.DataFrame({"i_uniq_kpi": ["E001"], "category": ["interets"]})
        safir_sc = pl.DataFrame({"i_siren": ["111"], "d_fin_excce_soc": ["2024-12-31"]})
        safir_sd = pl.DataFrame({"i_siren": ["111"], "c_code": ["00066"]})
        safir_cc = pl.DataFrame({"i_g_affre_rmpm": ["G001"]})
        safir_cd = pl.DataFrame({"i_g_affre_rmpm": ["G001"]})
        
        # Act
        with patch('industrialisation.src.batch.df_encoding') as mock_encoding, \
             patch('industrialisation.src.batch.add_risk_features') as mock_risk, \
             patch('industrialisation.src.batch.add_soldes_features') as mock_soldes, \
             patch('industrialisation.src.batch.add_reboot_features') as mock_reboot, \
             patch('industrialisation.src.batch.add_transac_features') as mock_transac, \
             patch('industrialisation.src.batch.add_safir_soc_features') as mock_safir_soc, \
             patch('industrialisation.src.batch.add_safir_conso_features') as mock_safir_conso, \
             patch('industrialisation.src.batch.filtre_df_main') as mock_filtre:
            
            mock_encoding.return_value = df_main
            mock_risk.return_value = df_main
            mock_soldes.return_value = df_main
            mock_reboot.return_value = df_main
            mock_transac.return_value = df_main
            mock_safir_soc.return_value = df_main
            mock_safir_conso.return_value = df_main
            mock_filtre.return_value = df_main
            
            result = batch.preprocess(
                df_main, rsc, soldes, reboot, transac,
                safir_sc, safir_sd, safir_cc, safir_cd
            )
        
        # Assert - all preprocessing functions should be called
        mock_encoding.assert_called_once()
        mock_risk.assert_called_once()
        mock_soldes.assert_called_once()
        mock_reboot.assert_called_once()
        mock_transac.assert_called_once()
        mock_filtre.assert_called_once()


class TestBatchExport(TestCase):
    """Unit tests for the Batch.export_results() method."""

    @patch('industrialisation.src.batch.CosManager')
    @patch('industrialisation.src.batch.load_project_config')
    def test_tu_117_export_results_writes_csv_files(
        self,
        mock_load_config: MagicMock,
        mock_cos_manager: MagicMock
    ) -> None:
        """TU-117: Verify export_results writes CSV files to correct locations.
        
        Tests that two CSV files are created: one for ILC output (main results)
        and one for audit trail.
        """
        # Arrange
        from industrialisation.src.batch import Batch
        
        mock_load_config.return_value = {
            'environment': 'dev',
            'starburst': {'schema': 'test'},
            'output': {
                'local_path': '/tmp/outputs',
                'cos_bucket': 'test-bucket',
            },
        }
        
        batch = Batch(environment='dev')
        
        df_ilc = pl.DataFrame({"ID_RP": ["E001"], "PDO": [0.02]})
        df_audit = pl.DataFrame({"i_uniq_kpi": ["E001"], "PDO": [0.02]})
        
        mock_cos_instance = MagicMock()
        mock_cos_manager.return_value = mock_cos_instance
        
        # Act
        with patch('polars.DataFrame.write_csv') as mock_write_csv:
            batch.export_results(df_ilc, df_audit)
        
        # Assert
        # write_csv should be called twice (once for each file)
        self.assertEqual(mock_write_csv.call_count, 2)

    @patch('industrialisation.src.batch.CosManager')
    @patch('industrialisation.src.batch.load_project_config')
    def test_tu_118_export_results_uploads_to_cos(
        self,
        mock_load_config: MagicMock,
        mock_cos_manager: MagicMock
    ) -> None:
        """TU-118: Verify export_results uploads files to COS after local write.
        
        Tests that after writing local CSV files, the batch uploads
        them to IBM Cloud Object Storage.
        """
        # Arrange
        from industrialisation.src.batch import Batch
        
        mock_load_config.return_value = {
            'environment': 'dev',
            'starburst': {'schema': 'test'},
            'output': {
                'local_path': '/tmp/outputs',
                'cos_bucket': 'test-bucket',
                'cos_prefix': 'pdo/outputs/',
            },
        }
        
        batch = Batch(environment='dev')
        
        df_ilc = pl.DataFrame({"ID_RP": ["E001"], "PDO": [0.02]})
        df_audit = pl.DataFrame({"i_uniq_kpi": ["E001"], "PDO": [0.02]})
        
        mock_cos_instance = MagicMock()
        mock_cos_manager.return_value = mock_cos_instance
        
        # Act
        with patch('polars.DataFrame.write_csv'):
            batch.export_results(df_ilc, df_audit)
        
        # Assert
        # upload_file should be called for each output file
        self.assertGreaterEqual(mock_cos_instance.upload_file.call_count, 2)


if __name__ == "__main__":
    main()
