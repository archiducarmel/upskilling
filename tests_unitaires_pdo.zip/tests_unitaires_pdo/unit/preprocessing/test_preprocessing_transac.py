"""Unit tests for the preprocessing_transac module.

This module contains tests for transaction feature calculation functions,
including category aggregation, threshold-based flags, and ratio calculations.

Test IDs: TU-034 to TU-042
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch
import polars as pl
import numpy as np


class TestAddTransacFeatures(TestCase):
    """Unit tests for the add_transac_features function."""

    def setUp(self) -> None:
        """Set up test fixtures with base DataFrame structures."""
        self.df_main_base = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111111111", "222222222"],
        })

    def _create_transac_df(self, data: dict) -> pl.DataFrame:
        """Create a transaction DataFrame with required columns."""
        defaults = {
            "i_uniq_kpi": [],
            "category": [],
            "netamount": [],
            "nops_category": [],
            "min_amount": [],
            "max_amount": [],
        }
        defaults.update(data)
        return pl.DataFrame(defaults)

    def test_tu_034_add_transac_features_category_grouping_saisie(self) -> None:
        """TU-034: Verify attri_blocage and atd_tres_pub are grouped into saisie__.
        
        Tests that transaction categories attri_blocage and atd_tres_pub are
        correctly merged into saisie__ for calculating pres_saisie.
        """
        # Arrange
        from common.preprocessing.preprocessing_transac import add_transac_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
        })
        
        donnees_transac = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E001", "E001", "E001"],
            "category": ["attri_blocage", "atd_tres_pub", "interets", "turnover"],
            "netamount": [100.0, 200.0, -50.0, 1000.0],
            "nops_category": [1, 2, 1, 1],
            "min_amount": [100.0, 100.0, -50.0, 1000.0],
            "max_amount": [100.0, 200.0, -50.0, 1000.0],
        })
        
        # Act
        result = add_transac_features(df_main, donnees_transac)
        
        # Assert
        self.assertIn("pres_saisie", result.columns)
        # saisie__nops = 1 + 2 = 3, so pres_saisie should be '1'
        self.assertEqual(result["pres_saisie"][0], "1")

    def test_tu_035_add_transac_features_remb_sepa_max_above_threshold(self) -> None:
        """TU-035: Verify remb_sepa_max='1' when max_amount > 3493.57.
        
        Tests that remb_sepa_max flag is '1' when the maximum SEPA
        reimbursement amount exceeds the threshold of 3493.57 euros.
        """
        # Arrange
        from common.preprocessing.preprocessing_transac import add_transac_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111", "222"],
        })
        
        donnees_transac = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "category": ["rembt_prlv_sepa", "rembt_prlv_sepa"],
            "netamount": [5000.0, 3000.0],
            "nops_category": [1, 1],
            "min_amount": [5000.0, 3000.0],
            "max_amount": [5000.0, 3000.0],  # E001 > 3493.57, E002 < 3493.57
        })
        
        # Act
        result = add_transac_features(df_main, donnees_transac)
        
        # Assert
        self.assertIn("remb_sepa_max", result.columns)
        
        row_e001 = result.filter(pl.col("i_uniq_kpi") == "E001")
        self.assertEqual(row_e001["remb_sepa_max"][0], "1")  # > 3493.57
        
        row_e002 = result.filter(pl.col("i_uniq_kpi") == "E002")
        self.assertEqual(row_e002["remb_sepa_max"][0], "2")  # < 3493.57

    def test_tu_036_add_transac_features_remb_sepa_max_exact_threshold(self) -> None:
        """TU-036: Test when max_amount equals exactly 3493.57 (threshold).
        
        The condition is > (strictly greater), so exactly 3493.57 should
        result in remb_sepa_max='2' (not exceeding threshold).
        """
        # Arrange
        from common.preprocessing.preprocessing_transac import add_transac_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
        })
        
        # Exact threshold value from code: 3493.57007
        donnees_transac = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "category": ["rembt_prlv_sepa"],
            "netamount": [3493.57007],
            "nops_category": [1],
            "min_amount": [3493.57007],
            "max_amount": [3493.57007],
        })
        
        # Act
        result = add_transac_features(df_main, donnees_transac)
        
        # Assert - condition is >, so exact threshold is '2'
        self.assertEqual(result["remb_sepa_max"][0], "2")

    def test_tu_037_add_transac_features_net_int_turnover_double_condition(self) -> None:
        """TU-037: Verify net_int_turnover requires ratio < threshold AND nops >= 60.
        
        Tests the double AND condition for net_int_turnover flag:
        - ratio (interets/turnover) < -0.00143675995
        - AND nops (number of operations) >= 60
        """
        # Arrange
        from common.preprocessing.preprocessing_transac import add_transac_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003"],
            "i_intrn": ["A001", "A002", "A003"],
            "i_siren": ["111", "222", "333"],
        })
        
        # E001: ratio OK AND nops OK -> '1'
        # E002: ratio OK BUT nops < 60 -> '2'
        # E003: ratio NOT OK (> threshold) -> '2'
        donnees_transac = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E001", "E002", "E002", "E003", "E003"],
            "category": ["interets", "turnover", "interets", "turnover", "interets", "turnover"],
            "netamount": [-100.0, 50000.0, -100.0, 50000.0, -10.0, 50000.0],
            "nops_category": [70, 70, 50, 50, 70, 70],
            "min_amount": [-100.0, 50000.0, -100.0, 50000.0, -10.0, 50000.0],
            "max_amount": [-100.0, 50000.0, -100.0, 50000.0, -10.0, 50000.0],
        })
        
        # Act
        result = add_transac_features(df_main, donnees_transac)
        
        # Assert
        self.assertIn("net_int_turnover", result.columns)
        
        # E001: ratio = -100/50000 = -0.002 < -0.00143, nops = 70 >= 60 -> '1'
        row_e001 = result.filter(pl.col("i_uniq_kpi") == "E001")
        self.assertEqual(row_e001["net_int_turnover"][0], "1")
        
        # E002: ratio OK but nops = 50 < 60 -> '2'
        row_e002 = result.filter(pl.col("i_uniq_kpi") == "E002")
        self.assertEqual(row_e002["net_int_turnover"][0], "2")
        
        # E003: ratio = -10/50000 = -0.0002 > -0.00143 -> '2'
        row_e003 = result.filter(pl.col("i_uniq_kpi") == "E003")
        self.assertEqual(row_e003["net_int_turnover"][0], "2")

    def test_tu_038_add_transac_features_division_by_zero_turnover(self) -> None:
        """TU-038: Test ratio calculation when turnover__netamount is 0.
        
        When turnover is exactly 0, the ratio calculation should return 0.0
        (via when/then condition) instead of causing division by zero.
        """
        # Arrange
        from common.preprocessing.preprocessing_transac import add_transac_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
        })
        
        donnees_transac = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E001"],
            "category": ["interets", "turnover"],
            "netamount": [-100.0, 0.0],  # turnover = 0
            "nops_category": [1, 1],
            "min_amount": [-100.0, 0.0],
            "max_amount": [-100.0, 0.0],
        })
        
        # Act
        result = add_transac_features(df_main, donnees_transac)
        
        # Assert - should handle division by zero
        # net_interets_sur_turnover should be 0.0, not Inf
        self.assertIn("net_interets_sur_turnover", result.columns)
        ratio = result["net_interets_sur_turnover"][0]
        
        self.assertFalse(np.isinf(ratio) if ratio is not None else False)
        self.assertEqual(ratio, 0.0)

    def test_tu_039_add_transac_features_both_interets_and_turnover_null(self) -> None:
        """TU-039: Test ratio when both interets and turnover are NULL.
        
        When both values are NULL (no data for either category),
        the ratio should be 0.0, and net_int_turnover should be '2'.
        """
        # Arrange
        from common.preprocessing.preprocessing_transac import add_transac_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
        })
        
        # Only prlv_sepa_retourne, no interets or turnover
        donnees_transac = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "category": ["prlv_sepa_retourne"],
            "netamount": [100.0],
            "nops_category": [1],
            "min_amount": [100.0],
            "max_amount": [100.0],
        })
        
        # Act
        result = add_transac_features(df_main, donnees_transac)
        
        # Assert
        ratio = result["net_interets_sur_turnover"][0]
        # Both NULL -> ratio should be 0.0
        self.assertEqual(ratio, 0.0)
        
        # net_int_turnover should be '2' (default)
        self.assertEqual(result["net_int_turnover"][0], "2")

    def test_tu_040_add_transac_features_pres_prlv_retourne_null_vs_zero(self) -> None:
        """TU-040: Test pres_prlv_retourne with NULL vs 0 for nops.
        
        NULL (no data) and 0 (zero operations) both result in
        pres_prlv_retourne='2', but for different reasons.
        """
        # Arrange
        from common.preprocessing.preprocessing_transac import add_transac_features
        
        # E001: no prlv_sepa_retourne data -> NULL after join -> '2'
        # E002: has prlv_sepa_retourne with nops=0 -> '2'
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111", "222"],
        })
        
        donnees_transac = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "category": ["interets", "prlv_sepa_retourne"],  # E001 has no prlv
            "netamount": [-50.0, 0.0],
            "nops_category": [1, 0],  # E002 has 0 operations
            "min_amount": [-50.0, 0.0],
            "max_amount": [-50.0, 0.0],
        })
        
        # Act
        result = add_transac_features(df_main, donnees_transac)
        
        # Assert
        self.assertIn("pres_prlv_retourne", result.columns)
        
        # E001: no prlv_sepa_retourne -> NULL -> '2' (otherwise)
        row_e001 = result.filter(pl.col("i_uniq_kpi") == "E001")
        self.assertEqual(row_e001["pres_prlv_retourne"][0], "2")
        
        # E002: nops = 0, condition > 0 is false -> '2'
        row_e002 = result.filter(pl.col("i_uniq_kpi") == "E002")
        self.assertEqual(row_e002["pres_prlv_retourne"][0], "2")

    def test_tu_041_add_transac_features_only_unused_categories(self) -> None:
        """TU-041: Test with enterprise having only non-model transaction categories.
        
        When an enterprise only has transactions in categories not used by
        the model (like 'agios'), all derived features should be NULL.
        """
        # Arrange
        from common.preprocessing.preprocessing_transac import add_transac_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
        })
        
        # Only 'agios' and 'amort_pret' which may be filtered out
        donnees_transac = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E001"],
            "category": ["agios", "amort_pret"],
            "netamount": [100.0, 200.0],
            "nops_category": [1, 1],
            "min_amount": [100.0, 200.0],
            "max_amount": [100.0, 200.0],
        })
        
        # Act
        result = add_transac_features(df_main, donnees_transac)
        
        # Assert - features should be NULL or default values
        # remb_sepa_max should be '2' (default)
        self.assertEqual(result["remb_sepa_max"][0], "2")
        
        # pres_saisie should be '2' (default)
        self.assertEqual(result["pres_saisie"][0], "2")
        
        # net_int_turnover should be '2' (default)
        self.assertEqual(result["net_int_turnover"][0], "2")


class TestAggregateCategory(TestCase):
    """Unit tests for the aggregate_category function."""

    def test_tu_042_aggregate_category_sum_aggregation(self) -> None:
        """TU-042: Verify correct SUM aggregation for category columns.
        
        Tests that netamount, nops_category, min_amount, and max_amount
        are correctly summed for each category.
        """
        # Arrange
        from common.preprocessing.preprocessing_transac import aggregate_category
        
        donnees_transac = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E001", "E001"],
            "category": ["interets", "interets", "interets"],
            "netamount": [-100.0, -50.0, -25.0],
            "nops_category": [1, 2, 1],
            "min_amount": [-100.0, -50.0, -25.0],
            "max_amount": [-100.0, -50.0, -25.0],
        })
        
        # Act
        result = aggregate_category(donnees_transac, "interets")
        
        # Assert
        # SUM of netamount: -100 + -50 + -25 = -175
        self.assertAlmostEqual(result["interets__netamount"][0], -175.0, places=2)
        
        # SUM of nops: 1 + 2 + 1 = 4
        self.assertEqual(result["interets__nops"][0], 4)
        
        # SUM of min_amount: -175 (sum, not MIN)
        self.assertAlmostEqual(result["interets__min_amount"][0], -175.0, places=2)
        
        # SUM of max_amount: -175 (sum, not MAX)
        self.assertAlmostEqual(result["interets__max_amount"][0], -175.0, places=2)


if __name__ == "__main__":
    main()
