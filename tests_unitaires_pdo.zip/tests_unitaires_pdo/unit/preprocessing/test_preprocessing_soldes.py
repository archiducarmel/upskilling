"""Unit tests for the preprocessing_soldes module.

This module contains tests for balance-related feature calculation functions,
including conversion from cents to euros and aggregation of account balances.

Test IDs: TU-023 to TU-027
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch
import polars as pl
import numpy as np


class TestAddSoldesFeatures(TestCase):
    """Unit tests for the add_soldes_features function."""

    def setUp(self) -> None:
        """Set up test fixtures with base DataFrame structures."""
        self.df_main_base = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111111111", "222222222"],
        })

    def test_tu_023_add_soldes_features_cents_to_euros_conversion(self) -> None:
        """TU-023: Verify pref_m_ctrvl_sld_arr is divided by 100 for solde_cav.
        
        Tests that balance values stored in cents are correctly converted
        to euros by dividing by 100, then summed by i_intrn.
        """
        # Arrange
        from common.preprocessing.preprocessing_soldes import add_soldes_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111", "222"],
        })
        
        soldes = pl.DataFrame({
            "i_intrn": ["A001", "A001", "A002"],
            "pref_i_uniq_cpt": ["CPT1", "CPT2", "CPT3"],
            "pref_m_ctrvl_sld_arr": [100000, 50000, 200000],  # In cents
        })
        
        # Act
        result = add_soldes_features(df_main, soldes)
        
        # Assert
        self.assertIn("solde_cav", result.columns)
        
        # A001: (100000 + 50000) / 100 = 1500.0 EUR
        row_a001 = result.filter(pl.col("i_intrn") == "A001")
        self.assertAlmostEqual(row_a001["solde_cav"][0], 1500.0, places=2)
        
        # A002: 200000 / 100 = 2000.0 EUR
        row_a002 = result.filter(pl.col("i_intrn") == "A002")
        self.assertAlmostEqual(row_a002["solde_cav"][0], 2000.0, places=2)

    def test_tu_024_add_soldes_features_account_count(self) -> None:
        """TU-024: Verify solde_nb is COUNT of unique accounts per enterprise.
        
        Tests that solde_nb correctly counts the number of distinct
        pref_i_uniq_cpt (unique account identifiers) per enterprise.
        """
        # Arrange
        from common.preprocessing.preprocessing_soldes import add_soldes_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111", "222"],
        })
        
        soldes = pl.DataFrame({
            "i_intrn": ["A001", "A001", "A001", "A002"],
            "pref_i_uniq_cpt": ["CPT1", "CPT2", "CPT3", "CPT4"],
            "pref_m_ctrvl_sld_arr": [10000, 20000, 30000, 40000],
        })
        
        # Act
        result = add_soldes_features(df_main, soldes)
        
        # Assert
        self.assertIn("solde_nb", result.columns)
        
        # A001: 3 accounts
        row_a001 = result.filter(pl.col("i_intrn") == "A001")
        self.assertEqual(row_a001["solde_nb"][0], 3)
        
        # A002: 1 account
        row_a002 = result.filter(pl.col("i_intrn") == "A002")
        self.assertEqual(row_a002["solde_nb"][0], 1)

    def test_tu_025_add_soldes_features_algebraic_sum_compensation(self) -> None:
        """TU-025: Test algebraic sum when positive and negative balances compensate.
        
        When an enterprise has multiple accounts with positive and negative
        balances that cancel out, solde_cav should be 0.0 (or close to it).
        """
        # Arrange
        from common.preprocessing.preprocessing_soldes import add_soldes_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
        })
        
        # Balances that sum to 0: +5000 - 3000 - 2000 = 0 EUR
        soldes = pl.DataFrame({
            "i_intrn": ["A001", "A001", "A001"],
            "pref_i_uniq_cpt": ["CPT1", "CPT2", "CPT3"],
            "pref_m_ctrvl_sld_arr": [500000, -300000, -200000],  # In cents
        })
        
        # Act
        result = add_soldes_features(df_main, soldes)
        
        # Assert
        solde_cav = result["solde_cav"][0]
        self.assertAlmostEqual(solde_cav, 0.0, places=2)

    def test_tu_026_add_soldes_features_very_large_values_overflow(self) -> None:
        """TU-026: Test with very large balance values for potential overflow.
        
        Very large balances in cents (billions of euros) should be handled
        without Float64 overflow. Result should not be Inf or NaN.
        """
        # Arrange
        from common.preprocessing.preprocessing_soldes import add_soldes_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
        })
        
        # Very large value (close to max int64)
        large_value = 9223372036854775807  # Max int64
        soldes = pl.DataFrame({
            "i_intrn": ["A001"],
            "pref_i_uniq_cpt": ["CPT1"],
            "pref_m_ctrvl_sld_arr": [large_value],
        })
        
        # Act
        result = add_soldes_features(df_main, soldes)
        
        # Assert
        solde_cav = result["solde_cav"][0]
        self.assertFalse(np.isnan(solde_cav))
        self.assertFalse(np.isinf(solde_cav))
        # Expected: 92233720368547758.07 EUR (Float64 can handle this)

    def test_tu_027_add_soldes_features_zero_balance_not_null(self) -> None:
        """TU-027: Test that exactly zero balance is treated correctly.
        
        A balance of exactly 0 should be treated as a valid value,
        distinct from NULL (absence of account data).
        """
        # Arrange
        from common.preprocessing.preprocessing_soldes import add_soldes_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
        })
        
        soldes = pl.DataFrame({
            "i_intrn": ["A001"],
            "pref_i_uniq_cpt": ["CPT1"],
            "pref_m_ctrvl_sld_arr": [0],
        })
        
        # Act
        result = add_soldes_features(df_main, soldes)
        
        # Assert
        solde_cav = result["solde_cav"][0]
        self.assertEqual(solde_cav, 0.0)  # Not NULL
        self.assertIsNotNone(solde_cav)
        
        solde_nb = result["solde_nb"][0]
        self.assertEqual(solde_nb, 1)  # Account exists


if __name__ == "__main__":
    main()
