"""Unit tests for the preprocessing_safir_conso module.

This module contains tests for consolidated financial statement (SAFIR)
feature calculation functions, including annualized revenue and VB023 ratio.

Test IDs: TU-043 to TU-049
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch
import polars as pl
import numpy as np


class TestAddSafirConsoFeatures(TestCase):
    """Unit tests for the add_safir_conso_features function."""

    def setUp(self) -> None:
        """Set up test fixtures with base DataFrame structures."""
        self.df_main_base = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111111111", "222222222"],
            "i_g_affre_rmpm": ["G001", "G002"],
        })

    def _create_safir_cc_df(self, data: dict) -> pl.DataFrame:
        """Create a SAFIR CC (consolidated header) DataFrame."""
        defaults = {
            "i_g_affre_rmpm": [],
            "d_fin_excce_conso": [],
            "c_duree_excce_conso": [],
            "top_ga_mm": [],
        }
        defaults.update(data)
        return pl.DataFrame(defaults)

    def _create_safir_cd_df(self, data: dict) -> pl.DataFrame:
        """Create a SAFIR CD (consolidated detail) DataFrame."""
        defaults = {
            "i_g_affre_rmpm": [],
            "d_fin_excce_conso": [],
            "c_code": [],
            "c_val": [],
        }
        defaults.update(data)
        return pl.DataFrame(defaults)

    def test_tu_043_add_safir_conso_features_ca_conso_annualization(self) -> None:
        """TU-043: Verify ca_conso is calculated as mt_310/c_duree_excce_conso*12.
        
        Tests that consolidated revenue (mt_310) is annualized by dividing
        by exercise duration in months and multiplying by 12.
        """
        # Arrange
        from common.preprocessing.preprocessing_safir_conso import add_safir_conso_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
            "i_g_affre_rmpm": ["G001"],
        })
        
        df_cc = pl.DataFrame({
            "i_g_affre_rmpm": ["G001"],
            "d_fin_excce_conso": ["2024-12-31"],
            "c_duree_excce_conso": [12],  # 12 months
            "top_ga_mm": ["1"],
        })
        
        df_cd = pl.DataFrame({
            "i_g_affre_rmpm": ["G001"],
            "d_fin_excce_conso": ["2024-12-31"],
            "c_code": ["00112"],  # mt_310 (CA)
            "c_val": [1000000.0],
        })
        
        # Act
        result = add_safir_conso_features(df_main, df_cc, df_cd)
        
        # Assert
        self.assertIn("ca_conso", result.columns)
        # ca_conso = 1000000 / 12 * 12 = 1000000
        self.assertAlmostEqual(result["ca_conso"][0], 1000000.0, places=2)

    def test_tu_044_add_safir_conso_features_vb023_ratio(self) -> None:
        """TU-044: Verify VB023 is calculated as res_net_conso/ca_conso*100.
        
        Tests that VB023 (net result to revenue ratio in percentage)
        is correctly calculated from consolidated financial data.
        """
        # Arrange
        from common.preprocessing.preprocessing_safir_conso import add_safir_conso_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
            "i_g_affre_rmpm": ["G001"],
        })
        
        df_cc = pl.DataFrame({
            "i_g_affre_rmpm": ["G001"],
            "d_fin_excce_conso": ["2024-12-31"],
            "c_duree_excce_conso": [12],
            "top_ga_mm": ["1"],
        })
        
        # res_net_conso = 50000, ca_conso = 1000000 -> VB023 = 5%
        df_cd = pl.DataFrame({
            "i_g_affre_rmpm": ["G001", "G001"],
            "d_fin_excce_conso": ["2024-12-31", "2024-12-31"],
            "c_code": ["00112", "00182"],  # mt_310 (CA), mt_182 (res_net)
            "c_val": [1000000.0, 50000.0],
        })
        
        # Act
        result = add_safir_conso_features(df_main, df_cc, df_cd)
        
        # Assert
        self.assertIn("VB023", result.columns)
        # VB023 = 50000 / 1000000 * 100 = 5.0%
        self.assertAlmostEqual(result["VB023"][0], 5.0, places=2)

    def test_tu_045_add_safir_conso_features_division_by_zero_duration(self) -> None:
        """TU-045: Test ca_conso calculation when c_duree_excce_conso is 0.
        
        When exercise duration is 0, division by zero occurs.
        The code should handle this gracefully.
        """
        # Arrange
        from common.preprocessing.preprocessing_safir_conso import add_safir_conso_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
            "i_g_affre_rmpm": ["G001"],
        })
        
        df_cc = pl.DataFrame({
            "i_g_affre_rmpm": ["G001"],
            "d_fin_excce_conso": ["2024-12-31"],
            "c_duree_excce_conso": [0],  # Zero duration
            "top_ga_mm": ["1"],
        })
        
        df_cd = pl.DataFrame({
            "i_g_affre_rmpm": ["G001"],
            "d_fin_excce_conso": ["2024-12-31"],
            "c_code": ["00112"],
            "c_val": [1000000.0],
        })
        
        # Act
        result = add_safir_conso_features(df_main, df_cc, df_cd)
        
        # Assert - should handle division by zero
        ca_conso = result["ca_conso"][0]
        # Should be NULL or Inf, but not crash
        # Document actual behavior
        if ca_conso is not None:
            self.assertTrue(np.isinf(ca_conso) or ca_conso == 0.0)

    def test_tu_046_add_safir_conso_features_vb023_zero_ca(self) -> None:
        """TU-046: Test VB023 calculation when ca_conso is 0 or NULL.
        
        When ca_conso is 0 or NULL, VB023 calculation faces division by zero.
        Should return '0' or NULL according to code logic.
        """
        # Arrange
        from common.preprocessing.preprocessing_safir_conso import add_safir_conso_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
            "i_g_affre_rmpm": ["G001"],
        })
        
        df_cc = pl.DataFrame({
            "i_g_affre_rmpm": ["G001"],
            "d_fin_excce_conso": ["2024-12-31"],
            "c_duree_excce_conso": [12],
            "top_ga_mm": ["1"],
        })
        
        # mt_310 = 0 (zero revenue)
        df_cd = pl.DataFrame({
            "i_g_affre_rmpm": ["G001", "G001"],
            "d_fin_excce_conso": ["2024-12-31", "2024-12-31"],
            "c_code": ["00112", "00182"],
            "c_val": [0.0, 50000.0],  # CA = 0
        })
        
        # Act
        result = add_safir_conso_features(df_main, df_cc, df_cd)
        
        # Assert
        vb023 = result["VB023"][0]
        # Division by zero should be handled
        if vb023 is not None:
            # Should be '0' or 0.0, not Inf
            self.assertFalse(np.isinf(vb023))

    def test_tu_047_add_safir_conso_features_keep_last_2_balances(self) -> None:
        """TU-047: Verify only last 2 consolidated balances are kept via ranking.
        
        Tests that ranking on d_fin_excce_conso keeps only N_bilan_conso
        values 1 (most recent) and 2 (second most recent).
        """
        # Arrange
        from common.preprocessing.preprocessing_safir_conso import add_safir_conso_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
            "i_g_affre_rmpm": ["G001"],
        })
        
        # 4 balances for same group
        df_cc = pl.DataFrame({
            "i_g_affre_rmpm": ["G001", "G001", "G001", "G001"],
            "d_fin_excce_conso": ["2021-12-31", "2022-12-31", "2023-12-31", "2024-12-31"],
            "c_duree_excce_conso": [12, 12, 12, 12],
            "top_ga_mm": ["1", "1", "1", "1"],
        })
        
        df_cd = pl.DataFrame({
            "i_g_affre_rmpm": ["G001", "G001", "G001", "G001"],
            "d_fin_excce_conso": ["2021-12-31", "2022-12-31", "2023-12-31", "2024-12-31"],
            "c_code": ["00112", "00112", "00112", "00112"],
            "c_val": [100000.0, 200000.0, 300000.0, 400000.0],
        })
        
        # Act
        result = add_safir_conso_features(df_main, df_cc, df_cd)
        
        # Assert - only 2024 (N=1) and 2023 (N=2) should be kept
        # VB023 should be calculated from most recent (2024)
        self.assertIn("VB023", result.columns)

    def test_tu_048_add_safir_conso_features_null_group_affiliation(self) -> None:
        """TU-048: Test join when enterprise has no group (i_g_affre_rmpm NULL).
        
        When an enterprise doesn't belong to a group, the LEFT JOIN
        should return NULL for all consolidated features.
        """
        # Arrange
        from common.preprocessing.preprocessing_safir_conso import add_safir_conso_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111", "222"],
            "i_g_affre_rmpm": ["G001", None],  # E002 has no group
        })
        
        df_cc = pl.DataFrame({
            "i_g_affre_rmpm": ["G001"],
            "d_fin_excce_conso": ["2024-12-31"],
            "c_duree_excce_conso": [12],
            "top_ga_mm": ["1"],
        })
        
        df_cd = pl.DataFrame({
            "i_g_affre_rmpm": ["G001"],
            "d_fin_excce_conso": ["2024-12-31"],
            "c_code": ["00112"],
            "c_val": [1000000.0],
        })
        
        # Act
        result = add_safir_conso_features(df_main, df_cc, df_cd)
        
        # Assert
        # E001 should have VB023 value
        row_e001 = result.filter(pl.col("i_uniq_kpi") == "E001")
        self.assertIsNotNone(row_e001["VB023"][0])
        
        # E002 (no group) should have VB023 = NULL
        row_e002 = result.filter(pl.col("i_uniq_kpi") == "E002")
        self.assertIsNone(row_e002["VB023"][0])

    def test_tu_049_add_safir_conso_features_parent_company_selection(self) -> None:
        """TU-049: Test selection when group has multiple companies with same SIREN.
        
        When multiple enterprises in a group have consolidated balances,
        the one with top_ga_mm='1' (parent company) should be selected.
        """
        # Arrange
        from common.preprocessing.preprocessing_safir_conso import add_safir_conso_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
            "i_g_affre_rmpm": ["G001"],
        })
        
        # Two balances: one parent (top_ga_mm='1'), one subsidiary (top_ga_mm='0')
        df_cc = pl.DataFrame({
            "i_g_affre_rmpm": ["G001", "G001"],
            "d_fin_excce_conso": ["2024-12-31", "2024-12-31"],
            "c_duree_excce_conso": [12, 12],
            "top_ga_mm": ["1", "0"],  # First is parent
        })
        
        df_cd = pl.DataFrame({
            "i_g_affre_rmpm": ["G001", "G001"],
            "d_fin_excce_conso": ["2024-12-31", "2024-12-31"],
            "c_code": ["00112", "00112"],
            "c_val": [1000000.0, 500000.0],  # Different values
        })
        
        # Act
        result = add_safir_conso_features(df_main, df_cc, df_cd)
        
        # Assert - parent company (top_ga_mm='1') should be used
        # ca_conso should be 1000000 (from parent)
        self.assertIn("ca_conso", result.columns)


if __name__ == "__main__":
    main()
