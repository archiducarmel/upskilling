"""Unit tests for the preprocessing_format_variables module.

This module contains tests for variable formatting and discretization functions
that convert continuous values into categorical classes for the PDO model.

Test IDs: TU-063 to TU-069
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch
import polars as pl


class TestFormatVariables(TestCase):
    """Unit tests for the format_variables function."""

    def setUp(self) -> None:
        """Set up test fixtures with base DataFrame structure."""
        self.base_columns = {
            "i_uniq_kpi": ["E001"],
            "c_njur_prsne_enc": ["1-3"],
            "solde_cav": [1000.0],
            "reboot_score2": [0.5],
            "VB023": [5.0],
            "Q_JJ_DEPST_MM": [5],
        }

    def _create_df(self, overrides: dict = None) -> pl.DataFrame:
        """Create a test DataFrame with optional overrides."""
        data = {**self.base_columns}
        if overrides:
            for key, value in overrides.items():
                data[key] = value if isinstance(value, list) else [value]
        return pl.DataFrame(data)

    def test_tu_063_format_variables_nat_jur_a_conversion(self) -> None:
        """TU-063: Verify nat_jur_a converts '7' to '>=7'.
        
        Tests that c_njur_prsne_enc value '7' is transformed to
        nat_jur_a value '>=7' for the model.
        """
        # Arrange
        from common.preprocessing.preprocessing_format_variables import format_variables
        
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003"],
            "c_njur_prsne_enc": ["1-3", "4-6", "7"],
            "solde_cav": [1000.0, 2000.0, 3000.0],
            "reboot_score2": [0.5, 0.5, 0.5],
            "VB023": [5.0, 5.0, 5.0],
            "Q_JJ_DEPST_MM": [5, 5, 5],
        })
        
        # Act
        result = format_variables(df)
        
        # Assert
        self.assertIn("nat_jur_a", result.columns)
        nat_jur_values = result["nat_jur_a"].to_list()
        self.assertEqual(nat_jur_values[0], "1-3")
        self.assertEqual(nat_jur_values[1], "4-6")
        self.assertEqual(nat_jur_values[2], ">=7")

    def test_tu_064_format_variables_solde_cav_char_thresholds(self) -> None:
        """TU-064: Verify solde_cav_char discretization with 4 thresholds.
        
        Tests the 4-class discretization:
        - Class '1': < -9.10499954
        - Class '2': >= -9.10499954 and < 15235.64
        - Class '3': >= 15235.64 and < 76378.70
        - Class '4': >= 76378.70
        """
        # Arrange
        from common.preprocessing.preprocessing_format_variables import format_variables
        
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003", "E004", "E005"],
            "c_njur_prsne_enc": ["1-3"] * 5,
            "solde_cav": [-100.0, -9.10499954, 0.0, 50000.0, 100000.0],
            "reboot_score2": [0.5] * 5,
            "VB023": [5.0] * 5,
            "Q_JJ_DEPST_MM": [5] * 5,
        })
        
        # Act
        result = format_variables(df)
        
        # Assert
        self.assertIn("solde_cav_char", result.columns)
        classes = result["solde_cav_char"].to_list()
        
        # -100 < -9.10 -> '1'
        self.assertEqual(classes[0], "1")
        # -9.10499954 is exactly at threshold, should be '1' or '2' depending on >= or >
        # 0 is >= -9.10 and < 15235.64 -> '2'
        self.assertEqual(classes[2], "2")
        # 50000 is >= 15235.64 and < 76378.70 -> '3'
        self.assertEqual(classes[3], "3")
        # 100000 >= 76378.70 -> '4'
        self.assertEqual(classes[4], "4")

    def test_tu_065_format_variables_reboot_score_char2_9_classes(self) -> None:
        """TU-065: Verify reboot_score_char2 discretization into 9 classes.
        
        Tests the 9-class discretization based on 8 probability thresholds.
        """
        # Arrange
        from common.preprocessing.preprocessing_format_variables import format_variables
        
        # Test values for each of the 9 classes
        df = pl.DataFrame({
            "i_uniq_kpi": [f"E00{i}" for i in range(1, 10)],
            "c_njur_prsne_enc": ["1-3"] * 9,
            "solde_cav": [1000.0] * 9,
            "reboot_score2": [0.01, 0.05, 0.10, 0.15, 0.25, 0.40, 0.55, 0.75, 0.95],
            "VB023": [5.0] * 9,
            "Q_JJ_DEPST_MM": [5] * 9,
        })
        
        # Act
        result = format_variables(df)
        
        # Assert
        self.assertIn("reboot_score_char2", result.columns)
        classes = result["reboot_score_char2"].to_list()
        
        # Verify each value is in a class from '1' to '9'
        for cls in classes:
            self.assertIn(cls, ["1", "2", "3", "4", "5", "6", "7", "8", "9"])

    def test_tu_066_format_variables_threshold_boundary_exact_value(self) -> None:
        """TU-066: Test discretization when value is exactly at threshold.
        
        Values exactly at -9.10499954 threshold should fall deterministically
        into one class (verify >= vs < condition consistency).
        """
        # Arrange
        from common.preprocessing.preprocessing_format_variables import format_variables
        
        # Values around the threshold
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003"],
            "c_njur_prsne_enc": ["1-3"] * 3,
            "solde_cav": [-9.10499955, -9.10499954, -9.10499953],
            "reboot_score2": [0.5] * 3,
            "VB023": [5.0] * 3,
            "Q_JJ_DEPST_MM": [5] * 3,
        })
        
        # Act
        result = format_variables(df)
        
        # Assert
        classes = result["solde_cav_char"].to_list()
        
        # Below threshold -> '1'
        self.assertEqual(classes[0], "1")
        # At or above threshold -> '2'
        self.assertIn(classes[1], ["1", "2"])  # Exact behavior depends on >= or >
        # Above threshold -> '2'
        self.assertEqual(classes[2], "2")

    def test_tu_067_format_variables_null_reboot_score2(self) -> None:
        """TU-067: Test discretization when reboot_score2 is NULL.
        
        NULL probability should result in NULL class or a default value.
        No exception should be raised.
        """
        # Arrange
        from common.preprocessing.preprocessing_format_variables import format_variables
        
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "c_njur_prsne_enc": ["1-3"] * 2,
            "solde_cav": [1000.0] * 2,
            "reboot_score2": [0.5, None],
            "VB023": [5.0] * 2,
            "Q_JJ_DEPST_MM": [5] * 2,
        })
        
        # Act
        result = format_variables(df)
        
        # Assert - should not raise
        self.assertIn("reboot_score_char2", result.columns)
        classes = result["reboot_score_char2"].to_list()
        
        # First should have a class
        self.assertIsNotNone(classes[0])
        # Second (NULL) should be NULL or default
        # Actual behavior depends on otherwise clause

    def test_tu_068_format_variables_null_vb023_default_class(self) -> None:
        """TU-068: Test VB023 discretization when value is NULL.
        
        NULL VB023 should be assigned default class '2' via otherwise clause.
        """
        # Arrange
        from common.preprocessing.preprocessing_format_variables import format_variables
        
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003"],
            "c_njur_prsne_enc": ["1-3"] * 3,
            "solde_cav": [1000.0] * 3,
            "reboot_score2": [0.5] * 3,
            "VB023": [5.0, None, -10.0],
            "Q_JJ_DEPST_MM": [5] * 3,
        })
        
        # Act
        result = format_variables(df)
        
        # Assert
        self.assertIn("rn_ca_conso_023b", result.columns)
        classes = result["rn_ca_conso_023b"].to_list()
        
        # NULL should get default class '2'
        self.assertEqual(classes[1], "2")

    def test_tu_069_format_variables_null_q_jj_depst_mm_default(self) -> None:
        """TU-069: Test nbj discretization when Q_JJ_DEPST_MM is NULL.
        
        NULL Q_JJ_DEPST_MM should be assigned default value '<=12'
        (less risky category) via otherwise clause.
        """
        # Arrange
        from common.preprocessing.preprocessing_format_variables import format_variables
        
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003"],
            "c_njur_prsne_enc": ["1-3"] * 3,
            "solde_cav": [1000.0] * 3,
            "reboot_score2": [0.5] * 3,
            "VB023": [5.0] * 3,
            "Q_JJ_DEPST_MM": [5, 15, None],
        })
        
        # Act
        result = format_variables(df)
        
        # Assert
        self.assertIn("nbj", result.columns)
        nbj_values = result["nbj"].to_list()
        
        # 5 <= 12 -> '<=12'
        self.assertEqual(nbj_values[0], "<=12")
        # 15 > 12 -> '>12'
        self.assertEqual(nbj_values[1], ">12")
        # NULL -> '<=12' (default, less risky)
        self.assertEqual(nbj_values[2], "<=12")


if __name__ == "__main__":
    main()
