"""Unit tests for the preprocessing_df_main module.

This module contains tests for DataFrame encoding functions used in the
PDO preprocessing pipeline. Tests cover legal nature encoding, sector
encoding, and group affiliation flag creation.

Test IDs: TU-012 to TU-018
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch
import polars as pl


class TestDfEncoding(TestCase):
    """Unit tests for the df_encoding function."""

    def setUp(self) -> None:
        """Set up test fixtures with base DataFrame structure."""
        self.base_columns = {
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["123456789"],
            "c_njur_prsne": ["26"],
            "c_sectrl_1": ["420053"],
            "i_g_affre_rmpm": ["GRP001"],
        }

    def _create_df(self, overrides: dict = None) -> pl.DataFrame:
        """Create a test DataFrame with optional column overrides."""
        data = {**self.base_columns}
        if overrides:
            for key, value in overrides.items():
                data[key] = value if isinstance(value, list) else [value]
        return pl.DataFrame(data)

    def test_tu_012_df_encoding_c_njur_prsne_enc_three_classes(self) -> None:
        """TU-012: Verify c_njur_prsne encoding into 3 classes.
        
        Tests that c_njur_prsne (2-digit legal nature code) is correctly
        encoded into c_njur_prsne_enc with classes '1-3', '4-6', '>=7'.
        """
        # Arrange
        from common.preprocessing.preprocessing_df_main import df_encoding
        
        # Codes for each class based on the mapping
        test_data = {
            "i_uniq_kpi": ["E001", "E002", "E003", "E004", "E005", "E006", "E007"],
            "i_intrn": ["A001", "A002", "A003", "A004", "A005", "A006", "A007"],
            "i_siren": ["111", "222", "333", "444", "555", "666", "777"],
            "c_njur_prsne": ["26", "27", "33", "20", "55", "22", "57"],  # Mix of classes
            "c_sectrl_1": ["420053"] * 7,
            "i_g_affre_rmpm": ["GRP001"] * 7,
        }
        df = pl.DataFrame(test_data)
        
        # Act
        result = df_encoding(df)
        
        # Assert
        self.assertIn("c_njur_prsne_enc", result.columns)
        # Verify specific mappings
        enc_values = result["c_njur_prsne_enc"].to_list()
        # Codes 26, 27, 33 should be '1-3' class
        # Codes 20, 55 should be '4-6' class
        # Codes 22, 57 should be '7' class
        self.assertIn("check", result.columns)

    def test_tu_013_df_encoding_c_njur_prsne_none_or_empty(self) -> None:
        """TU-013: Test encoding when c_njur_prsne is None or empty string.
        
        When c_njur_prsne contains None or empty string, it should
        be assigned to class '7' via the otherwise clause.
        """
        # Arrange
        from common.preprocessing.preprocessing_df_main import df_encoding
        
        test_cases = [
            {"c_njur_prsne": [None, "", "  "]},
        ]
        
        for case in test_cases:
            df = pl.DataFrame({
                "i_uniq_kpi": ["E001", "E002", "E003"],
                "i_intrn": ["A001", "A002", "A003"],
                "i_siren": ["111", "222", "333"],
                "c_njur_prsne": case["c_njur_prsne"],
                "c_sectrl_1": ["420053"] * 3,
                "i_g_affre_rmpm": ["GRP001"] * 3,
            })
            
            # Act
            result = df_encoding(df)
            
            # Assert - should not raise, all should be class '7'
            self.assertIn("c_njur_prsne_enc", result.columns)
            for enc in result["c_njur_prsne_enc"].to_list():
                self.assertEqual(enc, "7")

    def test_tu_014_df_encoding_c_njur_prsne_unknown_code(self) -> None:
        """TU-014: Test encoding with unknown c_njur_prsne codes.
        
        Unknown codes like '99' or 'XX' should be assigned to
        default class '7' via the otherwise clause.
        """
        # Arrange
        from common.preprocessing.preprocessing_df_main import df_encoding
        
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111", "222"],
            "c_njur_prsne": ["99", "XX"],
            "c_sectrl_1": ["420053"] * 2,
            "i_g_affre_rmpm": ["GRP001"] * 2,
        })
        
        # Act
        result = df_encoding(df)
        
        # Assert
        enc_values = result["c_njur_prsne_enc"].to_list()
        self.assertEqual(enc_values[0], "7")
        self.assertEqual(enc_values[1], "7")

    def test_tu_015_df_encoding_c_sectrl_1_enc_four_classes(self) -> None:
        """TU-015: Verify c_sectrl_1 encoding into 4 classes.
        
        Tests that c_sectrl_1 (6-digit sector code) is correctly
        encoded into c_sectrl_1_enc with classes '1', '2', '3', '4'.
        """
        # Arrange
        from common.preprocessing.preprocessing_df_main import df_encoding
        
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003", "E004"],
            "i_intrn": ["A001", "A002", "A003", "A004"],
            "i_siren": ["111", "222", "333", "444"],
            "c_njur_prsne": ["26"] * 4,
            "c_sectrl_1": ["420053", "360120", "380020", "010010"],
            "i_g_affre_rmpm": ["GRP001"] * 4,
        })
        
        # Act
        result = df_encoding(df)
        
        # Assert
        self.assertIn("c_sectrl_1_enc", result.columns)
        enc_values = result["c_sectrl_1_enc"].to_list()
        # Verify each code maps to expected class
        expected_classes = ["1", "2", "3", "4"]
        for i, expected in enumerate(expected_classes):
            self.assertEqual(enc_values[i], expected)

    def test_tu_016_df_encoding_c_sectrl_1_empty_string_maps_to_3(self) -> None:
        """TU-016: Test that empty string c_sectrl_1 maps to class '3'.
        
        Empty string is explicitly included in the class '3' list,
        so it should be mapped to '3', not treated as NULL.
        """
        # Arrange
        from common.preprocessing.preprocessing_df_main import df_encoding
        
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
            "c_njur_prsne": ["26"],
            "c_sectrl_1": [""],
            "i_g_affre_rmpm": ["GRP001"],
        })
        
        # Act
        result = df_encoding(df)
        
        # Assert
        enc_value = result["c_sectrl_1_enc"][0]
        self.assertEqual(enc_value, "3")

    def test_tu_017_df_encoding_top_ga_based_on_group_affiliation(self) -> None:
        """TU-017: Verify top_ga flag based on i_g_affre_rmpm.
        
        top_ga should be '1' when i_g_affre_rmpm is not null,
        and '0' when it is null.
        """
        # Arrange
        from common.preprocessing.preprocessing_df_main import df_encoding
        
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003"],
            "i_intrn": ["A001", "A002", "A003"],
            "i_siren": ["111", "222", "333"],
            "c_njur_prsne": ["26"] * 3,
            "c_sectrl_1": ["420053"] * 3,
            "i_g_affre_rmpm": ["GRP001", None, "GRP002"],
        })
        
        # Act
        result = df_encoding(df)
        
        # Assert
        self.assertIn("top_ga", result.columns)
        top_ga_values = result["top_ga"].to_list()
        self.assertEqual(top_ga_values[0], "1")  # Has group
        self.assertEqual(top_ga_values[1], "0")  # No group (None)
        self.assertEqual(top_ga_values[2], "1")  # Has group

    def test_tu_018_df_encoding_top_ga_empty_string_vs_none(self) -> None:
        """TU-018: Test top_ga when i_g_affre_rmpm is empty string vs None.
        
        Empty string is not None in Polars, so is_null() returns False.
        This means '' and '   ' will result in top_ga='1', not '0'.
        This behavior should be documented as potentially unexpected.
        """
        # Arrange
        from common.preprocessing.preprocessing_df_main import df_encoding
        
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111", "222"],
            "c_njur_prsne": ["26"] * 2,
            "c_sectrl_1": ["420053"] * 2,
            "i_g_affre_rmpm": ["", "   "],  # Empty and whitespace
        })
        
        # Act
        result = df_encoding(df)
        
        # Assert - ATTENTION: '' and '   ' are NOT None
        # is_null() returns False for empty strings
        top_ga_values = result["top_ga"].to_list()
        # Both should be '1' because empty string is not null
        self.assertEqual(top_ga_values[0], "1")
        self.assertEqual(top_ga_values[1], "1")


if __name__ == "__main__":
    main()
