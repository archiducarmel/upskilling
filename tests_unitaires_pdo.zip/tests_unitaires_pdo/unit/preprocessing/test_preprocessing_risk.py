"""Unit tests for the preprocessing_risk module.

This module contains tests for risk feature calculation functions,
specifically the aggregation of RSC (Risk Score Components) data
including days of authorized overdraft.

Test IDs: TU-019 to TU-022
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch
import polars as pl


class TestAddRiskFeatures(TestCase):
    """Unit tests for the add_risk_features function."""

    def setUp(self) -> None:
        """Set up test fixtures with base DataFrame structures."""
        self.df_main_base = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111111111", "222222222"],
        })

    def test_tu_019_add_risk_features_max_aggregation(self) -> None:
        """TU-019: Verify k_dep_auth_10j is aggregated by MAX per i_intrn.
        
        Tests that the number of authorized overdraft days (k_dep_auth_10j)
        is correctly aggregated using MAX function grouped by i_intrn.
        """
        # Arrange
        from common.preprocessing.preprocessing_risk import add_risk_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111", "222"],
        })
        
        rsc = pl.DataFrame({
            "i_intrn": ["A001", "A001", "A001", "A002"],
            "k_dep_auth_10j": [3, 7, 5, 2],
        })
        
        # Act
        result = add_risk_features(df_main, rsc)
        
        # Assert
        self.assertIn("Q_JJ_DEPST_MM", result.columns)
        
        # A001 should have max(3, 7, 5) = 7
        row_a001 = result.filter(pl.col("i_intrn") == "A001")
        self.assertEqual(row_a001["Q_JJ_DEPST_MM"][0], 7)
        
        # A002 should have max(2) = 2
        row_a002 = result.filter(pl.col("i_intrn") == "A002")
        self.assertEqual(row_a002["Q_JJ_DEPST_MM"][0], 2)

    def test_tu_020_add_risk_features_left_join_no_match(self) -> None:
        """TU-020: Test LEFT JOIN when enterprise has no RSC data.
        
        When an enterprise in df_main has no corresponding data in rsc,
        Q_JJ_DEPST_MM should be NULL (not 0) after the LEFT JOIN.
        """
        # Arrange
        from common.preprocessing.preprocessing_risk import add_risk_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111", "222"],
        })
        
        # Only data for A001, nothing for A002
        rsc = pl.DataFrame({
            "i_intrn": ["A001"],
            "k_dep_auth_10j": [5],
        })
        
        # Act
        result = add_risk_features(df_main, rsc)
        
        # Assert
        self.assertEqual(len(result), 2)  # Both rows preserved
        
        # A001 should have value
        row_a001 = result.filter(pl.col("i_intrn") == "A001")
        self.assertEqual(row_a001["Q_JJ_DEPST_MM"][0], 5)
        
        # A002 should have NULL (not 0)
        row_a002 = result.filter(pl.col("i_intrn") == "A002")
        self.assertIsNone(row_a002["Q_JJ_DEPST_MM"][0])

    def test_tu_021_add_risk_features_out_of_range_values(self) -> None:
        """TU-021: Test behavior with negative or >10 values for k_dep_auth_10j.
        
        Values outside the expected 0-10 range indicate corrupted data.
        Current implementation does not filter these values.
        """
        # Arrange
        from common.preprocessing.preprocessing_risk import add_risk_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
        })
        
        # Includes negative and >10 values
        rsc = pl.DataFrame({
            "i_intrn": ["A001", "A001", "A001"],
            "k_dep_auth_10j": [-2, 15, 8],
        })
        
        # Act
        result = add_risk_features(df_main, rsc)
        
        # Assert - max includes aberrant values
        # This is the CURRENT behavior, not necessarily desired
        q_jj_value = result["Q_JJ_DEPST_MM"][0]
        self.assertEqual(q_jj_value, 15)  # Max including aberrant value

    def test_tu_022_add_risk_features_empty_rsc_dataframe(self) -> None:
        """TU-022: Test with completely empty RSC DataFrame.
        
        When rsc has no rows, all enterprises should have NULL for
        Q_JJ_DEPST_MM. No exception should be raised.
        """
        # Arrange
        from common.preprocessing.preprocessing_risk import add_risk_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003"],
            "i_intrn": ["A001", "A002", "A003"],
            "i_siren": ["111", "222", "333"],
        })
        
        # Empty DataFrame with correct schema
        rsc = pl.DataFrame({
            "i_intrn": pl.Series([], dtype=pl.Utf8),
            "k_dep_auth_10j": pl.Series([], dtype=pl.Int64),
        })
        
        # Act
        result = add_risk_features(df_main, rsc)
        
        # Assert
        self.assertEqual(len(result), 3)  # All rows preserved
        
        # All should have NULL
        for val in result["Q_JJ_DEPST_MM"].to_list():
            self.assertIsNone(val)


if __name__ == "__main__":
    main()
