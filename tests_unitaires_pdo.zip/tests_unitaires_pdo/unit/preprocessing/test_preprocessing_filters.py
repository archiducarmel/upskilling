"""Unit tests for the preprocessing_filters module.

This module contains tests for DataFrame filtering functions that exclude
enterprises based on legal nature, segment, risk status, and other criteria.

Test IDs: TU-057 to TU-062
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch
import polars as pl


class TestFiltreDfMain(TestCase):
    """Unit tests for the filtre_df_main function."""

    def setUp(self) -> None:
        """Set up test fixtures with base DataFrame structure."""
        self.base_columns = {
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111111111"],
            "c_njur_prsne": ["26"],  # Valid
            "c_sgmttn_nae": ["ME"],  # Valid
            "c_crisq": ["0"],  # Valid (not in default)
            "c_profl_immbr": ["0"],  # Valid (not '1')
            "c_eco": ["999"],  # Valid (not in exclusion list)
            "c_naf": ["1234A"],  # Valid
        }

    def _create_df(self, overrides: dict = None, num_rows: int = 1) -> pl.DataFrame:
        """Create a test DataFrame with optional overrides."""
        data = {}
        for key, value in self.base_columns.items():
            if overrides and key in overrides:
                data[key] = overrides[key]
            else:
                data[key] = value * num_rows
        return pl.DataFrame(data)

    def test_tu_057_filtre_df_main_excluded_legal_natures(self) -> None:
        """TU-057: Verify exclusion of specific c_njur_prsne codes.
        
        Tests that legal nature codes ['31','32','34','35','93','95','99']
        (GIE, SCI, foncières) are correctly filtered out.
        """
        # Arrange
        from common.preprocessing.preprocessing_filters import filtre_df_main
        
        # Mix of valid and invalid legal nature codes
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003", "E004", "E005", "E006", "E007", "E008", "E009", "E010"],
            "i_intrn": ["A001", "A002", "A003", "A004", "A005", "A006", "A007", "A008", "A009", "A010"],
            "i_siren": ["111", "222", "333", "444", "555", "666", "777", "888", "999", "000"],
            "c_njur_prsne": ["26", "31", "32", "33", "34", "35", "55", "93", "95", "99"],
            "c_sgmttn_nae": ["ME"] * 10,
            "c_crisq": ["0"] * 10,
            "c_profl_immbr": ["0"] * 10,
            "c_eco": ["999"] * 10,
            "c_naf": ["1234A"] * 10,
        })
        
        # Act
        result = filtre_df_main(df)
        
        # Assert
        # Should keep: 26, 33, 55 (3 rows)
        # Should exclude: 31, 32, 34, 35, 93, 95, 99 (7 rows)
        self.assertEqual(len(result), 3)
        remaining_codes = result["c_njur_prsne"].to_list()
        self.assertIn("26", remaining_codes)
        self.assertIn("33", remaining_codes)
        self.assertIn("55", remaining_codes)

    def test_tu_058_filtre_df_main_valid_segments(self) -> None:
        """TU-058: Verify only segments ME, GR, A3 are kept.
        
        Tests that c_sgmttn_nae filter keeps only 'ME', 'GR', 'A3'
        and excludes all other segment codes.
        """
        # Arrange
        from common.preprocessing.preprocessing_filters import filtre_df_main
        
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003", "E004", "E005", "E006"],
            "i_intrn": ["A001", "A002", "A003", "A004", "A005", "A006"],
            "i_siren": ["111", "222", "333", "444", "555", "666"],
            "c_njur_prsne": ["26"] * 6,
            "c_sgmttn_nae": ["ME", "GR", "A3", "AP", "PE", "XX"],
            "c_crisq": ["0"] * 6,
            "c_profl_immbr": ["0"] * 6,
            "c_eco": ["999"] * 6,
            "c_naf": ["1234A"] * 6,
        })
        
        # Act
        result = filtre_df_main(df)
        
        # Assert
        # Should keep: ME, GR, A3 (3 rows)
        # Should exclude: AP, PE, XX (3 rows)
        self.assertEqual(len(result), 3)
        remaining_segments = result["c_sgmttn_nae"].to_list()
        self.assertEqual(set(remaining_segments), {"ME", "GR", "A3"})

    def test_tu_059_filtre_df_main_default_exclusion(self) -> None:
        """TU-059: Verify exclusion of enterprises already in default (c_crisq 1, 2).
        
        Tests that c_crisq codes '1' and '2' (already in default)
        are excluded from the PDO calculation perimeter.
        """
        # Arrange
        from common.preprocessing.preprocessing_filters import filtre_df_main
        
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003", "E004", "E005"],
            "i_intrn": ["A001", "A002", "A003", "A004", "A005"],
            "i_siren": ["111", "222", "333", "444", "555"],
            "c_njur_prsne": ["26"] * 5,
            "c_sgmttn_nae": ["ME"] * 5,
            "c_crisq": ["0", "1", "2", "3", None],
            "c_profl_immbr": ["0"] * 5,
            "c_eco": ["999"] * 5,
            "c_naf": ["1234A"] * 5,
        })
        
        # Act
        result = filtre_df_main(df)
        
        # Assert
        # Should keep: 0, 3, NULL (3 rows)
        # Should exclude: 1, 2 (2 rows)
        self.assertEqual(len(result), 3)
        remaining_crisq = result["c_crisq"].to_list()
        self.assertNotIn("1", [str(x) for x in remaining_crisq if x])
        self.assertNotIn("2", [str(x) for x in remaining_crisq if x])

    def test_tu_060_filtre_df_main_profl_immbr_null_vs_1(self) -> None:
        """TU-060: Test c_profl_immbr filter with NULL vs '1'.
        
        Filter != '1' should exclude '1' but keep NULL (since NULL != '1'
        evaluates to NULL which is falsy in Polars filter context).
        """
        # Arrange
        from common.preprocessing.preprocessing_filters import filtre_df_main
        
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003", "E004"],
            "i_intrn": ["A001", "A002", "A003", "A004"],
            "i_siren": ["111", "222", "333", "444"],
            "c_njur_prsne": ["26"] * 4,
            "c_sgmttn_nae": ["ME"] * 4,
            "c_crisq": ["0"] * 4,
            "c_profl_immbr": ["1", "0", None, ""],
            "c_eco": ["999"] * 4,
            "c_naf": ["1234A"] * 4,
        })
        
        # Act
        result = filtre_df_main(df)
        
        # Assert
        # Should exclude '1', keep '0', NULL, ''
        self.assertEqual(len(result), 3)
        remaining = result["c_profl_immbr"].to_list()
        self.assertNotIn("1", remaining)

    def test_tu_061_filtre_df_main_c_eco_with_spaces_null(self) -> None:
        """TU-061: Test c_eco filter with 89 excluded codes, spaces, and NULL.
        
        Codes with leading/trailing spaces may not match the exclusion list.
        NULL values should pass the filter.
        """
        # Arrange
        from common.preprocessing.preprocessing_filters import filtre_df_main
        
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003", "E004"],
            "i_intrn": ["A001", "A002", "A003", "A004"],
            "i_siren": ["111", "222", "333", "444"],
            "c_njur_prsne": ["26"] * 4,
            "c_sgmttn_nae": ["ME"] * 4,
            "c_crisq": ["0"] * 4,
            "c_profl_immbr": ["0"] * 4,
            "c_eco": ["011", " 011", "011 ", None],  # '011' is in exclusion list
            "c_naf": ["1234A"] * 4,
        })
        
        # Act
        result = filtre_df_main(df)
        
        # Assert
        # '011' exact match -> excluded
        # ' 011' and '011 ' with spaces -> may NOT match, kept (potential data quality issue)
        # NULL -> kept
        self.assertGreaterEqual(len(result), 2)  # At least ' 011', '011 ', NULL should pass

    def test_tu_062_filtre_df_main_combined_ap_naf_filter(self) -> None:
        """TU-062: Test combined filter c_sgmttn_nae='AP' AND c_naf='8411Z'.
        
        Only enterprises with BOTH segment='AP' AND NAF='8411Z' should be
        excluded (public administrations). AND logic, not OR.
        """
        # Arrange
        from common.preprocessing.preprocessing_filters import filtre_df_main
        
        df = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003", "E004"],
            "i_intrn": ["A001", "A002", "A003", "A004"],
            "i_siren": ["111", "222", "333", "444"],
            "c_njur_prsne": ["26"] * 4,
            "c_sgmttn_nae": ["AP", "AP", "ME", "ME"],
            "c_crisq": ["0"] * 4,
            "c_profl_immbr": ["0"] * 4,
            "c_eco": ["999"] * 4,
            "c_naf": ["8411Z", "1234A", "8411Z", "1234A"],
        })
        
        # Act
        result = filtre_df_main(df)
        
        # Assert
        # Note: 'AP' is not in valid segments ['ME', 'GR', 'A3']
        # So all 'AP' rows are excluded anyway
        # Only 'ME' rows should remain
        remaining_segments = result["c_sgmttn_nae"].to_list()
        for segment in remaining_segments:
            self.assertEqual(segment, "ME")


if __name__ == "__main__":
    main()
