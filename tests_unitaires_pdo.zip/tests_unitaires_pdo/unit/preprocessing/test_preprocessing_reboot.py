"""Unit tests for the preprocessing_reboot module.

This module contains tests for REBOOT score feature calculation functions,
including decimal format conversion (comma to dot) and sigmoid transformation.

Test IDs: TU-028 to TU-033
"""

from unittest import TestCase, main
from unittest.mock import MagicMock, patch
import polars as pl
import numpy as np
import math


class TestAddRebootFeatures(TestCase):
    """Unit tests for the add_reboot_features function."""

    def setUp(self) -> None:
        """Set up test fixtures with base DataFrame structures."""
        self.df_main_base = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111111111", "222222222"],
        })

    def test_tu_028_add_reboot_features_comma_to_dot_conversion(self) -> None:
        """TU-028: Verify q_score comma decimal is converted to dot for Float64.
        
        Tests that European decimal format with comma (e.g., '1,5') is
        correctly converted to dot format ('1.5') before casting to Float64.
        """
        # Arrange
        from common.preprocessing.preprocessing_reboot import add_reboot_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111", "222"],
        })
        
        reboot = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "q_score": ["1,5", "-0,75"],  # European format with comma
        })
        
        # Act
        result = add_reboot_features(df_main, reboot)
        
        # Assert
        # After conversion, q_score should be Float64
        row_e001 = result.filter(pl.col("i_uniq_kpi") == "E001")
        row_e002 = result.filter(pl.col("i_uniq_kpi") == "E002")
        
        # Values should be correctly parsed
        self.assertAlmostEqual(row_e001["q_score"][0], 1.5, places=4)
        self.assertAlmostEqual(row_e002["q_score"][0], -0.75, places=4)

    def test_tu_029_add_reboot_features_sigmoid_formula(self) -> None:
        """TU-029: Verify reboot_score2 sigmoid formula 1/(1+exp(-q_score)).
        
        Tests that the sigmoid transformation produces probability values
        between 0 and 1 for various q_score inputs.
        """
        # Arrange
        from common.preprocessing.preprocessing_reboot import add_reboot_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003"],
            "i_intrn": ["A001", "A002", "A003"],
            "i_siren": ["111", "222", "333"],
        })
        
        reboot = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002", "E003"],
            "q_score": ["0,0", "2,0", "-2,0"],  # 0, 2, -2
        })
        
        # Act
        result = add_reboot_features(df_main, reboot)
        
        # Assert
        self.assertIn("reboot_score2", result.columns)
        
        # q_score = 0 -> sigmoid = 0.5
        row_e001 = result.filter(pl.col("i_uniq_kpi") == "E001")
        self.assertAlmostEqual(row_e001["reboot_score2"][0], 0.5, places=4)
        
        # q_score = 2 -> sigmoid = 1/(1+exp(-2)) ≈ 0.8808
        row_e002 = result.filter(pl.col("i_uniq_kpi") == "E002")
        expected_sigmoid_2 = 1 / (1 + math.exp(-2))
        self.assertAlmostEqual(row_e002["reboot_score2"][0], expected_sigmoid_2, places=4)
        
        # q_score = -2 -> sigmoid = 1/(1+exp(2)) ≈ 0.1192
        row_e003 = result.filter(pl.col("i_uniq_kpi") == "E003")
        expected_sigmoid_minus2 = 1 / (1 + math.exp(2))
        self.assertAlmostEqual(row_e003["reboot_score2"][0], expected_sigmoid_minus2, places=4)

    def test_tu_030_add_reboot_features_extreme_negative_q_score(self) -> None:
        """TU-030: Test with extremely negative q_score (e.g., -100).
        
        When q_score is very negative, exp(-q_score) = exp(100) is very large.
        reboot_score2 = 1/(1+exp(100)) should be close to 0, not Inf or NaN.
        """
        # Arrange
        from common.preprocessing.preprocessing_reboot import add_reboot_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
        })
        
        reboot = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "q_score": ["-100"],  # Extreme negative
        })
        
        # Act
        result = add_reboot_features(df_main, reboot)
        
        # Assert
        reboot_score2 = result["reboot_score2"][0]
        
        # Should be very close to 0 but not exactly 0
        self.assertGreaterEqual(reboot_score2, 0.0)
        self.assertLess(reboot_score2, 0.0001)
        self.assertFalse(np.isnan(reboot_score2))
        self.assertFalse(np.isinf(reboot_score2))

    def test_tu_031_add_reboot_features_extreme_positive_q_score(self) -> None:
        """TU-031: Test with extremely positive q_score (e.g., +100).
        
        When q_score is very positive, exp(-q_score) = exp(-100) is very small.
        reboot_score2 = 1/(1+exp(-100)) should be close to 1, not Inf or NaN.
        """
        # Arrange
        from common.preprocessing.preprocessing_reboot import add_reboot_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
        })
        
        reboot = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "q_score": ["100"],  # Extreme positive
        })
        
        # Act
        result = add_reboot_features(df_main, reboot)
        
        # Assert
        reboot_score2 = result["reboot_score2"][0]
        
        # Should be very close to 1 but not exactly 1
        self.assertLessEqual(reboot_score2, 1.0)
        self.assertGreater(reboot_score2, 0.9999)
        self.assertFalse(np.isnan(reboot_score2))
        self.assertFalse(np.isinf(reboot_score2))

    def test_tu_032_add_reboot_features_non_numeric_q_score(self) -> None:
        """TU-032: Test with non-numeric q_score values like 'N/A' or 'ERROR'.
        
        Non-numeric strings should result in NULL after cast to Float64.
        reboot_score2 should also be NULL. No exception should be raised.
        """
        # Arrange
        from common.preprocessing.preprocessing_reboot import add_reboot_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "i_intrn": ["A001", "A002"],
            "i_siren": ["111", "222"],
        })
        
        reboot = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E002"],
            "q_score": ["N/A", "ERROR"],  # Non-numeric
        })
        
        # Act - should not raise exception
        result = add_reboot_features(df_main, reboot)
        
        # Assert
        # After str.replace and cast, non-numeric becomes NULL
        q_score_values = result["q_score"].to_list()
        reboot_score2_values = result["reboot_score2"].to_list()
        
        # Both should be NULL (None in Python)
        for val in q_score_values:
            self.assertIsNone(val)
        for val in reboot_score2_values:
            self.assertIsNone(val)

    def test_tu_033_add_reboot_features_duplicate_entries_unique_first(self) -> None:
        """TU-033: Test join with multiple REBOOT entries for same enterprise.
        
        When reboot has multiple rows for the same i_uniq_kpi, unique(keep='first')
        should keep the first row. Verify order is deterministic.
        """
        # Arrange
        from common.preprocessing.preprocessing_reboot import add_reboot_features
        
        df_main = pl.DataFrame({
            "i_uniq_kpi": ["E001"],
            "i_intrn": ["A001"],
            "i_siren": ["111"],
        })
        
        # Multiple entries for E001 with different scores
        reboot = pl.DataFrame({
            "i_uniq_kpi": ["E001", "E001", "E001"],
            "q_score": ["1,0", "2,0", "3,0"],  # Different scores
            "d_score": ["2024-01-01", "2024-01-02", "2024-01-03"],  # Different dates
        })
        
        # Act
        result = add_reboot_features(df_main, reboot)
        
        # Assert - should have only one row for E001
        self.assertEqual(len(result), 1)
        
        # First row should be kept (q_score = 1.0)
        q_score = result["q_score"][0]
        self.assertAlmostEqual(q_score, 1.0, places=4)


if __name__ == "__main__":
    main()
