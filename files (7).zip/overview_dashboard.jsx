import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

const allUseCases = [
  { id: 1, uc: 'SmartInbox Classification', pattern: 'API', type: 'NLP Classification', statut: 'En prod', volume: 1000, unit: 'appels/h' },
  { id: 2, uc: 'Simplimmo', pattern: 'Batch + API', type: 'Tabulaire Régression', statut: 'En prod', volume: 5000, unit: 'appels/h' },
  { id: 3, uc: 'PitchEasy', pattern: 'Batch', type: 'Recommandation', statut: 'En prod', volume: 4500000, unit: 'data points/mois' },
  { id: 4, uc: 'CR-Auto Transcription', pattern: 'API', type: 'Speech-to-Text', statut: 'En prod', volume: null, unit: null },
  { id: 5, uc: 'CR-Auto Summary', pattern: 'API', type: 'NLP Génératif', statut: 'En prod', volume: 1600, unit: 'appels/h' },
  { id: 6, uc: 'ML4AML', pattern: 'Batch', type: 'Tabulaire Classification', statut: 'En dév', volume: 7000000, unit: 'data points/mois' },
  { id: 7, uc: 'Fraude Virement', pattern: 'API', type: 'Tabulaire Classification', statut: 'En dév', volume: 18000, unit: 'appels/h' },
  { id: 8, uc: 'Fraude Chèques', pattern: 'API', type: 'Tabulaire Classification', statut: 'En dév', volume: 2700, unit: 'appels/h' },
  { id: 9, uc: 'Advocacy Classification', pattern: 'Batch', type: 'NLP Classification', statut: 'En dév', volume: 1500, unit: 'data points/mois' },
  { id: 10, uc: 'Advocacy Tonalité', pattern: 'Batch', type: 'NLP Classification', statut: 'En dév', volume: 1500, unit: 'data points/mois' },
  { id: 11, uc: 'SmartInbox Outlook', pattern: 'API', type: 'NLP RAG', statut: 'En dév', volume: 467, unit: 'appels/h' },
  { id: 12, uc: 'GenAI Guardrails Safety', pattern: 'API', type: 'NLP Classification', statut: 'En prod', volume: 650, unit: 'appels/h' },
  { id: 13, uc: 'GenAI Guardrails Irrelevancy', pattern: 'API', type: 'NLP Classification', statut: 'En prod', volume: 650, unit: 'appels/h' },
  { id: 14, uc: 'GenAI Guardrails Toxicity', pattern: 'API', type: 'NLP Classification', statut: 'En prod', volume: 650, unit: 'appels/h' },
  { id: 15, uc: 'GenAI Guardrails Intentions', pattern: 'API', type: 'NLP Classification', statut: 'En prod', volume: 650, unit: 'appels/h' },
  { id: 16, uc: 'GenAI Guardrails Language', pattern: 'Intégré', type: 'NLP Classification', statut: 'En dév', volume: null, unit: null },
  { id: 17, uc: 'GenAI Service GR/RAG', pattern: 'API', type: 'NLP RAG', statut: 'En prod', volume: 650, unit: 'appels/h' },
  { id: 18, uc: 'RASA', pattern: 'N/A', type: 'Non défini', statut: 'En dév', volume: null, unit: null },
  { id: 19, uc: 'Corporate Lending/PDO', pattern: 'Batch', type: 'Tabulaire Régression', statut: 'En dév', volume: 70000, unit: 'data points/mois' },
  { id: 20, uc: 'Vox Compliance Transcription', pattern: 'Batch', type: 'Speech-to-Text', statut: 'En dév', volume: null, unit: null },
  { id: 21, uc: 'Vox Compliance Contrôle', pattern: 'Batch', type: 'NLP Génératif', statut: 'En dév', volume: 1500, unit: 'data points/mois' },
  { id: 22, uc: 'Réclamation', pattern: 'API', type: 'NLP Génératif', statut: 'En dév', volume: 25, unit: 'appels/h' },
  { id: 23, uc: 'PFM', pattern: 'Batch', type: 'Non défini', statut: 'Suspendu', volume: null, unit: null },
  { id: 24, uc: 'Scores de FID', pattern: 'Batch', type: 'Tabulaire Classification', statut: 'En dév', volume: 5000000, unit: 'data points/mois' },
];

const patternData = [
  { name: 'Batch', value: 9, color: '#06b6d4' },
  { name: 'API', value: 13, color: '#8b5cf6' },
  { name: 'Batch + API', value: 1, color: '#3b82f6' },
  { name: 'Autre', value: 1, color: '#64748b' },
];

const modelTypeData = [
  { name: 'NLP Classification', value: 8, color: '#f43f5e' },
  { name: 'Tabulaire', value: 6, color: '#3b82f6' },
  { name: 'NLP Génératif', value: 3, color: '#8b5cf6' },
  { name: 'NLP RAG', value: 2, color: '#06b6d4' },
  { name: 'Speech-to-Text', value: 2, color: '#f59e0b' },
  { name: 'Recommandation', value: 1, color: '#10b981' },
  { name: 'Non défini', value: 2, color: '#64748b' },
];

const statusData = [
  { name: 'En prod', value: 10, color: '#22c55e' },
  { name: 'En dév', value: 13, color: '#f59e0b' },
  { name: 'Suspendu', value: 1, color: '#64748b' },
];

const formatNumber = (num) => {
  if (num === null) return null;
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
  return num.toString();
};

const CustomTooltip = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    const percentage = ((data.value / 24) * 100).toFixed(1);
    return (
      <div style={{
        background: 'linear-gradient(135deg, rgba(15, 23, 42, 0.98) 0%, rgba(30, 41, 59, 0.98) 100%)',
        border: '1px solid rgba(148, 163, 184, 0.2)',
        borderRadius: '12px',
        padding: '14px 18px',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)'
      }}>
        <p style={{ color: '#f1f5f9', fontWeight: '600', fontSize: '14px', margin: '0 0 4px 0' }}>{data.name}</p>
        <p style={{ color: '#94a3b8', fontSize: '13px', margin: '0' }}>{data.value} UC ({percentage}%)</p>
      </div>
    );
  }
  return null;
};

const StatCard = ({ title, value, subtitle, icon, color, delay }) => (
  <div style={{
    background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.8) 0%, rgba(15, 23, 42, 0.9) 100%)',
    borderRadius: '20px',
    padding: '22px',
    border: '1px solid rgba(148, 163, 184, 0.1)',
    position: 'relative',
    overflow: 'hidden',
    animation: `fadeSlideUp 0.6s ease-out ${delay}s both`
  }}>
    <div style={{
      position: 'absolute', top: 0, right: 0, width: '100px', height: '100px',
      background: color, borderRadius: '50%', filter: 'blur(35px)', opacity: 0.3, transform: 'translate(30%, -30%)'
    }} />
    <div style={{ position: 'relative', zIndex: 1 }}>
      <div style={{ fontSize: '22px', marginBottom: '8px' }}>{icon}</div>
      <p style={{ color: '#64748b', fontSize: '11px', textTransform: 'uppercase', letterSpacing: '1px', fontWeight: '600', margin: '0 0 5px 0' }}>{title}</p>
      <p style={{ color: color, fontSize: '28px', fontWeight: '800', margin: '0 0 3px 0' }}>{value}</p>
      <p style={{ color: '#94a3b8', fontSize: '11px', margin: 0 }}>{subtitle}</p>
    </div>
  </div>
);

const ChartCard = ({ title, subtitle, icon, data, children }) => (
  <div style={{
    background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.8) 100%)',
    borderRadius: '24px',
    padding: '28px',
    border: '1px solid rgba(148, 163, 184, 0.1)'
  }}>
    <h3 style={{ fontSize: '16px', fontWeight: '700', marginBottom: '6px', display: 'flex', alignItems: 'center', gap: '10px', color: '#f8fafc' }}>
      <span>{icon}</span> {title}
    </h3>
    <p style={{ color: '#64748b', fontSize: '13px', marginBottom: '20px' }}>{subtitle}</p>
    <div style={{ height: '220px', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      {children}
    </div>
    <div style={{ marginTop: '20px', display: 'flex', flexWrap: 'wrap', gap: '10px', justifyContent: 'center' }}>
      {data.map((item, idx) => (
        <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11px', color: '#94a3b8' }}>
          <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: item.color }} />
          <span>{item.name} ({item.value})</span>
        </div>
      ))}
    </div>
  </div>
);

const Badge = ({ type, children }) => {
  const styles = {
    batch: { background: 'rgba(6, 182, 212, 0.15)', color: '#22d3ee' },
    api: { background: 'rgba(139, 92, 246, 0.15)', color: '#a78bfa' },
    mixed: { background: 'rgba(59, 130, 246, 0.15)', color: '#60a5fa' },
    integrated: { background: 'rgba(100, 116, 139, 0.15)', color: '#94a3b8' },
    prod: { background: 'rgba(34, 197, 94, 0.15)', color: '#4ade80' },
    dev: { background: 'rgba(251, 191, 36, 0.15)', color: '#fbbf24' },
    suspended: { background: 'rgba(100, 116, 139, 0.15)', color: '#64748b' },
  };
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', padding: '4px 10px', borderRadius: '20px',
      fontSize: '10px', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '0.5px', ...styles[type]
    }}>{children}</span>
  );
};

const getModelIcon = (type) => {
  if (type.includes('Tabulaire')) return '📊';
  if (type === 'Recommandation') return '🎯';
  if (type === 'NLP RAG') return '🔍';
  if (type === 'NLP Génératif') return '✨';
  if (type === 'Speech-to-Text') return '🎤';
  if (type === 'Non défini') return '❓';
  return '🤖';
};

const getModelIconClass = (type) => {
  if (type.includes('Tabulaire')) return 'rgba(59, 130, 246, 0.15)';
  if (type === 'Recommandation') return 'rgba(16, 185, 129, 0.15)';
  if (type === 'Speech-to-Text') return 'rgba(251, 191, 36, 0.15)';
  if (type === 'Non défini') return 'rgba(100, 116, 139, 0.15)';
  return 'rgba(244, 63, 94, 0.15)';
};

const getPatternBadgeType = (pattern) => {
  if (pattern === 'Batch') return 'batch';
  if (pattern === 'Batch + API') return 'mixed';
  if (pattern === 'Intégré' || pattern === 'N/A') return 'integrated';
  return 'api';
};

const getStatusBadgeType = (statut) => {
  if (statut === 'En prod') return 'prod';
  if (statut === 'Suspendu') return 'suspended';
  return 'dev';
};

const getVolumeColor = (volume) => {
  if (volume === null) return '#64748b';
  if (volume >= 1000000) return '#fb7185';
  if (volume >= 1000) return '#fbbf24';
  return '#94a3b8';
};

export default function OverviewDashboard() {
  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(180deg, #0f172a 0%, #020617 100%)',
      fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      padding: '40px',
      position: 'relative',
      overflow: 'hidden'
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
        @keyframes fadeSlideUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.7; }
        }
        @keyframes float {
          0%, 100% { transform: translateY(0) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(5deg); }
        }
      `}</style>

      <div style={{ position: 'fixed', top: '10%', left: '5%', width: '600px', height: '600px', background: 'radial-gradient(circle, rgba(6, 182, 212, 0.08) 0%, transparent 70%)', borderRadius: '50%', pointerEvents: 'none', animation: 'float 20s ease-in-out infinite' }} />
      <div style={{ position: 'fixed', bottom: '10%', right: '5%', width: '500px', height: '500px', background: 'radial-gradient(circle, rgba(139, 92, 246, 0.08) 0%, transparent 70%)', borderRadius: '50%', pointerEvents: 'none', animation: 'float 25s ease-in-out infinite reverse' }} />
      <div style={{ position: 'fixed', top: '50%', right: '20%', width: '400px', height: '400px', background: 'radial-gradient(circle, rgba(244, 63, 94, 0.06) 0%, transparent 70%)', borderRadius: '50%', pointerEvents: 'none', animation: 'float 22s ease-in-out infinite' }} />

      <div style={{ maxWidth: '1600px', margin: '0 auto', position: 'relative', zIndex: 1 }}>
        <div style={{ textAlign: 'center', marginBottom: '50px', animation: 'fadeSlideUp 0.6s ease-out' }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: '8px',
            background: 'linear-gradient(135deg, rgba(244, 63, 94, 0.15), rgba(139, 92, 246, 0.15))',
            padding: '8px 20px', borderRadius: '30px', marginBottom: '20px', border: '1px solid rgba(148, 163, 184, 0.1)'
          }}>
            <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#22c55e', animation: 'pulse 2s ease-in-out infinite' }} />
            <span style={{ color: '#94a3b8', fontSize: '13px', fontWeight: '600', letterSpacing: '1px' }}>PLATEFORME ML MONITORING</span>
          </div>
          <h1 style={{ 
            color: '#f8fafc', fontSize: '48px', fontWeight: '900', margin: '0 0 12px 0', letterSpacing: '-2px',
            background: 'linear-gradient(135deg, #f8fafc 0%, #94a3b8 100%)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text'
          }}>Vue d'ensemble des Use Cases</h1>
          <p style={{ color: '#64748b', fontSize: '18px', margin: 0, fontWeight: '500' }}>
            Inventaire complet et répartitions • 24 Use Cases recensés
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '18px', marginBottom: '40px' }}>
          <StatCard title="Total Use Cases" value="24" subtitle="Modèles recensés" icon="🎯" color="#fb7185" delay={0.1} />
          <StatCard title="Batch" value="9" subtitle="37.5% du total" icon="📦" color="#22d3ee" delay={0.13} />
          <StatCard title="API" value="13" subtitle="54.2% du total" icon="🔌" color="#a78bfa" delay={0.16} />
          <StatCard title="En Production" value="10" subtitle="41.7% déployés" icon="✅" color="#4ade80" delay={0.19} />
          <StatCard title="En Développement" value="13" subtitle="54.2% en cours" icon="🔧" color="#fbbf24" delay={0.22} />
          <StatCard title="Suspendu" value="1" subtitle="4.2% en pause" icon="⏸️" color="#64748b" delay={0.25} />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '30px', marginBottom: '40px' }}>
          <ChartCard title="Répartition par Pattern" subtitle="Distribution Batch vs API" icon="📊" data={patternData}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={patternData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={3}>
                  {patternData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} stroke="rgba(15, 23, 42, 0.8)" strokeWidth={3} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Répartition par Type de Modèle" subtitle="Catégories de modèles ML" icon="🧠" data={modelTypeData}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={modelTypeData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={2}>
                  {modelTypeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} stroke="rgba(15, 23, 42, 0.8)" strokeWidth={3} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Répartition par Statut" subtitle="Cycle de vie des UC" icon="🚀" data={statusData}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={3}>
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} stroke="rgba(15, 23, 42, 0.8)" strokeWidth={3} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        <div style={{
          background: 'linear-gradient(145deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.8) 100%)',
          borderRadius: '24px', padding: '32px', border: '1px solid rgba(148, 163, 184, 0.1)', marginBottom: '30px'
        }}>
          <div style={{ marginBottom: '28px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '6px' }}>
              <span style={{ fontSize: '24px' }}>📋</span>
              <h2 style={{ color: '#f1f5f9', fontSize: '22px', fontWeight: '700', margin: 0, letterSpacing: '-0.5px' }}>
                Listing Complet des 24 Use Cases
              </h2>
            </div>
            <p style={{ color: '#64748b', fontSize: '14px', margin: 0, marginLeft: '36px' }}>
              Tous les modèles ML recensés sur la plateforme
            </p>
          </div>

          <div style={{ overflowX: 'auto', borderRadius: '16px', border: '1px solid rgba(148, 163, 184, 0.1)' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead style={{ background: 'rgba(15, 23, 42, 0.8)' }}>
                <tr>
                  {['#', 'Use Case', 'Pattern', 'Type de Modèle', 'Statut', 'Volumétrie'].map((header, idx) => (
                    <th key={header} style={{
                      padding: '16px 20px', textAlign: 'left', fontSize: '11px', fontWeight: '700',
                      textTransform: 'uppercase', letterSpacing: '1px', color: '#94a3b8',
                      borderBottom: '1px solid rgba(148, 163, 184, 0.1)', width: idx === 0 ? '50px' : 'auto'
                    }}>{header}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {allUseCases.map((uc) => (
                  <tr key={uc.id} style={{ transition: 'background 0.2s ease' }}
                    onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(51, 65, 85, 0.4)'}
                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
                    <td style={{ padding: '14px 20px', fontSize: '13px', color: '#64748b', fontWeight: '500', borderBottom: '1px solid rgba(148, 163, 184, 0.05)' }}>
                      {uc.id}
                    </td>
                    <td style={{ padding: '14px 20px', fontSize: '13px', color: '#f8fafc', fontWeight: '600', borderBottom: '1px solid rgba(148, 163, 184, 0.05)' }}>
                      {uc.uc}
                    </td>
                    <td style={{ padding: '14px 20px', borderBottom: '1px solid rgba(148, 163, 184, 0.05)' }}>
                      <Badge type={getPatternBadgeType(uc.pattern)}>{uc.pattern}</Badge>
                    </td>
                    <td style={{ padding: '14px 20px', borderBottom: '1px solid rgba(148, 163, 184, 0.05)' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <div style={{
                          width: '26px', height: '26px', borderRadius: '8px',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          fontSize: '12px', background: getModelIconClass(uc.type)
                        }}>{getModelIcon(uc.type)}</div>
                        <span style={{ color: '#f8fafc', fontSize: '13px' }}>{uc.type}</span>
                      </div>
                    </td>
                    <td style={{ padding: '14px 20px', borderBottom: '1px solid rgba(148, 163, 184, 0.05)' }}>
                      <Badge type={getStatusBadgeType(uc.statut)}>{uc.statut}</Badge>
                    </td>
                    <td style={{ 
                      padding: '14px 20px', borderBottom: '1px solid rgba(148, 163, 184, 0.05)',
                      fontWeight: '600', fontFamily: "'SF Mono', 'Fira Code', monospace", fontSize: '12px',
                      color: getVolumeColor(uc.volume), fontStyle: uc.volume === null ? 'italic' : 'normal'
                    }}>
                      {uc.volume !== null ? (
                        <>{formatNumber(uc.volume)} <span style={{ color: '#64748b', fontWeight: '400' }}>{uc.unit}</span></>
                      ) : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div style={{ textAlign: 'center', marginTop: '50px', paddingTop: '30px', borderTop: '1px solid rgba(148, 163, 184, 0.1)' }}>
          <p style={{ color: '#475569', fontSize: '13px', margin: 0 }}>
            Dashboard Vue d'ensemble - Plateforme ML Monitoring • {new Date().toLocaleDateString('fr-FR', { year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>
      </div>
    </div>
  );
}
