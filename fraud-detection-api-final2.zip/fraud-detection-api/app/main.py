"""
Sparkov Fraud Detection API

Endpoints:
  GET  /health         → service health
  GET  /model/info     → model metadata
  GET  /predict        → score 1 transaction (Swagger form fields, random defaults)
  POST /predict        → score 1 transaction (JSON body)
  POST /predict/batch  → score up to 100 transactions
"""
from __future__ import annotations

import json, logging, pickle, random, time, uuid
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi

from app.schemas import (
    BatchPredictionResponse, BatchTransactionRequest, DecisionAction, Gender,
    HealthResponse, MerchantCategory, ModelInfoResponse, PredictionResponse,
    RiskLevel, TransactionRequest,
)
from app.observability import init_langfuse, shutdown_langfuse, trace_prediction, score_trace_feedback

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("fraud_api")

MODEL_DIR = Path(__file__).parent.parent / "model"
_model = _scaler = None
_encoders: dict[str, Any] = {}
_metadata: dict[str, Any] = {}
APP_VERSION = "3.0.0"

# ── Random defaults generated ONCE at startup ──────────────────────────
_MERCHANTS = [
    "fraud_Kirlin and Sons", "fraud_Sporer-Keebler", "fraud_Haley Group",
    "fraud_Gislason Group", "fraud_Reichel LLC", "fraud_Nader-Maggio",
    "fraud_Romaguera Ltd", "fraud_Champlin and Sons", "fraud_Connelly-Carter",
    "fraud_Hoppe-Parisian", "fraud_Bauch-Blanda", "fraud_Kihn Inc",
]
_JOBS = [
    "Mechanical engineer", "Sales professional", "Librarian", "Set designer",
    "Psychotherapist", "Paramedic", "Firefighter", "Nurse", "Accountant",
    "Data scientist", "Chef", "Architect", "Teacher", "Police officer",
]
_STATES = [
    "CA", "NY", "TX", "FL", "IL", "PA", "OH", "GA", "NC", "MI",
    "NJ", "VA", "WA", "AZ", "MA", "CO", "SC", "UT", "OR", "AL",
]


def _random_defaults() -> dict:
    """Generate a set of random realistic defaults at import time."""
    lat = round(random.uniform(25, 48), 4)
    lon = round(random.uniform(-125, -70), 4)
    # Merchant near or far (50/50)
    if random.random() > 0.5:
        m_lat = round(lat + random.uniform(-0.5, 0.5), 4)
        m_lon = round(lon + random.uniform(-0.5, 0.5), 4)
    else:
        m_lat = round(random.uniform(25, 48), 4)
        m_lon = round(random.uniform(-125, -70), 4)

    base = datetime(2020, 1, 1) + timedelta(days=random.randint(0, 364))
    hour = random.randint(0, 23)
    minute = random.randint(0, 59)
    dt_str = base.strftime(f"%Y-%m-%d {hour:02d}:{minute:02d}:00")

    birth_year = random.randint(1940, 2002)
    dob_str = f"{birth_year}-{random.randint(1,12):02d}-{random.randint(1,28):02d}"

    return {
        "amt": round(random.uniform(1, 2000), 2),
        "trans_date_trans_time": dt_str,
        "merchant": random.choice(_MERCHANTS),
        "category": random.choice(list(MerchantCategory)).value,
        "gender": random.choice(list(Gender)).value,
        "dob": dob_str,
        "job": random.choice(_JOBS),
        "state": random.choice(_STATES),
        "city_pop": random.choice([random.randint(100, 5000), random.randint(5000, 500000), random.randint(500000, 3000000)]),
        "lat": lat,
        "long": lon,
        "merch_lat": m_lat,
        "merch_long": m_lon,
    }


# Generate once at module load (= each server start / Swagger load)
_DEFAULTS = _random_defaults()


def _haversine(lat1, lon1, lat2, lon2):
    R = 6371.0
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    dlat, dlon = lat2 - lat1, lon2 - lon1
    a = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2) ** 2
    return float(R * 2 * np.arcsin(np.sqrt(a)))


def load_model():
    global _model, _scaler, _encoders, _metadata
    for name, ext in [("fraud_model", "pkl"), ("scaler", "pkl"), ("encoders", "pkl"), ("metadata", "json")]:
        if not (MODEL_DIR / f"{name}.{ext}").exists():
            raise FileNotFoundError(f"{name}.{ext} missing in {MODEL_DIR}")
    with open(MODEL_DIR / "fraud_model.pkl", "rb") as f:
        _model = pickle.load(f)
    with open(MODEL_DIR / "scaler.pkl", "rb") as f:
        _scaler = pickle.load(f)
    with open(MODEL_DIR / "encoders.pkl", "rb") as f:
        _encoders = pickle.load(f)
    with open(MODEL_DIR / "metadata.json") as f:
        _metadata = json.load(f)
    logger.info(
        "Model loaded: %d features, threshold=%.4f, ROC=%.4f",
        _metadata["n_features"], _metadata["optimal_threshold"], _metadata["cv_roc_auc"],
    )


@asynccontextmanager
async def lifespan(app: FastAPI):
    load_model()
    init_langfuse()
    yield
    shutdown_langfuse()


app = FastAPI(
    title="Sparkov Fraud Detection API",
    description="ML-powered credit card fraud detection using XGBoost on the Sparkov dataset.\n\n"
    "Use **GET /predict** in Swagger to test with individual form fields (random defaults on each reload).\n"
    "Use **POST /predict** for JSON body integration.",
    version=APP_VERSION,
    lifespan=lifespan,
)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.middleware("http")
async def tracking(request: Request, call_next):
    rid = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    t0 = time.perf_counter()
    resp = await call_next(request)
    resp.headers["X-Request-ID"] = rid
    resp.headers["X-Process-Time-Ms"] = f"{(time.perf_counter() - t0) * 1000:.2f}"
    return resp


# ── Feature preparation ────────────────────────────────────────────────

def prepare_features(req: TransactionRequest) -> np.ndarray:
    le = _encoders["label_encoders"]
    fm = _encoders["freq_maps"]

    dt = pd.Timestamp(req.trans_date_trans_time)
    dob = pd.Timestamp(req.dob)
    hour = dt.hour
    age = int((dt - dob).days / 365.25)
    dist = _haversine(req.lat, req.long, req.merch_lat, req.merch_long)

    features = {
        "log_amt": np.log1p(req.amt),
        "city_pop_log": np.log1p(req.city_pop),
        "distance_km": dist,
        "log_distance": np.log1p(dist),
        "far_merchant": int(dist > 100),
        "hour": hour,
        "hour_sin": np.sin(2 * np.pi * hour / 24),
        "hour_cos": np.cos(2 * np.pi * hour / 24),
        "day_of_week": dt.dayofweek,
        "is_weekend": int(dt.dayofweek >= 5),
        "is_night": int(hour >= 22 or hour < 6),
        "age": age,
        "amt_per_pop": req.amt / max(req.city_pop, 1),
        "log_amt_per_pop": np.log1p(req.amt / max(req.city_pop, 1)),
        "age_amt": age * np.log1p(req.amt),
    }

    for col, val in [("category", req.category.value), ("gender", req.gender.value)]:
        enc = le[col]
        features[f"{col}_enc"] = int(enc.transform([val])[0]) if val in enc.classes_ else 0

    for col, val in [("merchant", req.merchant), ("state", req.state), ("job", req.job)]:
        freq = fm[col]
        features[f"{col}_freq"] = freq.get(val, 1 / max(len(freq), 1))

    ordered = _metadata["feature_names"]
    return np.array([features[n] for n in ordered]).reshape(1, -1)


def classify_risk(p):
    if p < 0.15:
        return RiskLevel.LOW, DecisionAction.APPROVE
    if p < 0.45:
        return RiskLevel.MEDIUM, DecisionAction.REVIEW
    if p < 0.75:
        return RiskLevel.HIGH, DecisionAction.REVIEW
    return RiskLevel.CRITICAL, DecisionAction.BLOCK


def detect_risk_factors(req: TransactionRequest) -> list[str]:
    factors = []
    hour = pd.Timestamp(req.trans_date_trans_time).hour
    if hour >= 22 or hour < 6:
        factors.append(f"Late-night transaction ({hour:02d}h)")
    dist = _haversine(req.lat, req.long, req.merch_lat, req.merch_long)
    if dist > 100:
        factors.append(f"Merchant is {dist:.0f}km away from customer")
    if req.amt > 500:
        factors.append(f"High-value transaction: ${req.amt:,.2f}")
    if req.amt > 200 and req.city_pop < 5000:
        factors.append(f"Large purchase in small town (pop {req.city_pop:,})")
    return factors


def predict_single(req: TransactionRequest, request_id: str = "") -> PredictionResponse:
    # ── Feature engineering (timed) ──
    t0 = time.perf_counter()
    X_raw = prepare_features(req)
    feature_ms = (time.perf_counter() - t0) * 1000

    # Capture engineered features for tracing
    feature_dict = dict(zip(_metadata["feature_names"], X_raw.flatten().tolist()))

    # ── Inference (timed) ──
    t1 = time.perf_counter()
    X = _scaler.transform(X_raw)
    proba = float(_model.predict_proba(X)[0, 1])
    inference_ms = (time.perf_counter() - t1) * 1000

    threshold = _metadata["optimal_threshold"]
    risk, action = classify_risk(proba)
    factors = detect_risk_factors(req)

    # ── Langfuse trace (async, non-blocking) ──
    raw_input = {
        "amt": req.amt,
        "trans_date_trans_time": req.trans_date_trans_time,
        "merchant": req.merchant,
        "category": req.category.value,
        "gender": req.gender.value,
        "dob": req.dob,
        "job": req.job,
        "state": req.state,
        "city_pop": req.city_pop,
        "lat": req.lat,
        "long": req.long,
        "merch_lat": req.merch_lat,
        "merch_long": req.merch_long,
    }

    trace_prediction(
        request_id=request_id,
        raw_input=raw_input,
        engineered_features=feature_dict,
        feature_engineering_ms=feature_ms,
        inference_ms=inference_ms,
        fraud_probability=proba,
        threshold=threshold,
        is_fraud=proba >= threshold,
        risk_level=risk.value,
        recommended_action=action.value,
        risk_factors=factors,
        model_version=APP_VERSION,
        n_features=len(feature_dict),
    )

    return PredictionResponse(
        transaction_id=req.transaction_id,
        is_fraud=proba >= threshold,
        fraud_probability=round(proba, 6),
        risk_level=risk,
        recommended_action=action,
        threshold_used=threshold,
        risk_factors=factors,
    )


# ── Endpoints ──────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse, tags=["System"])
async def health():
    return HealthResponse(status="ok", model_loaded=_model is not None, version=APP_VERSION)


@app.get("/model/info", response_model=ModelInfoResponse, tags=["System"])
async def model_info():
    if not _metadata:
        raise HTTPException(503, "Model not loaded")
    return ModelInfoResponse(**{k: v for k, v in _metadata.items() if k in ModelInfoResponse.model_fields})


# ── Param name → OpenAPI schema path mapping ──
_PARAM_FIELD_MAP = {
    "amt": {"type": "number"},
    "trans_date_trans_time": {"type": "string"},
    "merchant": {"type": "string"},
    "category": {"type": "string"},
    "gender": {"type": "string"},
    "dob": {"type": "string"},
    "job": {"type": "string"},
    "state": {"type": "string"},
    "city_pop": {"type": "integer"},
    "lat": {"type": "number"},
    "long": {"type": "number"},
    "merch_lat": {"type": "number"},
    "merch_long": {"type": "number"},
}


def custom_openapi():
    """Regenerate OpenAPI schema with fresh random defaults on every call.
    This means each time /docs is loaded, the form fields get new values."""
    schema = get_openapi(
        title=app.title, version=app.version,
        description=app.description, routes=app.routes,
    )
    # Inject random defaults into GET /predict parameters
    defaults = _random_defaults()
    get_predict = schema.get("paths", {}).get("/predict", {}).get("get", {})
    for param in get_predict.get("parameters", []):
        name = param.get("name")
        if name in defaults:
            param.setdefault("schema", {})["default"] = defaults[name]
    return schema


app.openapi = custom_openapi


D = _DEFAULTS  # initial defaults for the function signature (required by Python)


@app.get("/predict", response_model=PredictionResponse, tags=["Prediction"],
         summary="Score a transaction (form fields — random defaults on each reload)")
async def predict_form(
    request: Request,
    amt: float = Query(D["amt"], gt=0, le=50000, description="Amount in USD"),
    trans_date_trans_time: str = Query(D["trans_date_trans_time"], description="Datetime YYYY-MM-DD HH:MM:SS"),
    merchant: str = Query(D["merchant"], min_length=1, description="Merchant name"),
    category: MerchantCategory = Query(D["category"], description="Merchant category"),
    gender: Gender = Query(D["gender"], description="Customer gender"),
    dob: str = Query(D["dob"], description="Date of birth YYYY-MM-DD"),
    job: str = Query(D["job"], min_length=1, description="Customer job title"),
    state: str = Query(D["state"], min_length=2, max_length=2, description="US state code"),
    city_pop: int = Query(D["city_pop"], ge=0, description="City population"),
    lat: float = Query(D["lat"], ge=-90, le=90, description="Customer latitude"),
    long: float = Query(D["long"], ge=-180, le=180, description="Customer longitude"),
    merch_lat: float = Query(D["merch_lat"], ge=-90, le=90, description="Merchant latitude"),
    merch_long: float = Query(D["merch_long"], ge=-180, le=180, description="Merchant longitude"),
):
    """Score a single transaction. Each field has a **random default value**
    that changes every time you reload /docs — just click Execute to test."""
    if not _model:
        raise HTTPException(503, "Model not loaded")
    req = TransactionRequest(
        amt=amt, trans_date_trans_time=trans_date_trans_time,
        merchant=merchant, category=category, gender=gender,
        dob=dob, job=job, state=state, city_pop=city_pop,
        lat=lat, long=long, merch_lat=merch_lat, merch_long=merch_long,
    )
    rid = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    return predict_single(req, request_id=rid)


@app.post("/predict", response_model=PredictionResponse, tags=["Prediction"],
          summary="Score a transaction (JSON body)")
async def predict_json(request: Request, body: TransactionRequest):
    """Score a single transaction via JSON body (for programmatic use)."""
    if not _model:
        raise HTTPException(503, "Model not loaded")
    rid = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    return predict_single(body, request_id=rid)


@app.post("/predict/batch", response_model=BatchPredictionResponse, tags=["Prediction"])
async def predict_batch(request: Request, body: BatchTransactionRequest):
    if not _model:
        raise HTTPException(503, "Model not loaded")
    rid = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    preds = [predict_single(t, request_id=f"{rid}_{i}") for i, t in enumerate(body.transactions)]
    return BatchPredictionResponse(
        total=len(preds), fraud_count=sum(1 for p in preds if p.is_fraud), predictions=preds,
    )


# ── Feedback endpoint (closes the human-in-the-loop) ──

from pydantic import BaseModel


class FeedbackRequest(BaseModel):
    trace_id: str
    is_actually_fraud: bool
    comment: str | None = None


class FeedbackResponse(BaseModel):
    status: str
    trace_id: str


@app.post("/feedback", response_model=FeedbackResponse, tags=["Feedback"],
          summary="Submit ground truth for a past prediction")
async def submit_feedback(body: FeedbackRequest):
    """Mark a past prediction as true/false positive. This scores the
    Langfuse trace with ground truth for model evaluation in production."""
    score_trace_feedback(
        trace_id=body.trace_id,
        is_actually_fraud=body.is_actually_fraud,
        comment=body.comment,
    )
    return FeedbackResponse(status="recorded", trace_id=body.trace_id)
