---
id: PROC_VIREMENTS
categorie: procedure
type: operation_courante
segment: [PART_STD, PART_PREM, PART_PRIV, PRO, JEUNE]
produits_lies: [CPT_ESS, CPT_HOR, CPT_PRIV, CPT_PRO, CPT_TREMP]
date_maj: 2024-12-05
mots_cles: [virement, SEPA, international, SWIFT, instantané, bénéficiaire, IBAN, délai, frais]
---

# Virements bancaires

## Virement SEPA (zone euro)

### En ligne / application mobile
- **Tarif** : gratuit
- **Délai** : 1 jour ouvré (J+1). Si le virement est saisi après 16h30 ou un jour non ouvré, il est traité le jour ouvré suivant.
- **Plafond** : configurable par le client dans l'espace en ligne, de 500 € à 10 000 € par opération (plafond par défaut : 3 000 €). Modification de plafond avec effet sous 48h (validation par authentification forte).

### En agence
- **Tarif** : 3,50 € par virement
- **Délai** : 1 jour ouvré

### Ajout d'un nouveau bénéficiaire
Pour des raisons de sécurité (DSP2), l'ajout d'un nouveau bénéficiaire de virement nécessite une authentification forte (confirmation via l'app mobile ou code SMS).

Un délai de sécurité de 72h est appliqué avant qu'un premier virement puisse être effectué vers un nouveau bénéficiaire ajouté en ligne. Ce délai ne s'applique pas si le bénéficiaire est ajouté en agence.

### Virement permanent
Il est possible de mettre en place des virements permanents (hebdomadaires, mensuels, trimestriels) depuis l'espace en ligne ou en agence. La modification ou suppression d'un virement permanent prend effet à compter du prochain virement programmé, sous réserve de saisie avant le jour ouvré précédent l'exécution.

## Virement instantané (SEPA Instant)

- **Tarif** : 0,80 € par virement
- **Délai** : exécuté en moins de 10 secondes, 24h/24, 7j/7 (y compris week-ends et jours fériés)
- **Plafond** : 5 000 € par opération (non modifiable pour l'instant)
- **Disponible** : uniquement depuis l'application mobile ou l'espace en ligne
- **Irrévocable** : un virement instantané ne peut pas être annulé après exécution

Attention : le virement instantané n'est possible que si la banque du bénéficiaire est également adhérente au système SEPA Instant Credit Transfer (SCT Inst). Si ce n'est pas le cas, le virement sera automatiquement exécuté comme un virement SEPA standard (J+1) et la tarification de 0,80 € ne sera pas appliquée.

## Virement international (SWIFT)

Pour les virements hors zone SEPA (hors zone euro ou vers des pays ne participant pas au système SEPA).

### En ligne
- **Frais SHA** (frais partagés) : 9,50 €
- **Frais OUR** (tous frais à la charge de l'émetteur) : 18,00 €

### En agence
- **Frais SHA** : 15,00 €
- **Frais OUR** : 25,00 €

### Délais
- Zone EEE hors SEPA : 1 à 2 jours ouvrés
- Hors EEE : 2 à 5 jours ouvrés selon le pays et les banques intermédiaires
- Certains pays peuvent impliquer des vérifications complémentaires (LCB-FT) entraînant un délai supplémentaire.

### Informations nécessaires
- IBAN ou numéro de compte du bénéficiaire
- Code BIC/SWIFT de la banque bénéficiaire
- Nom et adresse du bénéficiaire
- Motif du virement (obligatoire pour certaines destinations)
- Devise souhaitée

### Taux de change
Pour les virements en devises, le taux de change appliqué est le taux interbancaire du jour majoré d'une marge de 1,5 %. Le taux exact est affiché avant la confirmation du virement en ligne.

Les clients Compte Privilège bénéficient d'une marge réduite de 0,80 %.

## Annulation d'un virement

- **Virement SEPA classique** : annulation possible tant que le virement n'a pas été exécuté (avant 16h30 le jour de saisie). Au-delà, une demande de recall peut être effectuée mais n'est pas garantie (dépend de la banque bénéficiaire). Frais de recall : 25,00 €.
- **Virement instantané** : aucune annulation possible.
- **Virement international** : annulation possible dans un délai très court après saisie. Contacter immédiatement le service client.
