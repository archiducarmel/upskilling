---
id: PROC_OPPOSITION_CARTE
categorie: procedure
type: urgence
segment: [PART_STD, PART_PREM, PART_PRIV, PRO, JEUNE]
produits_lies: [CB_CLASSIC, CB_PREMIER, CB_INFINITE, CB_BUSINESS]
date_maj: 2025-01-08
mots_cles: [opposition, carte, vol, perte, fraude, bloquer, urgence, remboursement]
---

# Opposition carte bancaire

## En cas de perte ou de vol

### Étape 1 — Faire opposition immédiatement

Appeler le service d'opposition 24h/24, 7j/7 :
- **Depuis la France** : 09 69 39 21 34 (appel non surtaxé)
- **Depuis l'étranger** : +33 1 44 92 31 99

L'opposition est irrévocable et prend effet immédiatement.

Un numéro d'opposition est communiqué à l'issue de l'appel. **Le noter et le conserver** : il constitue la preuve de la date et l'heure de l'opposition.

Alternativement, l'opposition peut être faite :
- Depuis l'application "Banque Verte & Moi" (menu Carte > Faire opposition)
- Via le serveur interbancaire : 0 892 705 705 (0,35 €/min + prix d'appel, en cas d'impossibilité de joindre Banque Verte)

### Étape 2 — Déposer plainte (en cas de vol uniquement)

Si la carte a été volée, déposer plainte au commissariat ou à la gendarmerie dans les plus brefs délais. Le récépissé de dépôt de plainte sera demandé par la banque pour le traitement du dossier.

En cas de simple perte, le dépôt de plainte n'est pas obligatoire mais reste recommandé.

### Étape 3 — Commander une nouvelle carte

Contacter le conseiller ou se rendre en agence pour commander une nouvelle carte. Délai de fabrication : 7 à 10 jours ouvrés. La nouvelle carte aura un nouveau numéro.

En attendant la réception de la nouvelle carte, il est possible d'effectuer des retraits au guichet de l'agence avec une pièce d'identité (dans la limite de 300 € par jour).

Frais de remplacement : **gratuit** en cas de vol (sur présentation du récépissé de plainte). En cas de perte : 15,00 € de frais de renouvellement anticipé.

### Étape 4 — Vérifier les opérations sur le compte

Le client doit surveiller son relevé de compte et signaler toute opération non reconnue dans un délai de 13 mois suivant la date de débit (70 jours pour les opérations hors EEE).

## En cas d'utilisation frauduleuse (carte en votre possession)

Si le client constate des opérations qu'il n'a pas effectuées alors qu'il est toujours en possession de sa carte :

1. **Bloquer temporairement la carte** depuis l'appli (menu Carte > Blocage temporaire) pour éviter de nouvelles opérations frauduleuses.
2. **Contester les opérations** depuis l'espace client en ligne (Mes opérations > Contester) ou en contactant le service client au 01 44 92 30 00.
3. Un formulaire de contestation sera adressé par e-mail. Le retourner signé sous 15 jours.
4. Remboursement provisoire : Banque Verte crédite le compte sous 5 jours ouvrés après réception de la contestation, dans l'attente de l'enquête.

## Responsabilité du client

- **Avant l'opposition** : le client supporte les pertes liées à l'utilisation frauduleuse dans la limite de 50 € (sauf en cas de négligence grave : code PIN noté sur la carte, carte laissée sans surveillance dans un lieu public).
- **Après l'opposition** : le client ne supporte aucune perte. Les opérations frauduleuses postérieures à l'opposition sont intégralement remboursées.
- **En cas de phishing / fraude en ligne** : si le client a communiqué ses données de carte suite à un e-mail ou SMS frauduleux, la franchise de 50 € s'applique. Banque Verte recommande de ne JAMAIS communiquer son numéro de carte, sa date d'expiration ou son cryptogramme par téléphone ou par e-mail.

## Délai de remboursement

Les opérations frauduleuses déclarées dans les délais légaux sont remboursées :
- Sous 1 jour ouvré pour les opérations non autorisées en zone SEPA
- Sous 5 jours ouvrés pour les opérations hors zone SEPA
- Remboursement provisoire dans l'attente de l'enquête si le montant dépasse 500 €
