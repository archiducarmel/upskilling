---
id: PROC_OPERATIONS_COURANTES
categorie: procedure
type: operation_courante
segment: [PART_STD, PART_PREM, PART_PRIV, PRO, JEUNE]
produits_lies: [CB_CLASSIC, CB_PREMIER, CB_INFINITE, CB_BUSINESS]
date_maj: 2025-01-22
mots_cles: [plafond, modifier, augmenter, baisser, chéquier, adresse, coordonnées, clôture, fermer, résilier]
---

# Procédures courantes

## Modifier les plafonds de carte bancaire

### Modification temporaire (depuis l'app ou l'espace web)
Le client peut augmenter temporairement ses plafonds de paiement et de retrait directement depuis l'application "Banque Verte & Moi" :
1. Menu **Carte** > **Gérer mes plafonds**
2. Sélectionner le type de plafond (paiement ou retrait)
3. Choisir le nouveau montant et la durée (1 à 30 jours)
4. Confirmer par authentification forte (empreinte digitale ou code)

L'augmentation temporaire est plafonnée à 2 fois le plafond contractuel. Effet immédiat. Retour automatique au plafond initial à l'expiration de la période choisie.

### Modification définitive
Contacter son conseiller par téléphone, en agence, ou via la messagerie sécurisée de l'espace client.
- **Hausse de plafond** : soumise à validation du conseiller. Délai : 48 à 72h. Le conseiller peut demander un justificatif de revenus si la hausse est importante.
- **Baisse de plafond** : sans condition. Effet sous 24h.

Plafonds maximaux autorisés par carte :
| Carte         | Paiement max 30j | Retrait max 7j |
|---------------|------------------|----------------|
| Visa Classic  | 4 000 €          | 800 €          |
| Visa Premier  | 8 000 €          | 2 500 €        |
| Visa Infinite | 20 000 €         | 5 000 €        |
| Visa Business | 15 000 €         | 3 500 €        |

## Commander un chéquier

### Depuis l'app ou l'espace web
Menu **Compte** > **Commander un chéquier**. Livraison à domicile sous 5 à 8 jours ouvrés par courrier simple (gratuit) ou par recommandé (5,20 €).

### En agence
Commander directement auprès du guichet. Retrait possible en agence sous 5 jours ouvrés.

### Points d'attention
- La délivrance d'un chéquier n'est pas un droit : la banque peut refuser si le client est en situation d'interdiction bancaire ou de fichage Banque de France.
- En cas de non-utilisation prolongée (> 1 an), la commande de nouveau chéquier peut nécessiter une validation du conseiller.
- Opposition chéquier (perte/vol) : appeler le 09 69 39 21 34 ou le Centre National d'Appel des Chèques Perdus ou Volés au 08 92 68 32 08. Frais d'opposition : 15,00 €.

## Changer d'adresse / coordonnées

### Changement d'adresse postale
- **En ligne** : Espace client > **Mon profil** > **Modifier mon adresse**. Justificatif de domicile de moins de 3 mois à téléverser. Traitement sous 48h.
- **En agence** : immédiat sur présentation d'un justificatif.

### Changement de numéro de téléphone / e-mail
- **En ligne** : Espace client > **Mon profil** > **Mes coordonnées**. Le changement de numéro de téléphone nécessite une validation par SMS sur l'ancien numéro (ou passage en agence si l'ancien numéro n'est plus accessible).

### Changement de nom (mariage, divorce)
Se rendre en agence avec :
- La nouvelle pièce d'identité au nom actuel
- L'acte de mariage ou le jugement de divorce
Délai : mise à jour sous 5 jours ouvrés. Nouvelle carte bancaire sous 7 à 10 jours (frais de renouvellement anticipé : 15,00 €).

## Clôturer un compte

### Procédure
La clôture peut être demandée :
- Par courrier recommandé avec accusé de réception adressé à l'agence
- En agence (signature d'un formulaire de clôture)
- Via l'espace client en ligne (pour les comptes sans crédit en cours)

La clôture est gratuite. Le compte doit être à solde nul ou positif. Si le solde est positif, indiquer un RIB pour le virement du solde restant.

### Délais
- Compte courant sans produit associé : clôture sous 10 jours ouvrés
- Compte avec carte bancaire : résiliation de la carte et restitution/destruction sous 10 jours. Le reliquat de cotisation annuelle n'est pas remboursé.
- Compte avec prélèvements / virements permanents : il est vivement recommandé d'utiliser le service de mobilité bancaire au préalable.

### Service de mobilité bancaire (loi Macron)
Gratuit. La nouvelle banque se charge de transférer les prélèvements et virements récurrents. Délai légal : 22 jours ouvrés maximum. Banque Verte adresse un relevé des opérations récurrentes au client et à la nouvelle banque.

### Clôture Livret A / PEL / Assurance Vie
- **Livret A / LDDS** : clôture en agence ou par courrier. Fonds virés sous 48h.
- **PEL** : clôture possible à tout moment (attention : avant 4 ans, perte des droits au prêt). Fonds virés sous 5 jours ouvrés.
- **Assurance Vie** : rachat total = clôture. Fonds virés sous 30 jours maximum (72h en pratique chez Banque Verte). Conséquences fiscales à étudier avec le conseiller avant toute clôture.
