---
id: PROD_ASSURANCE_MDP
categorie: produit
type: assurance
segment: [PART_STD, PART_PREM, PART_PRIV, PRO, JEUNE]
produits_lies: [CB_CLASSIC, CB_PREMIER, CB_INFINITE, CB_BUSINESS]
date_maj: 2025-01-10
mots_cles: [assurance, moyens de paiement, perte, vol, carte, chéquier, clés, papiers]
---

# Assurance des moyens de paiement

L'assurance des moyens de paiement protège le client en cas de perte, vol ou utilisation frauduleuse de ses moyens de paiement et de ses papiers d'identité.

## Formule Essentielle — 2,50 €/mois

Garanties :
- Perte et vol de cartes bancaires Banque Verte : prise en charge de la franchise de 50 € en cas d'utilisation frauduleuse avant opposition
- Perte et vol de chéquier : prise en charge des frais d'opposition (15 €)
- Utilisation frauduleuse de la carte : remboursement intégral des opérations frauduleuses non couvertes par la banque
- Plafond annuel de garantie : 8 000 €

## Formule Intégrale — 4,80 €/mois

Inclut toutes les garanties de la Formule Essentielle, plus :
- Perte et vol des papiers d'identité (CNI, passeport, permis de conduire) : remboursement des frais de renouvellement jusqu'à 100 €
- Perte et vol des clés (domicile, véhicule) : prise en charge des frais de serrurier jusqu'à 300 € et du remplacement des clés
- Vol d'espèces retirées dans les 48h suivant un retrait au DAB : indemnisation jusqu'à 500 €
- Vol du téléphone mobile : indemnisation jusqu'à 400 € (franchise 50 €, téléphone de moins de 2 ans)
- Plafond annuel de garantie : 15 000 €

## Informations importantes

- La Formule Intégrale est **incluse** dans le Compte Horizon et le Compte Privilège (pas de surcoût).
- L'assurance couvre **toutes les cartes bancaires** Banque Verte du souscripteur, y compris celles du conjoint si elles sont rattachées au même compte.
- Les sinistres doivent être déclarés dans les **48 heures** suivant la découverte de la perte ou du vol.
- Déclaration de sinistre : par téléphone au 01 44 92 31 80 ou via l'espace client en ligne (rubrique Assurance > Déclarer un sinistre).

## Résiliation

L'assurance peut être résiliée à tout moment après la première année, avec un préavis d'un mois. La résiliation prend effet à la fin du mois suivant la demande.

---

---
id: PROC_CONTESTATION_PRELEVEMENT
categorie: procedure
type: operation_courante
segment: [PART_STD, PART_PREM, PART_PRIV, PRO, JEUNE]
date_maj: 2024-11-25
mots_cles: [prélèvement, contester, rejeter, rembourser, annuler, SEPA, mandat, créancier, abonnement]
---

# Contestation et gestion des prélèvements

## Contester un prélèvement déjà passé

### Prélèvement autorisé (avec mandat SEPA valide)
Le client dispose de **8 semaines** (56 jours) à compter de la date de débit pour demander le remboursement d'un prélèvement SEPA autorisé, sans avoir à justifier sa demande.

Procédure :
1. Depuis l'espace client en ligne : Mes opérations > Sélectionner le prélèvement > Contester
2. OU depuis l'application mobile : Historique > Appui long sur l'opération > Contester
3. OU en agence avec un formulaire papier

Le remboursement est effectué sous **10 jours ouvrés** après la demande.

### Prélèvement non autorisé (sans mandat valide)
Si le client n'a jamais signé de mandat SEPA pour ce créancier, le délai de contestation est de **13 mois** à compter de la date de débit. Le remboursement est effectué immédiatement (J+1).

## Bloquer un prélèvement futur

### Révoquer un mandat de prélèvement (blacklister un créancier)
Pour empêcher définitivement un créancier de prélever :
1. Espace client en ligne : Mes prélèvements > Gérer mes mandats > Révoquer
2. OU contacter le service client ou le conseiller
3. Il est AUSSI recommandé d'informer le créancier de la révocation du mandat

### Créer une liste noire / liste blanche
Depuis l'espace client, le client peut :
- **Liste noire** : bloquer tous les prélèvements d'un créancier spécifique (par ICS - Identifiant Créancier SEPA)
- **Liste blanche** : n'autoriser QUE les prélèvements des créanciers listés (tous les autres seront rejetés automatiquement)

Attention : le blocage d'un prélèvement ne résilie pas le contrat avec le créancier. Le client reste redevable de sa dette et doit contacter le créancier pour résilier le contrat sous-jacent.

## Prélèvement rejeté pour provision insuffisante

Frais de rejet : 20,00 € (plafonné au montant du prélèvement si celui-ci est inférieur à 20 €).

Conséquences possibles :
- Le créancier peut représenter le prélèvement (généralement 2 à 5 jours après)
- En cas de rejet d'un prélèvement de crédit, le client risque un signalement au FICP (Fichier des Incidents de remboursement des Crédits aux Particuliers)
- Plusieurs rejets consécutifs peuvent entraîner une inscription au FCC (Fichier Central des Chèques) pour les chèques ou au FICP pour les crédits

Conseil : en cas de difficulté temporaire, contacter le conseiller AVANT la date de prélèvement pour mettre en place une solution (décalage de date, mise en place d'un échéancier avec le créancier).

---

---
id: PROC_MOBILITE_BANCAIRE
categorie: procedure
type: operation_courante
segment: [PART_STD, PART_PREM, PART_PRIV, PRO, JEUNE]
date_maj: 2024-08-15
mots_cles: [mobilité bancaire, changer de banque, transfert, Macron, prélèvements, virements permanents, clôture]
---

# Mobilité bancaire (loi Macron)

## Principe

Depuis la loi Macron (2017), tout client peut demander à sa nouvelle banque de prendre en charge le transfert de ses prélèvements et virements récurrents depuis son ancien compte. C'est gratuit et automatique.

## Comment ça marche quand un client ARRIVE chez Banque Verte

1. Le client ouvre un compte chez Banque Verte
2. Il signe un mandat de mobilité bancaire en agence ou en ligne
3. Il fournit le RIB de son ancien compte
4. Banque Verte contacte l'ancienne banque et récupère la liste des opérations récurrentes des 13 derniers mois
5. Banque Verte informe chaque émetteur de prélèvement et chaque émetteur de virement récurrent du nouveau RIB
6. Les opérations basculent progressivement sur le nouveau compte Banque Verte

Délai légal : **22 jours ouvrés** maximum à compter de la signature du mandat.

## Comment ça marche quand un client QUITTE la Banque Verte

1. Le client ouvre un compte dans sa nouvelle banque et y signe le mandat de mobilité
2. La nouvelle banque contacte Banque Verte
3. Banque Verte transmet la liste des opérations récurrentes sous 5 jours ouvrés
4. La nouvelle banque prend le relais pour les transferts

Banque Verte maintient l'ancien compte ouvert pendant **13 mois** après la dernière opération transférée, pour intercepter les prélèvements ou virements résiduels et rediriger le client vers son nouveau compte.

## Ce que la mobilité bancaire NE couvre PAS

- Les crédits en cours (un crédit immobilier reste domicilié chez la banque qui l'a accordé)
- Les produits d'épargne réglementée (Livret A, LDDS, PEL) : ils doivent être clôturés/transférés séparément
- L'assurance vie : le transfert d'un contrat AV vers un autre établissement n'est pas possible (il faut racheter et re-souscrire, avec les conséquences fiscales que cela implique)
- Les procurations et co-titularités : doivent être reconfigurées manuellement

## Conseil

Il est recommandé de conserver l'ancien compte ouvert pendant 2 à 3 mois après l'activation de la mobilité, le temps de s'assurer que tous les prélèvements ont bien basculé. Certains créanciers (administrations, organismes publics) peuvent mettre plus de temps à mettre à jour le RIB.
