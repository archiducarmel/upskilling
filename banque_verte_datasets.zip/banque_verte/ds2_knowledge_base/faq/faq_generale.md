---
id: FAQ_GENERAL
categorie: faq
type: questions_frequentes
segment: [PART_STD, PART_PREM, PART_PRIV, PRO, JEUNE]
date_maj: 2025-02-28
mots_cles: [faq, question, fréquente, aide, problème, comment, pourquoi, combien]
---

# Questions fréquentes

## Compte courant et opérations

**Q : Quels sont les frais de tenue de compte ?**
R : Les frais de tenue de compte sont de 1,50 € par mois. Ils sont inclus dans toutes les offres packagées (Compte Essentiel, Horizon, Privilège, Tremplin, Pro Vert). Ils ne sont facturés séparément que si le client dispose d'un compte sans offre associée.

**Q : Comment consulter mon solde rapidement ?**
R : Plusieurs options : l'application "Banque Verte & Moi" (solde affiché dès l'ouverture), l'espace client web, le serveur vocal au 09 69 39 21 34 (tapez 1), ou par SMS en envoyant "SOLDE" au 06 10 20 30 40 (service gratuit, hors coût SMS).

**Q : Qu'est-ce que le découvert autorisé et comment ça marche ?**
R : Le découvert autorisé est un montant négatif toléré sur votre compte courant. Il est accordé par votre conseiller et mentionné dans votre convention de compte. Si vous dépassez ce montant, des commissions d'intervention (8 €/opération, max 80 €/mois) et des frais de forçage peuvent s'appliquer. Les agios (intérêts débiteurs) sont calculés quotidiennement et prélevés chaque trimestre.

**Q : Mon prélèvement a été rejeté. Que faire ?**
R : Un prélèvement est rejeté quand le solde disponible (y compris découvert autorisé) est insuffisant. Frais de rejet : 20 €. Contactez votre créancier pour convenir d'une nouvelle date de prélèvement, puis approvisionnez votre compte. Si le rejet concerne un prélèvement important (loyer, crédit), contactez rapidement votre conseiller pour éviter des conséquences (fichage FICP pour un crédit par exemple).

**Q : Comment obtenir un RIB ?**
R : Le RIB est accessible gratuitement depuis l'application mobile (menu Compte > Mon RIB), depuis l'espace client web, ou au dos de votre chéquier. Vous pouvez aussi le demander en agence ou au guichet automatique. Format disponible : IBAN + BIC en PDF.

## Carte bancaire

**Q : Ma carte a été avalée par un distributeur, que faire ?**
R : Si c'est un distributeur Banque Verte : rendez-vous en agence avec votre pièce d'identité pour la récupérer (sous 48h, si l'agence est ouverte). Si c'est un distributeur d'une autre banque : la carte est généralement détruite après 48h. Faites opposition et commandez une nouvelle carte. Si vous suspectez une tentative de fraude (dispositif suspect sur le DAB), faites opposition immédiatement.

**Q : Comment activer le paiement sans contact ?**
R : Le paiement sans contact est activé par défaut sur toutes les nouvelles cartes. Pour l'activer ou le désactiver, rendez-vous dans l'application mobile > Menu Carte > Paiement sans contact. La modification prend effet immédiatement. Le plafond sans contact est de 50 € par transaction. Au-delà, la saisie du code PIN est requise.

**Q : J'ai oublié mon code PIN, comment faire ?**
R : Depuis l'application "Banque Verte & Moi" : Menu Carte > Code PIN > Consulter mon code. Authentification par empreinte digitale ou mot de passe. Vous pouvez aussi appeler le service client au 01 44 92 30 00.
Attention : après 3 saisies erronées du code PIN, la carte est bloquée automatiquement. Rendez-vous en agence avec une pièce d'identité pour la débloquer.

**Q : Comment payer en ligne de manière sécurisée ?**
R : Banque Verte utilise le système d'authentification forte 3D Secure. Pour chaque paiement en ligne supérieur à 30 €, une notification est envoyée sur l'application mobile pour valider le paiement (par empreinte, reconnaissance faciale ou code). Si vous n'avez pas l'appli, un code SMS est envoyé sur votre numéro de téléphone enregistré. Pensez à maintenir votre numéro de téléphone à jour.

## Épargne

**Q : Quel est le taux du Livret A en ce moment ?**
R : Le taux du Livret A est de 2,40 % net depuis le 1er février 2025. Ce taux est révisé par l'État deux fois par an (1er février et 1er août). Les intérêts sont exonérés d'impôt et de prélèvements sociaux.

**Q : Puis-je avoir un Livret A dans deux banques différentes ?**
R : Non, la loi interdit de détenir plus d'un Livret A par personne. Lors de l'ouverture, la banque vérifie auprès de l'administration fiscale que vous n'en possédez pas déjà un. En cas de doublon détecté, le second livret devra être clôturé.

**Q : Comment fonctionnent les intérêts du Livret A ?**
R : Les intérêts sont calculés par quinzaine (du 1er au 15 et du 16 au dernier jour du mois). Un dépôt effectué le 10 janvier ne commence à produire des intérêts que le 16 janvier. Un retrait le 10 janvier cesse de produire des intérêts dès le 1er janvier. Les intérêts annuels sont versés et capitalisés le 31 décembre.

**Q : Mon PEL arrive à 4 ans, que se passe-t-il ?**
R : Après 4 ans, votre PEL vous ouvre droit à un prêt épargne logement à taux privilégié (2,25 % pour les PEL ouverts en 2025). Vous pouvez aussi continuer à verser sur votre PEL pendant encore 6 ans (durée max 10 ans). Après 10 ans, le PEL ne peut plus recevoir de versements mais continue à produire des intérêts pendant 5 ans supplémentaires. La clôture reste possible à tout moment après 4 ans sans pénalité.

**Q : Comment fonctionne la fiscalité de l'assurance vie après 8 ans ?**
R : Après 8 ans de détention, les gains (intérêts et plus-values) réalisés lors d'un rachat bénéficient d'un abattement annuel de 4 600 € pour une personne seule (9 200 € pour un couple marié ou pacsé). Au-delà de cet abattement, les gains sont imposés à 24,7 % (7,5 % IR + 17,2 % prélèvements sociaux). Avant 8 ans, c'est le PFU de 30 % qui s'applique. Il est donc souvent intéressant d'attendre les 8 ans avant d'effectuer un rachat.

## Crédit

**Q : Quel apport faut-il pour un crédit immobilier ?**
R : La Banque Verte recommande un apport personnel d'au moins 10 % du montant de l'opération. Cet apport couvre généralement les frais de notaire (environ 7-8 % dans l'ancien, 2-3 % dans le neuf) et les frais de garantie. Un apport plus important améliore les conditions de taux. Le financement sans apport est exceptionnellement possible pour les profils à hauts revenus ou les fonctionnaires.

**Q : Est-ce que je peux changer d'assurance emprunteur ?**
R : Oui, depuis la loi Lemoine (2022), vous pouvez changer d'assurance emprunteur à tout moment, sans frais et sans attendre la date anniversaire. La nouvelle assurance doit présenter des garanties au moins équivalentes. Envoyez votre demande de substitution à votre conseiller : la banque dispose de 10 jours ouvrés pour accepter ou motiver un refus.

**Q : Puis-je rembourser mon crédit par anticipation ?**
R : Oui. Pour le crédit immobilier, des indemnités de remboursement anticipé (IRA) peuvent être dues : maximum 3 % du capital restant dû ou 6 mois d'intérêts (le montant le plus faible). Certaines offres promotionnelles prévoient l'absence d'IRA. Pour le crédit conso, les IRA sont plafonnées à 1 % ou 0,5 % selon la durée restante.

## Services en ligne et application

**Q : J'ai oublié mon identifiant ou mot de passe de l'espace client.**
R : Rendez-vous sur banqueverte.fr > "Identifiant oublié" : votre identifiant vous sera renvoyé par SMS. Pour le mot de passe : cliquez sur "Mot de passe oublié", un lien de réinitialisation sera envoyé à votre adresse e-mail. Si vous n'avez accès ni à votre téléphone ni à votre e-mail, rendez-vous en agence avec une pièce d'identité.

**Q : Comment activer l'application mobile ?**
R : 1) Téléchargez "Banque Verte & Moi" sur l'App Store ou Google Play. 2) Entrez votre identifiant espace client. 3) Validez par le code reçu par SMS. 4) Choisissez un code PIN à 6 chiffres ou activez la biométrie. Le premier accès nécessite obligatoirement le numéro de téléphone enregistré auprès de la banque.
