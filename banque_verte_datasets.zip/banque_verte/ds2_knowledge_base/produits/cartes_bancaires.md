---
id: PROD_CARTES
categorie: produit
type: carte_bancaire
segment: [PART_STD, PART_PREM, PART_PRIV, PRO, JEUNE]
produits_lies: [CPT_ESS, CPT_HOR, CPT_PRIV, CPT_PRO, CPT_TREMP]
date_maj: 2025-02-10
mots_cles: [carte bancaire, visa, plafond, sans contact, retrait, paiement, opposition, perte, vol]
---

# Cartes bancaires Banque Verte

La Banque Verte propose quatre gammes de cartes Visa adaptées aux besoins de chaque client.

## Visa Classic

Carte de paiement et de retrait disponible en débit immédiat ou différé.

- Cotisation annuelle : 46,00 € (gratuite si incluse dans un pack Compte Essentiel ou Compte Tremplin)
- Plafond de paiement : 2 500 € sur 30 jours glissants
- Plafond de retrait : 500 € sur 7 jours glissants
- Paiement sans contact : oui, jusqu'à 50 € par transaction
- Aucune assurance voyage incluse

## Visa Premier

Carte haut de gamme avec assurances voyage intégrées.

- Cotisation annuelle : 138,00 € (gratuite si incluse dans le Compte Horizon)
- Plafond de paiement : 5 000 € sur 30 jours glissants
- Plafond de retrait : 1 500 € sur 7 jours glissants
- Paiement sans contact : oui, jusqu'à 50 € par transaction
- Assurances incluses : annulation voyage, retard avion/bagage, assistance rapatriement, RC villégiature, garantie neige et montagne
- Conditions de revenus : ≥ 2 200 €/mois nets domiciliés ou encours épargne ≥ 40 000 €

## Visa Infinite

Carte prestige réservée aux clients Banque Privée.

- Cotisation annuelle : 340,00 € (gratuite si incluse dans le Compte Privilège)
- Plafond de paiement : 12 000 € sur 30 jours glissants
- Plafond de retrait : 3 000 € sur 7 jours glissants
- Paiement sans contact : oui, jusqu'à 50 € par transaction
- Débit différé systématique
- Assurances renforcées : toutes les garanties Visa Premier + annulation toutes causes, protection achats 180 jours, protection juridique voyage
- Accès salons aéroport : 2 accès offerts par an (réseau LoungeKey)
- Conciergerie 24h/24

## Visa Business

Carte destinée aux professionnels et entrepreneurs.

- Cotisation annuelle : 156,00 € (gratuite si incluse dans le Compte Pro Vert)
- Plafond de paiement : 8 000 € sur 30 jours glissants
- Plafond de retrait : 2 000 € sur 7 jours glissants
- Débit différé en fin de mois
- Assurances : assistance voyage d'affaires, location véhicule, RC professionnelle

## Modification des plafonds

Les plafonds de paiement et de retrait peuvent être modifiés :
- **Temporairement** (jusqu'à 2x le plafond initial, pour une durée de 1 à 30 jours) : directement depuis l'application "Banque Verte & Moi" ou l'espace client web, effet immédiat.
- **Définitivement** : sur demande auprès du conseiller. La hausse de plafond est soumise à validation (délai 48h-72h). La baisse est sans condition et prend effet sous 24h.

Pour la Visa Classic : le plafond paiement peut monter jusqu'à 4 000 €/30j et le plafond retrait jusqu'à 800 €/7j.
Pour la Visa Premier : le plafond paiement peut monter jusqu'à 8 000 €/30j et le plafond retrait jusqu'à 2 500 €/7j.

Attention : une hausse définitive de plafond peut entraîner une réévaluation des conditions d'éligibilité par le conseiller.

## Renouvellement et expiration

Les cartes sont émises pour une durée de 3 ans. Le renouvellement est automatique 1 mois avant l'expiration. La nouvelle carte est envoyée au domicile par courrier recommandé.

En cas de besoin de renouvellement anticipé (changement de nom, carte endommagée) : frais de 15,00 €. Délai de fabrication : 7 à 10 jours ouvrés.

## Blocage temporaire

Depuis l'application mobile, il est possible de bloquer temporairement la carte (paiements en magasin, paiements en ligne, retraits, paiements à l'étranger) de manière indépendante. Le déblocage est immédiat.

Cette fonctionnalité ne remplace PAS l'opposition en cas de perte ou de vol (voir procédure d'opposition).
