---
id: PROD_CREDITS
categorie: produit
type: credit
segment: [PART_STD, PART_PREM, PART_PRIV]
produits_lies: [CR_IMMO, CR_CONSO, EP_PEL]
date_maj: 2025-03-01
mots_cles: [crédit, immobilier, prêt, taux, mensualité, apport, consommation, emprunt, assurance emprunteur]
---

# Crédits Banque Verte

## Crédit Immobilier "Vert Habitat"

Le crédit immobilier Banque Verte permet de financer l'acquisition d'une résidence principale, secondaire, ou un investissement locatif, ainsi que des travaux de rénovation.

### Taux indicatifs (mars 2025, hors assurance)

| Durée       | Taux fixe indicatif | Mensualité pour 200 000 € |
|-------------|--------------------|-----------------------------|
| 10 ans      | 2,85 %             | 1 909 €                     |
| 15 ans      | 3,00 %             | 1 381 €                     |
| 20 ans      | 3,15 %             | 1 122 €                     |
| 25 ans      | 3,30 %             | 979 €                       |

Ces taux sont indicatifs et personnalisés en fonction du profil emprunteur, de l'apport, et de la relation bancaire.

### Bonus écologique
Réduction de taux de -0,10 % pour les biens classés A ou B au Diagnostic de Performance Énergétique (DPE). Justificatif DPE à fournir avec le dossier de prêt.

### Conditions
- Montant minimum : 50 000 €
- Durée : 7 à 25 ans (27 ans en cas de VEFA ou de travaux avec différé d'amortissement)
- Apport personnel recommandé : minimum 10 % du montant de l'opération (couvre les frais de notaire et de garantie)
- Taux d'endettement maximum : 35 % des revenus nets du foyer, conformément aux recommandations du HCSF
- Frais de dossier : 950 € (offerts pour les primo-accédants jusqu'au 30/06/2025, campagne en cours)
- Garantie : hypothèque conventionnelle ou caution Crédit Logement / CAMCA

### Assurance emprunteur
L'assurance emprunteur est obligatoire. Deux options :
1. **Assurance groupe Banque Verte** : tarif à partir de 0,25 % du capital emprunté par an, couvrant décès, PTIA, ITT, IPT. Surprime possible selon l'âge et l'état de santé.
2. **Délégation d'assurance** : le client est libre de choisir un assureur externe (loi Lemoine), sous réserve d'équivalence des garanties. Banque Verte s'engage à répondre sous 10 jours ouvrés à toute demande de substitution.

Le questionnaire de santé n'est plus exigé pour les prêts dont la part assurée est inférieure à 200 000 € et dont le terme intervient avant les 60 ans de l'emprunteur (loi Lemoine).

### Pièces du dossier
- 3 derniers bulletins de salaire (ou 2 derniers bilans pour les indépendants)
- 2 derniers avis d'imposition
- 3 derniers relevés de compte courant
- Justificatif d'apport personnel
- Compromis de vente ou contrat de réservation VEFA
- DPE du bien (pour le bonus écologique)

Délai de réponse : offre de prêt sous 3 à 4 semaines après réception du dossier complet.
Délai de réflexion obligatoire : 10 jours calendaires après réception de l'offre (incompressible).

## Crédit à la consommation "Vert Projet"

Crédit amortissable à taux fixe pour financer des projets personnels : travaux, véhicule, équipement, voyage, événement familial.

### Barème indicatif

| Montant   | Durée    | TAEG fixe | Mensualité |
|-----------|----------|-----------|------------|
| 5 000 €   | 36 mois  | 5,50 %    | 150,75 €   |
| 10 000 €  | 48 mois  | 4,90 %    | 229,84 €   |
| 20 000 €  | 60 mois  | 4,50 %    | 372,86 €   |
| 30 000 €  | 72 mois  | 5,20 %    | 486,12 €   |

### Conditions
- Montant : de 1 000 € à 75 000 €
- Durée : 6 à 84 mois
- Frais de dossier : gratuits
- Assurance emprunteur : facultative mais recommandée (à partir de 0,18 % du capital par mois)
- Délai de rétractation : 14 jours calendaires après acceptation de l'offre
- Réponse de principe : sous 48h
- Déblocage des fonds : sous 7 jours ouvrés après la fin du délai de rétractation

### Remboursement anticipé
Le remboursement anticipé total ou partiel est possible à tout moment. Indemnités de remboursement anticipé : maximum 1 % du capital restant dû si le remboursement intervient plus d'un an avant la fin du prêt, 0,5 % si moins d'un an. Pas d'indemnité si le montant remboursé est inférieur à 10 000 € sur 12 mois.

### Eco-bonus
Pour les projets liés à la transition écologique (achat véhicule électrique, panneaux solaires, isolation, pompe à chaleur) : réduction de taux de -0,20 % sur le TAEG. Justificatif : devis ou facture du prestataire.

Un crédit vous engage et doit être remboursé. Vérifiez vos capacités de remboursement avant de vous engager.
