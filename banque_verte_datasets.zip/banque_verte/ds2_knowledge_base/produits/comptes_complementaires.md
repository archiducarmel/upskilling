---
id: PROD_CPT_TREMP
categorie: produit
type: compte_courant
segment: [JEUNE]
produits_lies: [CB_CLASSIC, EP_LIVJEU, EP_LIVRA]
date_maj: 2025-01-15
mots_cles: [compte tremplin, jeune, étudiant, gratuit, 18-25 ans, première carte]
---

# Compte Tremplin

Le Compte Tremplin est l'offre gratuite de la Banque Verte réservée aux jeunes de 18 à 25 ans.

## Tarification

La cotisation mensuelle est de 0 € : le compte est entièrement gratuit pendant toute la période d'éligibilité (jusqu'au 31 décembre de l'année des 25 ans).

## Services inclus

- Carte Visa Classic à débit immédiat (gratuite, pas de cotisation annuelle)
- Accès à l'application "Banque Verte & Moi" et à l'espace client en ligne
- Virements SEPA en ligne gratuits et illimités
- Alertes SMS de solde et opérations incluses
- 1 chéquier (sur demande)

## Découvert autorisé

Un découvert autorisé de 200 € maximum peut être accordé, soumis à l'étude du dossier. Taux débiteur : 15,80 %. Les étudiants boursiers bénéficient d'un examen bienveillant de leur demande.

## Conditions d'ouverture

- Avoir entre 18 et 25 ans révolus
- Pièce d'identité en cours de validité
- Justificatif de domicile de moins de 3 mois OU certificat de scolarité
- Premier versement minimum : 20 €

Pour les 16-17 ans : ouverture possible avec autorisation parentale (les deux parents ou représentant légal). La carte est alors une carte de retrait uniquement.

## Fin du Compte Tremplin

Le Compte Tremplin prend fin au 31 décembre de l'année des 25 ans du client. Environ 2 mois avant, le client reçoit un courrier l'invitant à choisir entre :
- Le Compte Essentiel (2,90 €/mois)
- Le Compte Horizon (8,50 €/mois, si éligible)

À défaut de choix, le compte bascule automatiquement vers le Compte Essentiel.

## Offres complémentaires recommandées

- Livret Jeune à 3 % (plafond 1 600 €)
- Livret A (plafond 22 950 €)
- Application d'aide à la gestion de budget intégrée dans l'appli mobile

---

---
id: PROD_CPT_PRIV
categorie: produit
type: compte_courant
segment: [PART_PRIV]
produits_lies: [CB_INFINITE, EP_AV, CR_IMMO]
date_maj: 2024-09-10
mots_cles: [compte privilège, banque privée, infinite, patrimoine, conciergerie, haut de gamme]
---

# Compte Privilège — Banque Privée

Le Compte Privilège est l'offre dédiée aux clients de la Banque Privée Banque Verte. Il offre un accompagnement patrimonial personnalisé et des services d'exception.

## Tarification

Cotisation mensuelle : 24,00 € (288,00 € par an).

## Services inclus

- Carte Visa Infinite avec toutes ses assurances et garanties
- Conciergerie 24h/24 7j/7 (réservations, billetterie, services personnels)
- Assurance des moyens de paiement Formule Intégrale
- 2 accès salons aéroport par an (réseau LoungeKey)
- Service de change préférentiel (marge réduite à 0,80 % au lieu de 1,50 %)
- Bilan patrimonial annuel offert avec un conseiller dédié en banque privée
- Virements internationaux à tarif réduit
- Alertes et notifications illimitées
- Ligne téléphonique directe vers le conseiller dédié

## Conditions d'éligibilité

Le Compte Privilège est accessible sur invitation ou sur demande validée par un conseiller Banque Privée. Le client doit remplir AU MOINS UNE des conditions suivantes :
- Encours global (épargne + investissements) ≥ 250 000 € chez Banque Verte
- Revenus nets mensuels ≥ 6 000 € domiciliés chez Banque Verte

## Découvert autorisé

Jusqu'à 10 000 € sous réserve d'acceptation. Taux débiteur : 12,90 %. Agios prélevés trimestriellement.

## Conseiller dédié

Chaque client Banque Privée bénéficie d'un conseiller patrimonial dédié, joignable par téléphone direct, e-mail ou rendez-vous en agence. Le ratio est d'environ 1 conseiller pour 120 clients, garantissant un suivi personnalisé.

---

---
id: PROD_CPT_PRO
categorie: produit
type: compte_courant
segment: [PRO]
produits_lies: [CB_BUSINESS]
date_maj: 2025-02-01
mots_cles: [compte pro, professionnel, auto-entrepreneur, artisan, TPE, terminal paiement, Kbis]
---

# Compte Pro Vert

Le Compte Pro Vert est l'offre de la Banque Verte destinée aux professionnels : auto-entrepreneurs, professions libérales, artisans, commerçants et TPE de moins de 10 salariés.

## Tarification

Cotisation mensuelle : 12,00 € (144,00 € par an).

## Services inclus

- Carte Visa Business (débit différé fin de mois)
- Relevés mensuels au format compatible avec les logiciels de comptabilité (export CSV, PDF)
- Ligne téléphonique dédiée pro (numéro direct du conseiller)
- Virements SEPA en ligne gratuits et illimités
- Accès au service de remise de chèques en ligne (scan via appli)
- Terminal de paiement (TPE) à tarif préférentiel : location à partir de 19,90 €/mois (au lieu de 29,90 €)
- Séparation claire entre compte pro et compte perso

## Découvert autorisé

Jusqu'à 5 000 € sous réserve d'acceptation (étude basée sur le chiffre d'affaires et l'ancienneté de l'activité). Taux débiteur : 14,20 %.

## Conditions d'ouverture

- Extrait Kbis de moins de 3 mois (sociétés) OU numéro SIRET/INSEE (auto-entrepreneurs)
- Pièce d'identité du dirigeant
- Justificatif de domicile professionnel
- Statuts de la société (si applicable)

## Obligations légales

Rappel : depuis la loi PACTE, les auto-entrepreneurs dont le chiffre d'affaires annuel dépasse 10 000 € pendant deux années consécutives sont tenus d'ouvrir un compte bancaire dédié à leur activité professionnelle. Ce compte n'est pas obligatoirement un "compte professionnel" mais doit être séparé du compte personnel.

## Terminal de paiement (TPE)

Banque Verte propose des TPE fixes et mobiles en partenariat avec Ingenico :
- TPE fixe : location 19,90 €/mois, commission par transaction 0,70 %
- TPE mobile (4G) : location 24,90 €/mois, commission par transaction 0,80 %
- En cas de panne : appeler la hotline technique au 09 69 32 00 55 (lun-sam 8h-20h). Remplacement sous 48h ouvrées en cas de défaillance matérielle.
