---
id: PROD_CPT_HOR
categorie: produit
type: compte_courant
segment: [PART_PREM]
produits_lies: [CB_PREMIER, EP_AV, CR_IMMO]
date_maj: 2024-11-20
mots_cles: [compte horizon, premium, visa premier, assurance, avantages]
---

# Compte Horizon

Le Compte Horizon est l'offre premium de la Banque Verte destinée aux clients disposant de revenus confortables ou d'un patrimoine d'épargne significatif. Il offre un package de services complet incluant la carte Visa Premier et de nombreux avantages.

## Tarification

La cotisation mensuelle est de 8,50 € par mois (102,00 € par an). Ce tarif inclut l'ensemble des services décrits ci-dessous.

Note : pour les clients qui passent d'un Compte Essentiel à un Compte Horizon, la cotisation du mois en cours est calculée au prorata à compter de la date d'activation.

## Services inclus

- Carte Visa Premier (à débit immédiat ou différé) avec toutes ses assurances voyage
- Assurance des moyens de paiement (Formule Intégrale, valeur 4,80 €/mois)
- Alertes SMS et notifications push illimitées
- Virements SEPA en ligne gratuits et illimités
- 2 virements internationaux SWIFT par an à tarif réduit (5,00 € au lieu de 9,50 €)
- Remises partenaires Banque Verte (cinéma Pathé-Gaumont : -2 € par place, partenaires loisirs)
- Assistance et rapatriement en France et à l'étranger (via Europ Assistance)

## Conditions d'éligibilité

Pour bénéficier du Compte Horizon, le client doit remplir AU MOINS UNE des conditions suivantes :
- Domicilier des revenus nets mensuels ≥ 2 500 € sur son compte Banque Verte
- Détenir un encours d'épargne ≥ 50 000 € chez Banque Verte (tous supports confondus : livrets, PEL, assurance vie, etc.)

En cas de non-respect des conditions pendant 3 mois consécutifs, le client est averti par courrier et dispose de 2 mois pour régulariser sa situation. À défaut, le compte est basculé automatiquement vers un Compte Essentiel (avec changement de carte Visa Premier → Visa Classic).

## Découvert autorisé

Jusqu'à 2 000 € sous réserve d'acceptation. Taux débiteur : 14,50 % (TAEG 15,72 %). Agios prélevés trimestriellement.

## Avantage Visa Premier – Assurances voyage

La carte Visa Premier inclut automatiquement les garanties suivantes pour tout voyage réglé avec la carte (au moins 50 % du transport) :
- Annulation / modification de voyage : remboursement jusqu'à 5 000 € par assuré
- Retard d'avion (> 4h) : indemnité forfaitaire de 150 €
- Bagages retardés (> 6h) : forfait de première nécessité de 200 €
- Assistance médicale et rapatriement : frais réels sans plafond dans le monde entier
- Responsabilité civile villégiature : jusqu'à 1 500 000 €
- Garantie neige et montagne : couverture des frais de secours sur piste

Pour toute déclaration de sinistre : appeler le 01 44 92 31 60 (du lundi au vendredi 9h-18h) ou envoyer le dossier à sinistres@banqueverte.fr dans les 5 jours suivant l'événement.
