---
id: PROD_CPT_ESS
categorie: produit
type: compte_courant
segment: [PART_STD]
produits_lies: [CB_CLASSIC, EP_LIVRA, EP_LDDS]
date_maj: 2025-01-15
mots_cles: [compte courant, compte essentiel, carte visa, frais bancaires, cotisation]
---

# Compte Essentiel

Le Compte Essentiel est l'offre de base de la Banque Verte pour les clients particuliers. Il convient aux personnes qui recherchent un compte bancaire simple et abordable pour la gestion de leurs opérations quotidiennes.

## Caractéristiques principales

Le Compte Essentiel est facturé 2,90 € par mois (soit 34,80 € par an). Ce tarif comprend :
- La tenue de compte
- Une carte Visa Classic à débit immédiat ou différé (au choix lors de la souscription)
- L'accès à l'application mobile "Banque Verte & Moi" et à l'espace client en ligne
- Les virements SEPA en ligne illimités et gratuits
- Un RIB au format IBAN

Les alertes SMS ne sont pas incluses dans cette offre (disponibles en option à 1,20 €/mois ou incluses dans le Compte Horizon).

## Découvert autorisé

Un découvert autorisé jusqu'à 500 € peut être accordé sur étude du dossier. Le taux débiteur appliqué est le taux conventionnel en vigueur (actuellement 15,80 % par an, soit un TAEG de 16,94 %). Les agios sont prélevés trimestriellement.

Attention : au-delà du découvert autorisé, une commission d'intervention de 8 € par opération est facturée (plafonnée à 80 € par mois).

## Conditions d'ouverture

Pour ouvrir un Compte Essentiel, il faut :
- Être une personne physique majeure (ou mineure de 16 ans avec autorisation parentale)
- Résider fiscalement en France
- Fournir : pièce d'identité en cours de validité, justificatif de domicile de moins de 3 mois, un specimen de signature

Le premier versement minimum est de 50 €.

## Opérations incluses

- Virements SEPA en ligne : gratuits et illimités
- Virements SEPA en agence : 3,50 € par opération
- Prélèvements : gratuits
- Remise de chèques : gratuite
- Un chéquier : gratuit (envoi recommandé en option : 5,20 €)

## Changement d'offre

Il est possible de passer du Compte Essentiel au Compte Horizon à tout moment, sans frais de migration. Le changement de carte bancaire (Visa Classic vers Visa Premier) prend effet sous 7 à 10 jours ouvrés. L'ancienne carte doit être restituée en agence ou détruite.

## Clôture

La clôture du Compte Essentiel est gratuite et peut être demandée à tout moment par courrier, en agence, ou via l'espace client en ligne. Le service d'aide à la mobilité bancaire (dispositif légal) est disponible pour faciliter le transfert des prélèvements et virements récurrents vers un autre établissement. Délai de traitement : environ 22 jours ouvrés.
