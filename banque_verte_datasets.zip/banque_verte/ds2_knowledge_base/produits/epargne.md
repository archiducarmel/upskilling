---
id: PROD_EPARGNE
categorie: produit
type: epargne
segment: [PART_STD, PART_PREM, PART_PRIV, JEUNE]
produits_lies: [EP_LIVRA, EP_LDDS, EP_LIVJEU, EP_PEL, EP_AV, EP_CEL]
date_maj: 2025-02-15
mots_cles: [épargne, livret a, ldds, pel, assurance vie, taux, plafond, fiscalité, intérêts]
---

# Produits d'épargne Banque Verte

## Livret A

Le Livret A est le produit d'épargne réglementé le plus populaire en France. Son taux est fixé par l'État.

- Taux en vigueur : 2,40 % net (depuis le 1er février 2025)
- Plafond de versement : 22 950 € (hors intérêts capitalisés)
- Fiscalité : totalement exonéré d'impôt sur le revenu ET de prélèvements sociaux
- Disponibilité : fonds disponibles à tout moment, virement vers le compte courant sous 24 à 48h
- Calcul des intérêts : par quinzaine. Les versements produisent des intérêts à compter de la quinzaine suivante. Les retraits cessent de produire des intérêts dès la quinzaine du retrait.
- Un seul Livret A par personne (y compris les mineurs)

Conseil : pour optimiser les intérêts, il vaut mieux effectuer les versements le 14 ou le 29 du mois (veille de quinzaine) et les retraits le 1er ou le 16.

## Livret de Développement Durable et Solidaire (LDDS)

Fonctionnement quasi-identique au Livret A, avec un plafond différent.

- Taux : 2,40 % net (même taux que le Livret A)
- Plafond : 12 000 €
- Fiscalité : exonéré d'IR et de prélèvements sociaux
- Conditions : être majeur, résider fiscalement en France
- Particularité : le LDDS contribue au financement de projets écologiques et solidaires. Le client peut choisir de reverser une partie de ses intérêts à une association partenaire (sur demande).

Le LDDS est cumulable avec un Livret A.

## Livret Jeune

- Taux Banque Verte : 3,00 % net (supérieur au minimum réglementaire)
- Plafond : 1 600 €
- Fiscalité : exonéré d'IR et de PS
- Réservé aux 12-25 ans
- Carte de retrait possible à partir de 16 ans (carte de retrait uniquement, pas de paiement)
- Clôture automatique le 31 décembre de l'année des 25 ans du titulaire. Le solde est alors transféré vers le Livret A ou le compte courant.

## Plan Épargne Logement (PEL)

Le PEL est un produit d'épargne bloqué qui permet de constituer un apport pour un projet immobilier.

- Taux de rémunération : 1,75 % brut pour les PEL ouverts à partir du 1er janvier 2025
- Plafond : 61 200 € (hors intérêts)
- Durée minimale : 4 ans
- Durée maximale : 10 ans (au-delà, le PEL continue de produire des intérêts pendant 5 ans mais ne peut plus recevoir de versements)
- Versement minimum : 225 € à l'ouverture, puis 540 € par an minimum (soit 45 €/mois)
- Fiscalité : PFU de 30 % (12,8 % IR + 17,2 % PS) sur les intérêts dès la 1re année (pour les PEL ouverts depuis le 1er janvier 2018)
- Droit au prêt : après 4 ans, le titulaire peut obtenir un prêt immobilier à taux privilégié de 2,25 % (pour les PEL ouverts en 2025), dans la limite de 92 000 €.

ATTENTION : tout retrait avant 4 ans entraîne la clôture du PEL et la perte des droits au prêt. Il n'y a pas de retrait partiel possible.

Un seul PEL par personne.

## Compte Épargne Logement (CEL)

- Taux : 1,50 % brut
- Plafond : 15 300 €
- Disponibilité : fonds disponibles à tout moment (contrairement au PEL)
- Versement minimum : 300 € à l'ouverture, puis 75 € par versement
- Fiscalité : PFU 30 % pour les CEL ouverts depuis 2018
- Compatible avec un PEL
- Droit à un prêt épargne logement après 18 mois de détention

## Assurance Vie "Vert Avenir"

Contrat d'assurance vie multisupport distribué par Banque Verte et assuré par Vert Assurances.

- Versement initial minimum : 500 €
- Versements complémentaires : minimum 100 € (libres ou programmés)
- Pas de plafond réglementaire

### Supports disponibles

1. **Fonds euros "Sérénité"** : capital garanti, rendement 2024 de 2,80 % net de frais de gestion. Adapté aux profils prudents.

2. **UC Vert Impact (ISR)** : fonds investi dans des entreprises engagées dans la transition écologique (label ISR et Greenfin). Performance 2024 : +7,2 %. Niveau de risque SRRI 4/7.

3. **UC Dynamique Monde** : fonds actions internationales diversifié. Performance 2024 : +11,5 %. Niveau de risque SRRI 6/7. Ce fonds peut connaître des fluctuations importantes.

4. **UC Immobilier Durable (SCPI)** : fonds investi en immobilier tertiaire écoresponsable. Performance 2024 : +4,1 %. Niveau de risque SRRI 3/7.

### Frais
- Frais d'entrée : 1,50 % maximum (négociables avec le conseiller, souvent réduits à 0,50 % lors de promotions)
- Frais de gestion annuels : 0,60 % sur fonds euros, 0,80 % sur UC
- Frais d'arbitrage : 0,50 % du montant arbitré (1 arbitrage gratuit par an)

### Fiscalité
- Avant 8 ans : PFU 30 % sur les gains en cas de rachat
- Après 8 ans : abattement annuel de 4 600 € (personne seule) ou 9 200 € (couple marié/pacsé) sur les gains, puis taxation à 24,7 % (7,5 % IR + 17,2 % PS) pour les versements < 150 000 €

### Rachat
Le rachat (partiel ou total) est possible à tout moment. Délai de traitement : 72h ouvrées en pratique. Mais attention à la fiscalité : un rachat avant 8 ans est fiscalement pénalisant.

### Clause bénéficiaire
Par défaut : "Mon conjoint, à défaut mes enfants, à défaut mes héritiers". Le client peut modifier la clause à tout moment en agence ou par courrier recommandé.

### Avertissement
Les performances passées ne préjugent pas des performances futures. Les UC présentent un risque de perte en capital. L'assureur ne s'engage que sur le nombre d'unités de compte mais pas sur leur valeur.
