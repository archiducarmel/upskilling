---
id: REGL_ENSEMBLE
categorie: reglementation
type: droits_obligations
segment: [PART_STD, PART_PREM, PART_PRIV, PRO, JEUNE]
date_maj: 2024-10-15
mots_cles: [rgpd, données personnelles, dsp2, authentification forte, lcb-ft, justificatif, kyc, médiation, réclamation, droits]
---

# Réglementation bancaire — Ce que le client doit savoir

## Protection des données personnelles (RGPD)

La Banque Verte traite les données personnelles de ses clients conformément au Règlement Général sur la Protection des Données (RGPD).

### Données collectées
La banque collecte et traite : les données d'identification (nom, prénom, date de naissance, adresse), les données financières (revenus, patrimoine, opérations bancaires), les données de connexion (logs d'accès à l'espace client), et éventuellement des données de santé (uniquement dans le cadre de l'assurance emprunteur, avec consentement explicite).

### Droits du client
Le client peut exercer à tout moment :
- **Droit d'accès** : obtenir une copie de toutes les données le concernant
- **Droit de rectification** : corriger des données inexactes
- **Droit à l'effacement** : demander la suppression de ses données (sous réserve des obligations légales de conservation)
- **Droit à la portabilité** : récupérer ses données dans un format exploitable
- **Droit d'opposition** : s'opposer au traitement de ses données à des fins de prospection commerciale

### Comment exercer ses droits
Envoyer un courrier au Délégué à la Protection des Données (DPO) :
DPO Banque Verte — 14 avenue de la République — 75011 Paris
Ou par e-mail : dpo@banqueverte.fr
Réponse sous 30 jours maximum.

### Conservation des données
- Données de compte actif : pendant toute la durée de la relation bancaire
- Données après clôture : 5 ans (obligation légale de conservation des pièces comptables)
- Données de connexion / traces : 1 an
- Données relatives à un crédit : 5 ans après la fin du remboursement

## Authentification forte (DSP2)

La Directive sur les Services de Paiement 2 (DSP2) impose une authentification forte pour sécuriser les opérations sensibles.

### Quand l'authentification forte est-elle requise ?
- Connexion à l'espace client en ligne (au moins tous les 90 jours)
- Paiements en ligne > 30 € (via 3D Secure)
- Ajout d'un nouveau bénéficiaire de virement
- Modification des plafonds de carte
- Virements vers un bénéficiaire non enregistré

### Comment ça fonctionne chez Banque Verte ?
L'authentification forte combine au moins 2 des 3 éléments suivants :
1. **Quelque chose que vous connaissez** : code PIN, mot de passe
2. **Quelque chose que vous possédez** : votre smartphone avec l'appli Banque Verte & Moi
3. **Quelque chose que vous êtes** : empreinte digitale, reconnaissance faciale

En pratique : une notification est envoyée sur l'application mobile. Le client valide par biométrie ou par saisie de son code personnel à 6 chiffres.

### Si le client n'a pas de smartphone
Un boîtier générateur de code (Digipass) est disponible sur demande en agence (frais : 29,00 €). Alternativement, un code est envoyé par SMS (moins sécurisé, option appelée à disparaître progressivement).

## Connaissance client (LCB-FT / KYC)

La réglementation anti-blanchiment (LCB-FT) oblige la banque à vérifier l'identité de ses clients et à comprendre l'origine de leurs fonds.

### Justificatifs pouvant être demandés
La Banque Verte peut, à tout moment de la relation, demander :
- Une pièce d'identité en cours de validité (CNI, passeport)
- Un justificatif de domicile de moins de 3 mois
- Un justificatif de revenus (bulletin de salaire, avis d'imposition)
- Un justificatif de l'origine des fonds pour les opérations inhabituelles (vente immobilière, héritage, donation)

### Pourquoi la banque pose-t-elle ces questions ?
Ce n'est pas de l'intrusion : c'est une obligation légale. La banque encourt des sanctions pénales et administratives si elle ne respecte pas ces obligations. Le refus de fournir les justificatifs demandés peut entraîner la restriction des services ou, en dernier recours, la clôture du compte.

### Opérations surveillées
Les opérations suivantes peuvent faire l'objet de vérifications complémentaires :
- Virements internationaux de montants importants
- Dépôts d'espèces récurrents ou inhabituels
- Opérations sans lien apparent avec l'activité du client

La banque ne peut pas informer le client qu'une déclaration de soupçon a été faite auprès de TRACFIN (obligation de discrétion).

## Réclamations et médiation

### Procédure de réclamation
1. **1er niveau** : contacter son conseiller ou le service client (01 44 92 30 00)
2. **2e niveau** : si la réponse ne satisfait pas le client, adresser un courrier au Service Relations Clientèle : Banque Verte — Service Réclamations — TSA 40012 — 75702 Paris Cedex 13. Ou par e-mail : reclamations@banqueverte.fr. Réponse sous 15 jours ouvrés (2 mois maximum pour les cas complexes).
3. **3e niveau** : si le désaccord persiste après la réponse du service réclamations, le client peut saisir le Médiateur de la Banque Verte (gratuit) : Médiateur Banque Verte — TSA 54141 — 75702 Paris Cedex 13. Le médiateur rend son avis sous 90 jours.

Le recours au médiateur est gratuit et n'empêche pas le client d'engager une action en justice.

## Droit au compte

Toute personne physique résidant en France, dépourvue d'un compte de dépôt, peut demander à la Banque de France de désigner un établissement qui sera tenu de lui ouvrir un compte avec les services bancaires de base (droit au compte, article L. 312-1 du Code monétaire et financier). La Banque Verte est tenue de respecter cette procédure.
