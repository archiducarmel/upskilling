# VoiceAdvisor — Jeu de données Banque Verte

## Vue d'ensemble

Ce jeu de données alimente le projet étudiant VoiceAdvisor (service client bancaire augmenté par voice cloning). Il est construit autour d'une banque fictive, la **Banque Verte**, et couvre l'ensemble des données nécessaires au pipeline STT → RAG → TTS.

## Structure

```
banque_verte/
├── ds1_referentiel/
│   └── banque_verte.json                # Identité, segments, gamme, tarifs
├── ds2_knowledge_base/
│   ├── produits/
│   │   ├── compte_essentiel.md          # Fiche Compte Essentiel
│   │   ├── compte_horizon.md            # Fiche Compte Horizon (Premium)
│   │   ├── comptes_complementaires.md   # Tremplin, Privilège, Pro Vert
│   │   ├── cartes_bancaires.md          # Gamme complète de cartes Visa
│   │   ├── epargne.md                   # Livret A, LDDS, PEL, AV, CEL
│   │   └── credits.md                   # Crédit immobilier et consommation
│   ├── procedures/
│   │   ├── opposition_carte.md          # Perte, vol, fraude
│   │   ├── virements.md                 # SEPA, instantané, international
│   │   ├── operations_courantes.md      # Plafonds, chéquier, clôture
│   │   └── assurance_contestation_mobilite.md  # Assurance MDP, prélèvements, mobilité
│   ├── faq/
│   │   └── faq_generale.md              # 20+ questions-réponses
│   └── reglementation/
│       └── reglementation_client.md     # RGPD, DSP2, LCB-FT, médiation
├── ds3_personas/
│   └── personas.json                    # 10 profils clients détaillés
├── ds4_questions/
│   ├── corpus_questions_reponses.json           # Questions Q001-Q025
│   ├── corpus_questions_reponses_complement.json # Questions Q026-Q060
│   └── corpus_complet.json              # Fusion des 60 questions (fichier principal)
├── ds7_voix_conseillers/
│   └── scripts_enregistrement.json      # Scripts pour 3 conseillers (24 phrases)
├── ds8_evaluation/
│   └── matrice_evaluation.json          # Grille de scoring (60 scénarios × 13 métriques)
└── README.md
```

## Contenu par dataset

| Dataset | Fichiers | Contenu | Usage pipeline |
|---------|----------|---------|----------------|
| DS-1 | 1 JSON | Référentiel banque (5 segments, 5 comptes, 4 cartes, 6 épargnes, 2 crédits, tarifs) | Source de vérité partagée |
| DS-2 | 10 Markdown | ~60 fiches KB avec métadonnées YAML front-matter | Indexation RAG (embeddings + ChromaDB) |
| DS-3 | 1 JSON | 10 personas avec produits, encours, historique | Contexte client injecté dans le prompt LLM |
| DS-4+DS-5 | 2 JSON (fusionnés) | 60 questions (version écrite + orale) + réponses de référence + fiches attendues | Test E2E + évaluation RAG |
| DS-7 | 1 JSON | 3 conseillers × 8 phrases = 24 scripts d'enregistrement | Échantillons pour XTTS-v2 voice cloning |
| DS-8 | 1 JSON | 60 scénarios × 13 métriques (à remplir) | Protocole d'évaluation reproductible |

## Couverture du corpus de questions (60 questions)

### Par thème
- Carte bancaire : 9 questions
- Compte courant : 11 questions
- Épargne : 10 questions
- Crédit : 5 questions
- Opérations (virements, prélèvements) : 8 questions
- Réglementation : 5 questions
- Services (appli, agence) : 4 questions
- Assurance : 1 question
- Hors périmètre / composite : 7 questions

### Par difficulté
- Facile : 22 questions (réponse directe, 1 fiche KB)
- Moyen : 27 questions (reformulation orale, croisement de fiches, contexte client)
- Difficile : 11 questions (ambiguë, hors périmètre, composite, guardrails critiques)

### Par intention
- Informationnelle : 35 questions
- Transactionnelle : 12 questions
- Résolution de problème : 6 questions
- Hors périmètre (refus/redirection attendu) : 4 questions
- Composite (plusieurs intentions) : 3 questions

### Par persona
Chaque persona apparaît entre 3 et 8 fois. Couverture diversifiée par âge (21-71 ans), segment (jeune, standard, premium, privé, pro), et canal préféré.

## Cohérence interne

Les datasets sont interconnectés par des IDs stables :
- Les produits du DS-1 sont référencés dans les personas du DS-3
- Les fiches KB du DS-2 sont référencées dans le ground truth du DS-4
- Les conseillers du DS-7 sont rattachés aux personas du DS-3
- La matrice DS-8 croise questions, personas, conseillers et fiches attendues

## Imperfections réalistes intégrées

- La fiche Compte Horizon (DS-2) a une date de MAJ plus ancienne (nov 2024) que les autres
- Les revenus de Sofia Rodriguez (CLI_005) sont irréguliers et juste en-dessous des seuils
- Le PEL de Robert Garcia (CLI_010) a dépassé sa durée de versement (12 ans > 10 ans)
- Certaines questions orales contiennent des erreurs factuelles du client (ex: confusion de terminologie)
- La question Q002 (bourse CROUS) est hors du périmètre bancaire strict mais fréquente en pratique
- La question Q005 (TPE en panne) nécessite une escalade vers un service tiers

## Licence

Ce jeu de données est fictif et créé à des fins pédagogiques uniquement. Les noms, tarifs, taux et conditions sont inspirés du marché bancaire français mais ne correspondent à aucun établissement réel. Toute ressemblance avec des personnes existantes est fortuite.
