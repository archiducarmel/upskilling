"""Pydantic schemas for the Sparkov Fraud Detection API."""
from __future__ import annotations
from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field, field_validator, model_validator


class Gender(str, Enum):
    M = "M"
    F = "F"


class MerchantCategory(str, Enum):
    ENTERTAINMENT = "entertainment"
    FOOD_DINING = "food_dining"
    GAS_TRANSPORT = "gas_transport"
    GROCERY_NET = "grocery_net"
    GROCERY_POS = "grocery_pos"
    HEALTH_FITNESS = "health_fitness"
    HOME = "home"
    KIDS_PETS = "kids_pets"
    MISC_NET = "misc_net"
    MISC_POS = "misc_pos"
    PERSONAL_CARE = "personal_care"
    SHOPPING_NET = "shopping_net"
    SHOPPING_POS = "shopping_pos"
    TRAVEL = "travel"


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class DecisionAction(str, Enum):
    APPROVE = "approve"
    REVIEW = "review"
    BLOCK = "block"


class TransactionRequest(BaseModel):
    """A credit card transaction to score for fraud."""

    transaction_id: Optional[str] = Field(None, max_length=64)

    # Transaction
    amt: float = Field(..., gt=0, le=50000, description="Amount in USD", examples=[29.84])
    trans_date_trans_time: str = Field(
        ..., description="Transaction datetime (YYYY-MM-DD HH:MM:SS)",
        examples=["2020-06-21 12:14:33"],
    )
    merchant: str = Field(..., min_length=1, max_length=200, examples=["fraud_Sporer-Keebler"])
    category: MerchantCategory = Field(..., examples=["personal_care"])

    # Customer
    gender: Gender = Field(..., examples=["F"])
    dob: str = Field(
        ..., pattern=r"^\d{4}-\d{2}-\d{2}$",
        description="Date of birth YYYY-MM-DD", examples=["1990-01-17"],
    )
    job: str = Field(..., min_length=1, max_length=200, examples=["Sales professional, IT"])
    state: str = Field(..., min_length=2, max_length=2, description="US state code", examples=["UT"])
    city_pop: int = Field(..., ge=0, le=10_000_000, description="City population", examples=[302])

    # Geolocation
    lat: float = Field(..., ge=-90, le=90, description="Customer latitude", examples=[40.3207])
    long: float = Field(..., ge=-180, le=180, description="Customer longitude", examples=[-110.436])
    merch_lat: float = Field(..., ge=-90, le=90, description="Merchant latitude", examples=[39.4505])
    merch_long: float = Field(..., ge=-180, le=180, description="Merchant longitude", examples=[-109.9604])

    @field_validator("amt")
    @classmethod
    def round_amt(cls, v):
        return round(v, 2)


class BatchTransactionRequest(BaseModel):
    transactions: list[TransactionRequest] = Field(..., min_length=1, max_length=100)

    @field_validator("transactions")
    @classmethod
    def check_unique_ids(cls, v):
        ids = [t.transaction_id for t in v if t.transaction_id]
        if len(ids) != len(set(ids)):
            raise ValueError("Duplicate transaction_id values")
        return v


class PredictionResponse(BaseModel):
    transaction_id: Optional[str] = None
    is_fraud: bool
    fraud_probability: float = Field(..., ge=0.0, le=1.0)
    risk_level: RiskLevel
    recommended_action: DecisionAction
    threshold_used: float
    risk_factors: list[str] = Field(default_factory=list)


class BatchPredictionResponse(BaseModel):
    total: int
    fraud_count: int
    predictions: list[PredictionResponse]


class ModelInfoResponse(BaseModel):
    model_type: str
    dataset: str
    n_features: int
    feature_names: list[str]
    optimal_threshold: float
    cv_roc_auc: float
    cv_pr_auc: float
    training_samples: int
    fraud_ratio: float
    categories: list[str]
    status: str = "healthy"


class HealthResponse(BaseModel):
    status: str = "ok"
    model_loaded: bool
    version: str
