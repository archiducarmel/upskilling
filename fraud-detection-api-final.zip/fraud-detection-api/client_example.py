#!/usr/bin/env python3
"""Client examples for the Sparkov Fraud Detection API."""
import httpx, json

BASE = "http://localhost:8000"

def call(method, path, **kw):
    r = getattr(httpx, method)(f"{BASE}{path}", **kw)
    print(f"\n{'─'*50}\n{method.upper()} {path} → {r.status_code}")
    print(json.dumps(r.json(), indent=2))
    return r

# Normal small purchase
call("post", "/predict", json={
    "amt": 5.36, "trans_date_trans_time": "2020-06-21 14:30:00",
    "merchant": "fraud_Kirlin and Sons", "category": "personal_care",
    "gender": "F", "dob": "1990-01-17", "job": "Engineer",
    "state": "CA", "city_pop": 172817,
    "lat": 34.15, "long": -118.23, "merch_lat": 34.20, "merch_long": -118.30,
})

# Suspicious: high amount, late night, far merchant
call("post", "/predict", json={
    "amt": 1200.00, "trans_date_trans_time": "2020-06-21 03:15:00",
    "merchant": "fraud_Gislason Group", "category": "shopping_net",
    "gender": "M", "dob": "1955-07-06", "job": "Retired",
    "state": "NY", "city_pop": 2504700,
    "lat": 40.68, "long": -73.98, "merch_lat": 33.45, "merch_long": -112.07,
})

call("get", "/model/info")
call("get", "/health")
