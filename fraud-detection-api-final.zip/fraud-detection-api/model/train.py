#!/usr/bin/env python3
"""
Training pipeline for Sparkov Credit Card Fraud Detection.

Feature engineering (22 features):
─────────────────────────────────
NUMERIC (2):  log_amt, city_pop_log
GEOGRAPHIC (3): distance_km, log_distance, far_merchant
TEMPORAL (6): hour, hour_sin, hour_cos, day_of_week, is_weekend, is_night
DEMOGRAPHIC (1): age
CATEGORICAL label-encoded (2): category_enc, gender_enc
CATEGORICAL freq-encoded (3): merchant_freq, state_freq, job_freq
DERIVED (3): amt_per_pop, log_amt_per_pop, age_amt

DROPPED: cc_num, first, last, street, city, zip, trans_num, unix_time, dob,
         lat, long, merch_lat, merch_long (all converted to derived features)
"""

import json
import pickle
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder, RobustScaler
from sklearn.metrics import (
    classification_report, confusion_matrix,
    roc_auc_score, average_precision_score, precision_recall_curve,
)
import xgboost as xgb

warnings.filterwarnings("ignore")

DATA_DIR = Path(__file__).parent.parent / "data"
MODEL_DIR = Path(__file__).parent
MODEL_PATH = MODEL_DIR / "fraud_model.pkl"
SCALER_PATH = MODEL_DIR / "scaler.pkl"
ENCODERS_PATH = MODEL_DIR / "encoders.pkl"
METADATA_PATH = MODEL_DIR / "metadata.json"

RANDOM_STATE = 42
N_FOLDS = 5
TARGET = "is_fraud"
LABEL_ENCODE_COLS = ["category", "gender"]
FREQ_ENCODE_COLS = ["merchant", "state", "job"]


def find_dataset() -> Path:
    if DATA_DIR.exists():
        for f in sorted(DATA_DIR.glob("*.csv")):
            return f
    raise FileNotFoundError(f"No CSV in {DATA_DIR}/. Place fraudTrain.csv there.")


def haversine_km(lat1, lon1, lat2, lon2):
    R = 6371.0
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    dlat, dlon = lat2 - lat1, lon2 - lon1
    a = np.sin(dlat/2)**2 + np.cos(lat1)*np.cos(lat2)*np.sin(dlon/2)**2
    return R * 2 * np.arcsin(np.sqrt(a))


def load_data() -> pd.DataFrame:
    path = find_dataset()
    df = pd.read_csv(path)
    for c in [c for c in df.columns if c.startswith("Unnamed")]:
        df.drop(columns=c, inplace=True)
    print(f"✅ Loaded: {df.shape[0]:,} rows from {path.name}")
    print(f"   Fraud: {df[TARGET].sum():,} ({df[TARGET].mean()*100:.2f}%)")
    return df


def feature_engineering(df, label_encoders=None, freq_maps=None, fit=True):
    out = pd.DataFrame(index=df.index)

    # Numeric
    out["log_amt"] = np.log1p(df["amt"])
    out["city_pop_log"] = np.log1p(df["city_pop"])

    # Geographic
    dist = haversine_km(df["lat"].values, df["long"].values,
                        df["merch_lat"].values, df["merch_long"].values)
    out["distance_km"] = dist
    out["log_distance"] = np.log1p(dist)
    out["far_merchant"] = (dist > 100).astype(int)

    # Temporal
    dt = pd.to_datetime(df["trans_date_trans_time"])
    hours = dt.dt.hour
    out["hour"] = hours
    out["hour_sin"] = np.sin(2 * np.pi * hours / 24)
    out["hour_cos"] = np.cos(2 * np.pi * hours / 24)
    out["day_of_week"] = dt.dt.dayofweek
    out["is_weekend"] = (dt.dt.dayofweek >= 5).astype(int)
    out["is_night"] = ((hours >= 22) | (hours < 6)).astype(int)

    # Demographic
    dob = pd.to_datetime(df["dob"])
    out["age"] = ((dt - dob).dt.days / 365.25).astype(int)

    # Label encoding
    if fit:
        label_encoders = {}
    for col in LABEL_ENCODE_COLS:
        if fit:
            le = LabelEncoder()
            out[f"{col}_enc"] = le.fit_transform(df[col].astype(str))
            label_encoders[col] = le
        else:
            le = label_encoders[col]
            known = set(le.classes_)
            vals = df[col].astype(str).map(lambda x: x if x in known else le.classes_[0])
            out[f"{col}_enc"] = le.transform(vals)

    # Frequency encoding
    if fit:
        freq_maps = {}
    for col in FREQ_ENCODE_COLS:
        if fit:
            freq = df[col].value_counts(normalize=True).to_dict()
            freq_maps[col] = freq
        else:
            freq = freq_maps[col]
        default = 1 / max(len(freq), 1)
        out[f"{col}_freq"] = df[col].map(freq).fillna(default)

    # Derived
    out["amt_per_pop"] = df["amt"] / df["city_pop"].clip(lower=1)
    out["log_amt_per_pop"] = np.log1p(out["amt_per_pop"])
    out["age_amt"] = out["age"] * out["log_amt"]

    return out, label_encoders, freq_maps, list(out.columns)


def find_optimal_threshold(y_true, y_proba):
    prec, rec, thresholds = precision_recall_curve(y_true, y_proba)
    f1 = 2 * (prec * rec) / (prec + rec + 1e-10)
    idx = np.argmax(f1)
    t = float(thresholds[min(idx, len(thresholds) - 1)])
    print(f"✅ Optimal threshold: {t:.4f} (F1={f1[idx]:.4f})")
    return t


def train_and_evaluate(X, y, feature_names):
    scaler = RobustScaler()
    X_scaled = scaler.fit_transform(X)

    n_fraud, n_legit = int(y.sum()), len(y) - int(y.sum())
    spw = n_legit / max(n_fraud, 1)

    print(f"\n{'='*60}")
    print(f"TRAINING — {len(y):,} samples, {len(feature_names)} features")
    print(f"  Legit={n_legit:,}, Fraud={n_fraud:,}, scale_pos_weight={spw:.1f}")
    print(f"{'='*60}")

    params = dict(
        n_estimators=500, max_depth=8, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, scale_pos_weight=spw,
        eval_metric="aucpr", random_state=RANDOM_STATE, n_jobs=-1,
        reg_alpha=0.1, reg_lambda=1.0, min_child_weight=5, gamma=0.1,
    )

    skf = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=RANDOM_STATE)
    cv_probas = np.zeros(len(y))

    for fold, (tr, va) in enumerate(skf.split(X_scaled, y)):
        m = xgb.XGBClassifier(**params)
        m.fit(X_scaled[tr], y[tr], eval_set=[(X_scaled[va], y[va])], verbose=False)
        cv_probas[va] = m.predict_proba(X_scaled[va])[:, 1]
        print(f"  Fold {fold+1}: ROC={roc_auc_score(y[va], cv_probas[va]):.4f} "
              f"PR={average_precision_score(y[va], cv_probas[va]):.4f}")

    cv_roc = roc_auc_score(y, cv_probas)
    cv_pr = average_precision_score(y, cv_probas)
    threshold = find_optimal_threshold(y, cv_probas)
    preds = (cv_probas >= threshold).astype(int)

    print(f"\n  Overall ROC-AUC: {cv_roc:.4f}")
    print(f"  Overall PR-AUC:  {cv_pr:.4f}")
    print(f"\n{classification_report(y, preds, target_names=['Legit','Fraud'], digits=4)}")
    cm = confusion_matrix(y, preds)
    print(f"  Confusion: TN={cm[0,0]:,} FP={cm[0,1]:,} FN={cm[1,0]:,} TP={cm[1,1]:,}")

    # Final model
    print(f"\n{'='*60}")
    print("FINAL MODEL (full data, scale_pos_weight)")
    print(f"{'='*60}")
    final = xgb.XGBClassifier(**params)
    final.fit(X_scaled, y, verbose=False)

    top = sorted(zip(feature_names, final.feature_importances_), key=lambda x: -x[1])
    print("\n  Top features:")
    for n, i in top[:12]:
        print(f"    {n:>25}: {i:.4f}")

    return final, scaler, threshold, cv_roc, cv_pr


def main():
    print("💳 SPARKOV FRAUD DETECTION — TRAINING")
    print("=" * 60)

    df = load_data()
    X_df, le, fm, fnames = feature_engineering(df, fit=True)
    y = df[TARGET].values

    model, scaler, threshold, cv_roc, cv_pr = train_and_evaluate(X_df.values, y, fnames)

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    with open(MODEL_PATH, "wb") as f: pickle.dump(model, f)
    with open(SCALER_PATH, "wb") as f: pickle.dump(scaler, f)
    with open(ENCODERS_PATH, "wb") as f:
        pickle.dump({"label_encoders": le, "freq_maps": fm}, f)

    meta = {
        "model_type": "XGBClassifier",
        "dataset": "Sparkov Credit Card Fraud",
        "n_features": len(fnames),
        "feature_names": fnames,
        "optimal_threshold": threshold,
        "cv_roc_auc": round(cv_roc, 4),
        "cv_pr_auc": round(cv_pr, 4),
        "training_samples": int(len(y)),
        "fraud_ratio": round(float(y.mean()), 6),
        "label_encode_columns": LABEL_ENCODE_COLS,
        "freq_encode_columns": FREQ_ENCODE_COLS,
        "label_encode_classes": {c: list(le[c].classes_) for c in le},
        "categories": list(le["category"].classes_),
    }
    with open(METADATA_PATH, "w") as f:
        json.dump(meta, f, indent=2)

    print(f"\n✅ Saved — Threshold: {threshold:.4f} | ROC: {cv_roc:.4f} | PR: {cv_pr:.4f}")


if __name__ == "__main__":
    main()
