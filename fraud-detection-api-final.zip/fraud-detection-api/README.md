# Sparkov Credit Card Fraud Detection API

Real-time fraud detection API using XGBoost on the Sparkov dataset (1000 customers, 800 merchants, 1.8M transactions).

## Arborescence

```
fraud-detection-api/
├── app/
│   ├── __init__.py
│   ├── main.py                # FastAPI, routes, middleware, inférence
│   └── schemas.py             # Pydantic v2 (enums, validation)
├── model/
│   ├── __init__.py
│   ├── train.py               # Feature engineering + entraînement XGBoost
│   ├── fraud_model.pkl        # (généré) modèle entraîné
│   ├── scaler.pkl             # (généré) RobustScaler
│   ├── encoders.pkl           # (généré) LabelEncoders + FrequencyMaps
│   └── metadata.json          # (généré) seuil, métriques, features
├── data/
│   └── fraudTrain.csv         # ← placer le dataset Sparkov ici
├── tests/
│   ├── __init__.py
│   └── test_api.py            # 23 tests (schemas + intégration)
├── Dockerfile                 # Multi-stage : train → serve
├── docker-compose.yml
├── requirements.txt
├── client_example.py
└── README.md
```

## Quick Start

```bash
# 1. Place fraudTrain.csv in data/
# 2. Train + serve
pip install -r requirements.txt
python -m model.train
uvicorn app.main:app --reload
# → http://localhost:8000/docs

# Or with Docker
docker compose up --build
```

## Feature Engineering (20 features)

| Type | Features | Signal |
|------|----------|--------|
| Geographic | `distance_km`, `log_distance`, `far_merchant` | Haversine customer↔merchant — **top signal** |
| Amount | `log_amt`, `amt_per_pop`, `log_amt_per_pop` | Spending level & relative to city |
| Temporal | `hour`, `hour_sin/cos`, `day_of_week`, `is_weekend`, `is_night` | Late-night = higher fraud risk |
| Demographic | `age`, `age_amt` | Age × spending interaction |
| Categorical | `category_enc`, `gender_enc`, `merchant_freq`, `state_freq`, `job_freq` | Label + frequency encoding |
| Population | `city_pop_log` | Urban vs rural context |

## API Example

```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{
    "amt": 1200, "trans_date_trans_time": "2020-06-21 03:15:00",
    "merchant": "fraud_Gislason Group", "category": "shopping_net",
    "gender": "M", "dob": "1955-07-06", "job": "Retired",
    "state": "NY", "city_pop": 2504700,
    "lat": 40.68, "long": -73.98,
    "merch_lat": 33.45, "merch_long": -112.07
  }'
```

Response:
```json
{
  "is_fraud": true,
  "fraud_probability": 0.9997,
  "risk_level": "critical",
  "recommended_action": "block",
  "risk_factors": [
    "Late-night transaction (03h)",
    "Merchant is 3445km away from customer",
    "High-value transaction: $1,200.00"
  ]
}
```

## Dataset

Sparkov Credit Card Fraud Detection Dataset (Kaggle): https://www.kaggle.com/datasets/kartik2112/fraud-detection
