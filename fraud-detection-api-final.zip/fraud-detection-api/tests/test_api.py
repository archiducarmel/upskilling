"""Tests for Sparkov Fraud Detection API."""
import pytest
from pydantic import ValidationError
from app.schemas import TransactionRequest, BatchTransactionRequest


def _valid(**ov):
    base = dict(
        transaction_id="txn-001", amt=29.84,
        trans_date_trans_time="2020-06-21 12:14:33",
        merchant="fraud_Sporer-Keebler", category="personal_care",
        gender="F", dob="1990-01-17", job="Sales professional",
        state="UT", city_pop=302, lat=40.3207, long=-110.436,
        merch_lat=39.4505, merch_long=-109.9604,
    )
    base.update(ov)
    return base


class TestSchemaValidation:
    def test_valid(self):
        r = TransactionRequest(**_valid())
        assert r.amt == 29.84

    def test_negative_amt(self):
        with pytest.raises(ValidationError): TransactionRequest(**_valid(amt=-1))

    def test_zero_amt(self):
        with pytest.raises(ValidationError): TransactionRequest(**_valid(amt=0))

    def test_amt_rounded(self):
        r = TransactionRequest(**_valid(amt=12.345))
        assert r.amt == 12.35

    def test_invalid_gender(self):
        with pytest.raises(ValidationError): TransactionRequest(**_valid(gender="X"))

    def test_invalid_category(self):
        with pytest.raises(ValidationError): TransactionRequest(**_valid(category="crypto"))

    def test_invalid_dob_format(self):
        with pytest.raises(ValidationError): TransactionRequest(**_valid(dob="17-01-1990"))

    def test_invalid_state_length(self):
        with pytest.raises(ValidationError): TransactionRequest(**_valid(state="Utah"))

    def test_lat_out_of_range(self):
        with pytest.raises(ValidationError): TransactionRequest(**_valid(lat=91))

    def test_long_out_of_range(self):
        with pytest.raises(ValidationError): TransactionRequest(**_valid(long=181))

    def test_all_categories(self):
        cats = ["entertainment","food_dining","gas_transport","grocery_net","grocery_pos",
                "health_fitness","home","kids_pets","misc_net","misc_pos",
                "personal_care","shopping_net","shopping_pos","travel"]
        for c in cats:
            r = TransactionRequest(**_valid(category=c))
            assert r.category.value == c

    def test_optional_txn_id(self):
        d = _valid(); del d["transaction_id"]
        assert TransactionRequest(**d).transaction_id is None


class TestBatch:
    def test_valid(self):
        b = BatchTransactionRequest(transactions=[_valid(transaction_id=f"t{i}") for i in range(3)])
        assert len(b.transactions) == 3

    def test_empty(self):
        with pytest.raises(ValidationError): BatchTransactionRequest(transactions=[])

    def test_over_100(self):
        with pytest.raises(ValidationError):
            BatchTransactionRequest(transactions=[_valid(transaction_id=f"t{i}") for i in range(101)])

    def test_dup_ids(self):
        with pytest.raises(ValidationError):
            BatchTransactionRequest(transactions=[_valid(transaction_id="dup")]*2)


class TestAPIIntegration:
    @pytest.fixture(autouse=True)
    def setup(self):
        try:
            from app.main import app, load_model, _model
            if _model is None: load_model()
            from fastapi.testclient import TestClient
            self.client = TestClient(app)
        except Exception:
            pytest.skip("Model not available")

    def test_health(self):
        r = self.client.get("/health")
        assert r.status_code == 200 and r.json()["model_loaded"]

    def test_model_info(self):
        r = self.client.get("/model/info")
        assert r.status_code == 200
        assert "categories" in r.json()

    def test_predict_legit(self):
        r = self.client.post("/predict", json=_valid(amt=5.0))
        assert r.status_code == 200
        assert 0 <= r.json()["fraud_probability"] <= 1

    def test_predict_suspicious(self):
        r = self.client.post("/predict", json=_valid(
            amt=900, trans_date_trans_time="2020-06-21 02:30:00",
            merch_lat=25.0, merch_long=-80.0,  # far away
        ))
        assert r.status_code == 200
        assert len(r.json()["risk_factors"]) > 0

    def test_predict_batch(self):
        txns = [_valid(transaction_id=f"b{i}") for i in range(3)]
        r = self.client.post("/predict/batch", json={"transactions": txns})
        assert r.status_code == 200 and r.json()["total"] == 3

    def test_validation_error(self):
        r = self.client.post("/predict", json={"amt": -1})
        assert r.status_code == 422

    def test_request_headers(self):
        r = self.client.get("/health", headers={"X-Request-ID": "test-42"})
        assert r.headers["X-Request-ID"] == "test-42"
